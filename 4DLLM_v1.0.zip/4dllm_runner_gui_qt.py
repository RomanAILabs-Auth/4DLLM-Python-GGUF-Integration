#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Copyright Daniel Harding - RomanAILabs
4DLLM Runner GUI — World-Class PyQt6 + HTML/CSS/JS Interface

A stunning graphical interface built with PyQt6 and modern web technologies
for running 4DLLM files with maximum visual quality.
"""

from __future__ import annotations

import json
import os
import queue
import select
import struct
import subprocess
import sys
import threading
import time
import zlib
import ast
import shlex
import logging
import importlib.util
import html
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from datetime import datetime

# For non-blocking I/O
try:
    import fcntl
    HAS_FCNTL = True
except ImportError:
    HAS_FCNTL = False

try:
    from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                                 QHBoxLayout, QPushButton, QLabel, QTextEdit, 
                                 QFileDialog, QMessageBox, QComboBox, QCheckBox,
                                 QLineEdit, QSplitter, QTreeWidget, QTreeWidgetItem,
                                 QTabWidget, QFrame, QScrollArea, QInputDialog, QDialog)
    from PyQt6.QtCore import Qt, QUrl, QThread, pyqtSignal, pyqtSlot, QTimer, QSize
    from PyQt6.QtGui import QFont, QColor, QPalette, QIcon, QClipboard
    from PyQt6.QtWebEngineWidgets import QWebEngineView
    from PyQt6.QtWebChannel import QWebChannel
    HAS_PYQT6 = True
except ImportError:
    try:
        from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                                      QHBoxLayout, QPushButton, QLabel, QTextEdit,
                                      QFileDialog, QMessageBox, QComboBox, QCheckBox,
                                      QLineEdit, QSplitter, QTreeWidget, QTreeWidgetItem,
                                      QTabWidget, QFrame, QScrollArea, QInputDialog, QDialog)
        from PySide6.QtCore import Qt, QUrl, QThread, Signal, Slot, QTimer, QSize
        from PySide6.QtGui import QFont, QColor, QPalette, QIcon, QClipboard
        from PySide6.QtWebEngineWidgets import QWebEngineView
        from PySide6.QtWebChannel import QWebChannel
        HAS_PYQT6 = True
        pyqtSignal = Signal
        pyqtSlot = Slot
    except ImportError:
        HAS_PYQT6 = False

# Import shared utilities from original file using importlib
import importlib.util

def _import_runner_utils():
    """Import utilities from 4dllm_runner.py"""
    runner_path = Path(__file__).parent / "4dllm_runner.py"
    if runner_path.exists():
        try:
            DEBUG_LOGGER.info(f"Loading runner module from: {runner_path}")
            spec = importlib.util.spec_from_file_location("runner_module", str(runner_path))
            if not spec:
                DEBUG_LOGGER.error(f"Failed to create spec for runner module from: {runner_path}")
                return None
            if not spec.loader:
                DEBUG_LOGGER.error(f"Spec loader is None for runner module. Spec: {spec}")
                # Try alternative import method
                try:
                    import sys
                    # Add parent directory to path if needed
                    parent_dir = str(runner_path.parent)
                    if parent_dir not in sys.path:
                        sys.path.insert(0, parent_dir)
                    # Try importing directly
                    runner_module = importlib.import_module("4dllm_runner")
                    DEBUG_LOGGER.info("Runner module loaded via direct import")
                    return runner_module
                except Exception as alt_error:
                    DEBUG_LOGGER.error(f"Alternative import also failed: {alt_error}", exc_info=True)
                    return None
            
            runner_module = importlib.util.module_from_spec(spec)
            if runner_module is None:
                DEBUG_LOGGER.error("module_from_spec returned None")
                return None
            
            spec.loader.exec_module(runner_module)
            DEBUG_LOGGER.info("Runner module loaded successfully")
            return runner_module
        except Exception as e:
            DEBUG_LOGGER.error(f"Failed to load runner module: {e}", exc_info=True)
            import traceback
            DEBUG_LOGGER.error(f"Traceback: {traceback.format_exc()}")
    else:
        DEBUG_LOGGER.error(f"Runner module file not found: {runner_path}")
    return None

def _import_gui_utils():
    """Import utilities from 4dllm_runner_gui.py"""
    gui_path = Path(__file__).parent / "4dllm_runner_gui.py"
    if gui_path.exists():
        try:
            spec = importlib.util.spec_from_file_location("gui_module", str(gui_path))
            if spec and spec.loader:
                gui_module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(gui_module)
                return gui_module
        except Exception as e:
            DEBUG_LOGGER.error(f"Failed to load GUI module: {e}")
    return None

# Setup logger
DEBUG_LOG_FILE = Path(__file__).parent / "4dllm_runner_debug.log"
DEBUG_LOGGER = logging.getLogger("4dllm_runner_gui_qt")
DEBUG_LOGGER.setLevel(logging.DEBUG)
fh = logging.FileHandler(DEBUG_LOG_FILE, mode='a', encoding='utf-8')
fh.setLevel(logging.DEBUG)
# Console handler for verbose output
ch = logging.StreamHandler(sys.stderr)
ch.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s [%(levelname)s] %(name)s: %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
fh.setFormatter(formatter)
ch.setFormatter(formatter)
DEBUG_LOGGER.addHandler(fh)
DEBUG_LOGGER.addHandler(ch)

# GUI Debug Log Handler (will be set up after GUI is created)
class GUIDebugLogHandler(logging.Handler):
    """Custom handler that forwards log messages to the GUI debug log"""
    def __init__(self, gui_instance):
        super().__init__()
        self.gui_instance = gui_instance
        self.setLevel(logging.DEBUG)
        formatter = logging.Formatter('%(levelname)s: %(message)s')
        self.setFormatter(formatter)
    
    def emit(self, record):
        """Emit a log record to the GUI"""
        try:
            if self.gui_instance and hasattr(self.gui_instance, '_append_debug_log'):
                msg = self.format(record)
                level_map = {
                    'DEBUG': 'debug',
                    'INFO': 'info',
                    'WARNING': 'warning',
                    'ERROR': 'error',
                    'CRITICAL': 'error'
                }
                level = level_map.get(record.levelname, 'info')
                self.gui_instance._append_debug_log(msg, level)
        except Exception:
            pass  # Don't let logging errors break the app

# Import utilities
runner_module = _import_runner_utils()
gui_module = _import_gui_utils()

# Import builder functionality
builder_path = Path(__file__).parent / "4dllm_builder_v2.0.py"
builder_module = None
if builder_path.exists():
    try:
        spec = importlib.util.spec_from_file_location("builder_module", str(builder_path))
        if spec and spec.loader:
            builder_module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(builder_module)
        DEBUG_LOGGER.info("Builder module loaded successfully")
    except Exception as e:
        DEBUG_LOGGER.error(f"Failed to load builder module: {e}")

# Import GGUF editor functionality
editor_path = Path(__file__).parent / "gguf-editor.py"
editor_module = None
if editor_path.exists():
    try:
        spec = importlib.util.spec_from_file_location("editor_module", str(editor_path))
        if spec and spec.loader:
            editor_module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(editor_module)
        DEBUG_LOGGER.info("Editor module loaded successfully")
    except Exception as e:
        DEBUG_LOGGER.error(f"Failed to load editor module: {e}")

# Import trainer functionality
trainer_path = Path(__file__).parent / "4dllm_trainer.py"
trainer_module = None
TRAINING_PRESETS = {
    "Quick Fine-Tune": {
        "epochs": "3",
        "learning_rate": "0.0001",
        "batch_size": "4",
        "context_size": "2048",
        "lora_r": "8",
        "lora_alpha": "16",
        "lora_dropout": "0.05",
    },
    "Standard Training": {
        "epochs": "5",
        "learning_rate": "0.0001",
        "batch_size": "8",
        "context_size": "4096",
        "lora_r": "16",
        "lora_alpha": "32",
        "lora_dropout": "0.1",
    },
    "Advanced Training": {
        "epochs": "10",
        "learning_rate": "0.00005",
        "batch_size": "16",
        "context_size": "8192",
        "lora_r": "32",
        "lora_alpha": "64",
        "lora_dropout": "0.15",
    },
}
if trainer_path.exists():
    try:
        spec = importlib.util.spec_from_file_location("trainer_module", str(trainer_path))
        if spec and spec.loader:
            trainer_module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(trainer_module)
            # Extract training presets if available
            if hasattr(trainer_module, 'TRAINING_PRESETS'):
                TRAINING_PRESETS = trainer_module.TRAINING_PRESETS
        DEBUG_LOGGER.info("Trainer module loaded successfully")
    except Exception as e:
        DEBUG_LOGGER.error(f"Failed to load trainer module: {e}")

if gui_module and hasattr(gui_module, 'read_4dllm_info'):
    read_4dllm_info = gui_module.read_4dllm_info
else:
    def read_4dllm_info(path):
        return {"valid": False, "error": "Import failed"}

if runner_module:
    read_and_validate_toc = runner_module.read_and_validate_toc
    read_section_small = runner_module.read_section_small
    SECTION_PYTHON_SCRIPT = runner_module.SECTION_PYTHON_SCRIPT
    SECTION_METADATA = runner_module.SECTION_METADATA
    SECTION_SCRIPT_CONFIG = runner_module.SECTION_SCRIPT_CONFIG
    # Get GGUF section type
    SECTION_GGUF_DATA = getattr(runner_module, 'SECTION_GGUF_DATA', 0x01)
else:
    def read_and_validate_toc(path):
        return [], None
    def read_section_small(path, entry):
        return None
    SECTION_PYTHON_SCRIPT = 0x02
    SECTION_METADATA = 0x03
    SECTION_SCRIPT_CONFIG = 0x04
    SECTION_GGUF_DATA = 0x01  # GGUF data section

# ---------------- World-Class HTML/CSS/JS Interface ----------------

HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>4DLLM Studio</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', 'Segoe UI', -apple-system, BlinkMacSystemFont, sans-serif;
            background: 
                radial-gradient(ellipse at top, rgba(6, 182, 212, 0.1) 0%, transparent 50%),
                radial-gradient(ellipse at bottom right, rgba(59, 130, 246, 0.08) 0%, transparent 50%),
                linear-gradient(135deg, #0a0f1a 0%, #1a1f2e 100%);
            background-attachment: fixed;
            color: #e2e8f0;
            overflow: hidden;
            height: 100vh;
            width: 100vw;
        }
        
        .app-container {
            display: flex;
            flex-direction: column;
            height: 100vh;
            width: 100vw;
        }
        
        /* World-Class Header Banner */
        .header {
            background: linear-gradient(135deg, #0a0f1a 0%, #1e293b 30%, #334155 70%, #1e293b 100%);
            padding: 24px 40px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.5), inset 0 1px 0 rgba(255, 255, 255, 0.1);
            border-bottom: 3px solid transparent;
            background-image: 
                linear-gradient(135deg, #0a0f1a 0%, #1e293b 30%, #334155 70%, #1e293b 100%),
                linear-gradient(90deg, transparent 0%, #06b6d4 20%, #22d3ee 50%, #06b6d4 80%, transparent 100%);
            background-size: 100% 100%, 200% 3px;
            background-position: center, bottom;
            background-repeat: no-repeat, repeat-x;
            position: relative;
            overflow: hidden;
        }
        
        .header-code-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 0;
            overflow: hidden;
        }
        
        .code-easter-egg {
            position: absolute;
            right: -100px;
            top: 50%;
            transform: translateY(-50%) rotate(-10deg);
            font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
            font-size: 64px;
            font-weight: 800;
            white-space: nowrap;
            line-height: 1.5;
            letter-spacing: 4px;
            user-select: none;
            animation: codeGlow 8s ease-in-out infinite;
        }
        
        .code-easter-egg .code-line {
            display: block;
            margin-bottom: 16px;
            font-size: 58px;
            text-shadow: 0 0 30px rgba(6, 182, 212, 0.5), 0 0 60px rgba(34, 211, 238, 0.3);
        }
        
        .code-easter-egg .code-line:nth-child(1) {
            color: rgba(6, 182, 212, 0.22);
            animation: codeLinePulse 6s ease-in-out infinite;
        }
        
        .code-easter-egg .code-line:nth-child(2) {
            color: rgba(34, 211, 238, 0.20);
            animation: codeLinePulse 6s ease-in-out infinite 0.8s;
        }
        
        @keyframes codeGlow {
            0%, 100% {
                opacity: 0.18;
            }
            50% {
                opacity: 0.26;
            }
        }
        
        @keyframes codeLinePulse {
            0%, 100% {
                text-shadow: 0 0 30px rgba(6, 182, 212, 0.4), 0 0 60px rgba(34, 211, 238, 0.2);
            }
            50% {
                text-shadow: 0 0 45px rgba(34, 211, 238, 0.6), 0 0 90px rgba(6, 182, 212, 0.4);
            }
        }
        
        .header::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, 
                transparent 0%, 
                rgba(6, 182, 212, 0.1) 50%, 
                transparent 100%);
            animation: shimmer 4s infinite;
        }
        
        @keyframes shimmer {
            0% { left: -100%; }
            100% { left: 100%; }
        }
        
        .header-content {
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: relative;
            z-index: 1;
        }
        
        .logo-container {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .logo-img {
            width: 101px;
            height: 101px;
            object-fit: contain;
            filter: drop-shadow(0 0 25px rgba(6, 182, 212, 0.7));
            animation: logoGlow 3s ease-in-out infinite;
            transition: transform 0.3s;
        }
        
        .logo-img:hover {
            transform: scale(1.05) rotate(5deg);
        }
        
        .logo-svg {
            width: 72px;
            height: 72px;
            filter: drop-shadow(0 0 25px rgba(6, 182, 212, 0.7));
            animation: logoGlow 3s ease-in-out infinite;
            transition: transform 0.3s;
            display: none !important;
        }
        
        @keyframes logoGlow {
            0%, 100% { 
                filter: drop-shadow(0 0 25px rgba(6, 182, 212, 0.7)) 
                        drop-shadow(0 0 10px rgba(34, 211, 238, 0.5)); 
            }
            50% { 
                filter: drop-shadow(0 0 35px rgba(34, 211, 238, 1)) 
                        drop-shadow(0 0 15px rgba(6, 182, 212, 0.8)); 
            }
        }
        
        .logo-text-container {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }
        
        .logo-main-text {
            font-size: 42px;
            font-weight: 900;
            background: linear-gradient(135deg, #06b6d4 0%, #22d3ee 40%, #3b82f6 60%, #22d3ee 80%, #06b6d4 100%);
            background-size: 200% 200%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            letter-spacing: -1px;
            text-shadow: 0 0 50px rgba(6, 182, 212, 0.5);
            line-height: 1.1;
            animation: gradientShift 4s ease infinite;
        }
        
        @keyframes gradientShift {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }
        
        .logo-brand-text {
            font-size: 16px;
            font-weight: 600;
            color: #cbd5e1;
            letter-spacing: 1px;
            margin-top: 2px;
            text-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
        }
        
        .logo-email {
            font-size: 14px;
            color: #94a3b8;
            font-weight: 500;
            margin-top: 6px;
            transition: all 0.3s;
            cursor: pointer;
            display: inline-block;
        }
        
        .logo-email:hover {
            color: #22d3ee;
            text-shadow: 0 0 10px rgba(34, 211, 238, 0.5);
            transform: translateX(2px);
        }
        
        /* Integrated Navigation in Sidebar */
        .nav-tabs {
            display: flex;
            flex-direction: column;
            gap: 8px;
            margin-top: 20px;
        }
        
        .nav-tab {
            width: 100%;
            padding: 12px 16px;
            background: rgba(51, 65, 85, 0.4);
            border: 1px solid rgba(71, 85, 105, 0.3);
            color: #cbd5e1;
            font-size: 13px;
            font-weight: 600;
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
            text-align: left;
        }
        
        .nav-tab::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(6, 182, 212, 0.2), transparent);
            transition: left 0.5s;
        }
        
        .nav-tab:hover::before {
            left: 100%;
        }
        
        .nav-tab:hover {
            background: rgba(6, 182, 212, 0.2);
            border-color: rgba(6, 182, 212, 0.5);
            color: #22d3ee;
            transform: translateX(2px);
            box-shadow: 0 2px 8px rgba(6, 182, 212, 0.3);
        }
        
        .nav-tab.active {
            background: linear-gradient(135deg, #1e40af 0%, #3b82f6 50%, #06b6d4 100%);
            background-size: 200% 200%;
            border-color: rgba(59, 130, 246, 0.6);
            color: #ffffff;
            box-shadow: 
                0 4px 12px rgba(59, 130, 246, 0.5),
                inset 0 1px 0 rgba(255, 255, 255, 0.25),
                0 0 20px rgba(59, 130, 246, 0.2);
            transform: translateX(2px);
            animation: activeTabGlow 3s ease-in-out infinite;
        }
        
        @keyframes activeTabGlow {
            0%, 100% { 
                background-position: 0% 50%;
                box-shadow: 
                    0 4px 12px rgba(59, 130, 246, 0.5),
                    inset 0 1px 0 rgba(255, 255, 255, 0.25),
                    0 0 20px rgba(59, 130, 246, 0.2);
            }
            50% { 
                background-position: 100% 50%;
                box-shadow: 
                    0 4px 12px rgba(59, 130, 246, 0.6),
                    inset 0 1px 0 rgba(255, 255, 255, 0.3),
                    0 0 25px rgba(6, 182, 212, 0.3);
            }
        }
        
        /* Main Content Area */
        .main-content {
            display: flex;
            flex: 1;
            overflow: hidden;
            gap: 12px;
            padding: 12px;
        }
        
        .sidebar {
            width: 280px;
            background: 
                linear-gradient(180deg, rgba(15, 23, 42, 0.95) 0%, rgba(30, 41, 59, 0.95) 100%),
                linear-gradient(135deg, rgba(6, 182, 212, 0.05) 0%, transparent 50%);
            border-radius: 16px;
            padding: 20px;
            box-shadow: 
                0 8px 32px rgba(0, 0, 0, 0.4),
                0 0 0 1px rgba(71, 85, 105, 0.3),
                inset 0 1px 0 rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(71, 85, 105, 0.3);
            backdrop-filter: blur(20px) saturate(180%);
            overflow-y: auto;
            position: relative;
        }
        
        .sidebar::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 1px;
            background: linear-gradient(90deg, 
                transparent 0%, 
                rgba(6, 182, 212, 0.3) 50%, 
                transparent 100%);
            pointer-events: none;
        }
        
        .sidebar-section {
            margin-bottom: 24px;
        }
        
        .section-title {
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            color: #06b6d4;
            margin-bottom: 12px;
            text-shadow: 0 0 10px rgba(6, 182, 212, 0.3);
            position: relative;
            padding-left: 8px;
        }
        
        .section-title::before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 3px;
            height: 60%;
            background: linear-gradient(180deg, #06b6d4 0%, #22d3ee 100%);
            border-radius: 2px;
            box-shadow: 0 0 8px rgba(6, 182, 212, 0.5);
        }
        
        .btn-primary {
            width: 100%;
            padding: 12px 20px;
            background: linear-gradient(135deg, #1e40af 0%, #3b82f6 50%, #06b6d4 100%);
            background-size: 200% 200%;
            border: none;
            border-radius: 12px;
            color: #ffffff;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 
                0 4px 15px rgba(59, 130, 246, 0.4),
                0 0 0 1px rgba(255, 255, 255, 0.1) inset,
                0 2px 4px rgba(0, 0, 0, 0.2);
            margin-bottom: 8px;
            position: relative;
            overflow: hidden;
            letter-spacing: 0.3px;
        }
        
        .btn-primary::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            border-radius: 50%;
            background: radial-gradient(circle, rgba(255, 255, 255, 0.4) 0%, transparent 70%);
            transform: translate(-50%, -50%);
            transition: width 0.6s cubic-bezier(0.4, 0, 0.2, 1), height 0.6s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .btn-primary::after {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s;
        }
        
        .btn-primary:hover::before {
            width: 300px;
            height: 300px;
        }
        
        .btn-primary:hover::after {
            left: 100%;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            background-position: 100% 50%;
            box-shadow: 
                0 8px 25px rgba(59, 130, 246, 0.6),
                0 0 0 1px rgba(255, 255, 255, 0.2) inset,
                0 4px 8px rgba(0, 0, 0, 0.3);
        }
        
        .btn-primary:active {
            transform: translateY(0);
            box-shadow: 
                0 2px 8px rgba(59, 130, 246, 0.4),
                0 0 0 1px rgba(255, 255, 255, 0.1) inset;
        }
        
        .btn-secondary {
            width: 100%;
            padding: 10px 18px;
            background: 
                linear-gradient(135deg, rgba(51, 65, 85, 0.6) 0%, rgba(71, 85, 105, 0.6) 100%);
            border: 1px solid rgba(71, 85, 105, 0.5);
            border-radius: 10px;
            color: #e2e8f0;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            margin-bottom: 8px;
            position: relative;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
        }
        
        .btn-secondary::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(6, 182, 212, 0.2), transparent);
            transition: left 0.4s;
        }
        
        .btn-secondary:hover::before {
            left: 100%;
        }
        
        .btn-secondary:hover {
            background: 
                linear-gradient(135deg, rgba(71, 85, 105, 0.8) 0%, rgba(100, 116, 139, 0.8) 100%);
            border-color: #06b6d4;
            transform: translateY(-1px);
            box-shadow: 
                0 4px 12px rgba(6, 182, 212, 0.3),
                0 0 0 1px rgba(6, 182, 212, 0.2);
        }
        
        .btn-secondary:active {
            transform: translateY(0);
        }
        
        .workspace {
            flex: 1;
            background: 
                linear-gradient(180deg, rgba(15, 23, 42, 0.95) 0%, rgba(30, 41, 59, 0.95) 100%),
                linear-gradient(135deg, rgba(6, 182, 212, 0.03) 0%, transparent 50%);
            border-radius: 16px;
            padding: 24px;
            box-shadow: 
                0 8px 32px rgba(0, 0, 0, 0.4),
                0 0 0 1px rgba(71, 85, 105, 0.3),
                inset 0 1px 0 rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(71, 85, 105, 0.3);
            backdrop-filter: blur(20px) saturate(180%);
            overflow: hidden;
            display: flex;
            flex-direction: column;
            position: relative;
        }
        
        .workspace::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 1px;
            background: linear-gradient(90deg, 
                transparent 0%, 
                rgba(6, 182, 212, 0.3) 50%, 
                transparent 100%);
            pointer-events: none;
        }
        
        .tab-content {
            display: none;
            flex: 1;
            overflow-y: auto;
            padding: 20px;
            opacity: 0;
            transform: translateY(10px);
            transition: opacity 0.3s ease, transform 0.3s ease;
        }
        
        .tab-content.active {
            display: flex;
            flex-direction: column;
            opacity: 1;
            transform: translateY(0);
            animation: fadeInUp 0.4s ease-out;
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(15px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .content-header {
            font-size: 24px;
            font-weight: 700;
            background: linear-gradient(135deg, #06b6d4 0%, #22d3ee 50%, #3b82f6 100%);
            background-size: 200% 200%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 24px;
            animation: headerGradientShift 4s ease infinite;
            text-shadow: 0 0 30px rgba(6, 182, 212, 0.3);
            letter-spacing: -0.5px;
        }
        
        @keyframes headerGradientShift {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }
        
        .terminal-container {
            flex: 1;
            background: 
                radial-gradient(ellipse at center, rgba(6, 182, 212, 0.03) 0%, transparent 70%),
                #0a0f1a;
            border-radius: 12px;
            padding: 16px;
            border: 1px solid rgba(71, 85, 105, 0.4);
            box-shadow: 
                inset 0 2px 4px rgba(0, 0, 0, 0.3),
                0 0 0 1px rgba(6, 182, 212, 0.1);
            display: flex;
            flex-direction: column;
            font-family: 'Consolas', 'Monaco', monospace;
            font-size: 13px;
            overflow: hidden;
            position: relative;
        }
        
        .terminal-overlay-logo {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 288px;
            height: 288px;
            pointer-events: none;
            z-index: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0;
            padding: 0;
        }
        
        .terminal-overlay-logo .logo-main {
            position: relative;
            width: 288px;
            height: 288px;
            object-fit: contain;
            opacity: 0.15;
            filter: drop-shadow(0 0 20px rgba(6, 182, 212, 0.4)) drop-shadow(0 0 40px rgba(34, 211, 238, 0.2)) brightness(1.1);
            animation: logoPulse 6s ease-in-out infinite;
            margin: auto;
        }
        
        .terminal-overlay-logo img {
            position: relative;
            width: 288px;
            height: 288px;
            object-fit: contain;
            opacity: 0.25;
            filter: drop-shadow(0 0 20px rgba(6, 182, 212, 0.4)) drop-shadow(0 0 40px rgba(34, 211, 238, 0.2)) brightness(1.1);
            animation: logoPulse 6s ease-in-out infinite;
            display: block !important;
            margin: 0 auto;
        }
        
        @keyframes logoPulse {
            0%, 100% { 
                transform: scale(1);
                opacity: 0.20;
                filter: drop-shadow(0 0 20px rgba(6, 182, 212, 0.2));
            }
            50% { 
                transform: scale(1.03);
                opacity: 0.30;
                filter: drop-shadow(0 0 30px rgba(34, 211, 238, 0.4));
            }
        }
        
        .terminal-output {
            flex: 1;
            background: transparent;
            color: #e2e8f0;
            overflow-y: auto;
            padding: 12px;
            line-height: 1.6;
            white-space: pre-wrap;
            word-wrap: break-word;
            position: relative;
            z-index: 2;
        }
        
        .terminal-output .info {
            color: #60a5fa;
        }
        
        .terminal-output .success {
            color: #34d399;
        }
        
        .terminal-output .error {
            color: #f87171;
        }
        
        .terminal-output .warning {
            color: #fbbf24;
        }
        
        .terminal-output .debug {
            color: #94a3b8;
        }
        
        .chat-input-container {
            margin-top: 12px;
            display: flex;
            gap: 8px;
        }
        
        .chat-input {
            flex: 1;
            background: 
                linear-gradient(135deg, rgba(15, 23, 42, 0.9) 0%, rgba(30, 41, 59, 0.9) 100%);
            border: 1px solid rgba(71, 85, 105, 0.5);
            border-radius: 10px;
            padding: 12px 16px;
            color: #e2e8f0;
            font-family: 'Consolas', monospace;
            font-size: 13px;
            resize: none;
            min-height: 60px;
            max-height: 120px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.2);
        }
        
        .chat-input:focus {
            outline: none;
            border-color: #06b6d4;
            box-shadow: 
                0 0 0 3px rgba(6, 182, 212, 0.15),
                inset 0 2px 4px rgba(0, 0, 0, 0.2),
                0 0 20px rgba(6, 182, 212, 0.1);
            background: 
                linear-gradient(135deg, rgba(15, 23, 42, 0.95) 0%, rgba(30, 41, 59, 0.95) 100%);
        }
        
        .chat-input::placeholder {
            color: #64748b;
            opacity: 0.7;
        }
        
        .btn-send {
            padding: 12px 24px;
            background: linear-gradient(135deg, #1e40af 0%, #3b82f6 50%, #06b6d4 100%);
            background-size: 200% 200%;
            border: none;
            border-radius: 10px;
            color: #ffffff;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 
                0 4px 12px rgba(59, 130, 246, 0.4),
                0 0 0 1px rgba(255, 255, 255, 0.1) inset;
            position: relative;
            overflow: hidden;
        }
        
        .btn-send::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transition: left 0.5s;
        }
        
        .btn-send:hover::before {
            left: 100%;
        }
        
        .btn-send:hover {
            transform: translateY(-2px);
            background-position: 100% 50%;
            box-shadow: 
                0 6px 20px rgba(59, 130, 246, 0.6),
                0 0 0 1px rgba(255, 255, 255, 0.2) inset;
        }
        
        .btn-send:active {
            transform: translateY(0);
        }
        
        .details-panel {
            width: 320px;
            background: 
                linear-gradient(180deg, rgba(15, 23, 42, 0.95) 0%, rgba(30, 41, 59, 0.95) 100%),
                linear-gradient(135deg, rgba(6, 182, 212, 0.05) 0%, transparent 50%);
            border-radius: 16px;
            padding: 20px;
            box-shadow: 
                0 8px 32px rgba(0, 0, 0, 0.4),
                0 0 0 1px rgba(71, 85, 105, 0.3),
                inset 0 1px 0 rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(71, 85, 105, 0.3);
            backdrop-filter: blur(20px) saturate(180%);
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            gap: 16px;
            position: relative;
        }
        
        .details-panel::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 1px;
            background: linear-gradient(90deg, 
                transparent 0%, 
                rgba(6, 182, 212, 0.3) 50%, 
                transparent 100%);
            pointer-events: none;
        }
        
        .details-section {
            flex: 1;
            display: flex;
            flex-direction: column;
            min-height: 0;
        }
        
        .details-header {
            font-size: 16px;
            font-weight: 700;
            color: #06b6d4;
            margin-bottom: 12px;
            padding-bottom: 8px;
            border-bottom: 2px solid rgba(6, 182, 212, 0.3);
        }
        
        .details-content {
            flex: 1;
            color: #cbd5e1;
            font-size: 12px;
            line-height: 1.6;
            white-space: pre-wrap;
            overflow-y: auto;
            padding: 8px;
            background: rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            font-family: 'Consolas', 'Monaco', monospace;
        }
        
        .debug-log {
            flex: 1;
            color: #94a3b8;
            font-size: 11px;
            line-height: 1.5;
            white-space: pre-wrap;
            overflow-y: auto;
            padding: 8px;
            background: rgba(0, 0, 0, 0.3);
            border-radius: 8px;
            font-family: 'Consolas', 'Monaco', monospace;
            max-height: 100%;
        }
        
        .debug-log-entry {
            margin-bottom: 4px;
            padding: 2px 0;
        }
        
        .debug-log-entry.error {
            color: #f87171;
        }
        
        .debug-log-entry.warning {
            color: #fbbf24;
        }
        
        .debug-log-entry.info {
            color: #60a5fa;
        }
        
        .debug-log-entry.debug {
            color: #94a3b8;
        }
        
        /* Scrollbar Styling */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }
        
        ::-webkit-scrollbar-track {
            background: rgba(15, 23, 42, 0.5);
            border-radius: 4px;
        }
        
        ::-webkit-scrollbar-thumb {
            background: linear-gradient(180deg, #475569 0%, #64748b 100%);
            border-radius: 4px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(180deg, #64748b 0%, #06b6d4 100%);
            box-shadow: 0 0 10px rgba(6, 182, 212, 0.5);
        }
        
        ::-webkit-scrollbar-thumb:active {
            background: linear-gradient(180deg, #06b6d4 0%, #22d3ee 100%);
        }
        
        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .fade-in {
            animation: fadeIn 0.3s ease-out;
        }
        
        /* Glass morphism effects */
        .glass {
            background: rgba(15, 23, 42, 0.6);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        /* Enhanced input and select styling */
        input[type="text"],
        input[type="file"],
        select,
        textarea {
            background: 
                linear-gradient(135deg, rgba(15, 23, 42, 0.9) 0%, rgba(30, 41, 59, 0.9) 100%);
            border: 1px solid rgba(71, 85, 105, 0.5);
            border-radius: 8px;
            padding: 10px 12px;
            color: #e2e8f0;
            font-size: 13px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.2);
        }
        
        input[type="text"]:focus,
        input[type="file"]:focus,
        select:focus,
        textarea:focus {
            outline: none;
            border-color: #06b6d4;
            box-shadow: 
                0 0 0 3px rgba(6, 182, 212, 0.15),
                inset 0 2px 4px rgba(0, 0, 0, 0.2),
                0 0 15px rgba(6, 182, 212, 0.1);
            background: 
                linear-gradient(135deg, rgba(15, 23, 42, 0.95) 0%, rgba(30, 41, 59, 0.95) 100%);
        }
        
        input[type="text"]:hover,
        select:hover,
        textarea:hover {
            border-color: rgba(71, 85, 105, 0.7);
            box-shadow: 
                inset 0 2px 4px rgba(0, 0, 0, 0.2),
                0 0 10px rgba(6, 182, 212, 0.05);
        }
        
        /* Checkbox styling */
        input[type="checkbox"] {
            width: 18px;
            height: 18px;
            cursor: pointer;
            accent-color: #06b6d4;
            filter: drop-shadow(0 0 4px rgba(6, 182, 212, 0.3));
        }
        
        input[type="checkbox"]:hover {
            filter: drop-shadow(0 0 6px rgba(6, 182, 212, 0.5));
        }
        
        /* File info boxes */
        div[id*="file"],
        div[id*="status"],
        div[id*="info"] {
            background: 
                linear-gradient(135deg, rgba(15, 23, 42, 0.7) 0%, rgba(30, 41, 59, 0.7) 100%);
            border: 1px solid rgba(71, 85, 105, 0.4);
            border-radius: 8px;
            padding: 12px;
            transition: all 0.3s ease;
            box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.2);
        }
        
        div[id*="file"]:hover,
        div[id*="status"]:hover,
        div[id*="info"]:hover {
            border-color: rgba(6, 182, 212, 0.3);
            box-shadow: 
                inset 0 2px 4px rgba(0, 0, 0, 0.2),
                0 0 15px rgba(6, 182, 212, 0.1);
        }
        
        /* Settings Tab Buttons */
        .settings-tab-btn {
            padding: 10px 16px;
            background: rgba(51, 65, 85, 0.4);
            border: 1px solid rgba(71, 85, 105, 0.3);
            color: #cbd5e1;
            font-size: 13px;
            font-weight: 600;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
        }
        
        .settings-tab-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(6, 182, 212, 0.2), transparent);
            transition: left 0.4s;
        }
        
        .settings-tab-btn:hover::before {
            left: 100%;
        }
        
        .settings-tab-btn:hover {
            background: rgba(6, 182, 212, 0.2);
            border-color: rgba(6, 182, 212, 0.5);
            color: #22d3ee;
        }
        
        .settings-tab-btn.active {
            background: linear-gradient(135deg, #1e40af 0%, #3b82f6 50%, #06b6d4 100%);
            border-color: rgba(59, 130, 246, 0.6);
            color: #ffffff;
            box-shadow: 0 2px 8px rgba(59, 130, 246, 0.3);
        }
        
        /* Settings Panels */
        .settings-panel {
            display: none;
        }
        
        .settings-panel.active {
            display: block;
            animation: fadeInUp 0.3s ease-out;
        }
    </style>
</head>
<body>
    <div class="app-container">
        <!-- World-Class Header Banner -->
        <div class="header">
            <div class="header-code-overlay">
                <div class="code-easter-egg">
                    <span class="code-line">def hypercube_4d():</span>
                    <span class="code-line">class FourDLLM:</span>
                </div>
            </div>
            <div class="header-content">
                <div class="logo-container">
                    <img src="HEADER_LOGO_PLACEHOLDER" alt="RomanAILabs Logo" class="logo-img" style="width: 101px; height: 101px; object-fit: contain;" onerror="console.error('Failed to load header logo:', this.src);">
                    <svg class="logo-svg" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" style="display: none !important;">
                        <defs>
                            <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                                <stop offset="0%" style="stop-color:#06b6d4;stop-opacity:1" />
                                <stop offset="50%" style="stop-color:#22d3ee;stop-opacity:1" />
                                <stop offset="100%" style="stop-color:#06b6d4;stop-opacity:1" />
                            </linearGradient>
                            <linearGradient id="logoGradient2" x1="0%" y1="0%" x2="100%" y2="100%">
                                <stop offset="0%" style="stop-color:#3b82f6;stop-opacity:0.8" />
                                <stop offset="100%" style="stop-color:#06b6d4;stop-opacity:0.8" />
                            </linearGradient>
                            <filter id="glow">
                                <feGaussianBlur stdDeviation="4" result="coloredBlur"/>
                                <feMerge>
                                    <feMergeNode in="coloredBlur"/>
                                    <feMergeNode in="SourceGraphic"/>
                                </feMerge>
                            </filter>
                            <filter id="shadow">
                                <feGaussianBlur in="SourceAlpha" stdDeviation="2"/>
                                <feOffset dx="2" dy="2" result="offsetblur"/>
                                <feComponentTransfer>
                                    <feFuncA type="linear" slope="0.3"/>
                                </feComponentTransfer>
                                <feMerge>
                                    <feMergeNode/>
                                    <feMergeNode in="SourceGraphic"/>
                                </feMerge>
                            </filter>
                        </defs>
                        <!-- 4D Cube with 3D effect -->
                        <g filter="url(#shadow)">
                            <!-- Main cube -->
                            <rect x="20" y="20" width="60" height="60" rx="10" fill="url(#logoGradient)" filter="url(#glow)" opacity="0.95"/>
                            <!-- Top face (3D effect) -->
                            <polygon points="20,20 30,10 90,10 80,20" fill="url(#logoGradient2)" opacity="0.7"/>
                            <!-- Right face (3D effect) -->
                            <polygon points="80,20 90,10 90,70 80,80" fill="url(#logoGradient2)" opacity="0.5"/>
                            <!-- Inner border -->
                            <rect x="25" y="25" width="50" height="50" rx="6" fill="none" stroke="#ffffff" stroke-width="1.5" opacity="0.4"/>
                            <!-- Corner highlights -->
                            <circle cx="30" cy="30" r="3" fill="#ffffff" opacity="0.9"/>
                            <circle cx="70" cy="30" r="3" fill="#ffffff" opacity="0.9"/>
                            <circle cx="30" cy="70" r="3" fill="#ffffff" opacity="0.9"/>
                            <circle cx="70" cy="70" r="3" fill="#ffffff" opacity="0.9"/>
                            <!-- 4D Text -->
                            <text x="50" y="58" font-family="Arial, sans-serif" font-size="28" font-weight="900" fill="#ffffff" text-anchor="middle" opacity="1" filter="url(#glow)">4D</text>
                        </g>
                    </svg>
                    <div class="logo-text-container">
                        <div class="logo-main-text">4DLLM Studio by RomanAILabs</div>
                        <div class="logo-email">romanailabs@gmail.com</div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="main-content">
            <div class="sidebar">
                <div class="sidebar-section">
                    <div class="section-title">Recent Files</div>
                    <div id="recent-files" style="background: rgba(15, 23, 42, 0.5); border-radius: 8px; padding: 12px; min-height: 100px; color: #64748b; font-size: 12px;">
                        No recent files
                    </div>
                </div>
                
                <div class="sidebar-section">
                    <div class="section-title">Files</div>
                    <button class="btn-primary" onclick="window.bridge.open4dllm()">📂 Open .4dllm</button>
                    <button class="btn-secondary" onclick="window.bridge.openGguf()">📂 Open .gguf</button>
                </div>
                
                <div class="sidebar-section">
                    <div class="section-title">Profiles</div>
                    <select id="profile-select" style="width: 100%; padding: 10px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 8px; color: #e2e8f0; margin-bottom: 12px;" onchange="window.bridge.selectProfile(this.value)">
                        <option value="Default">Default</option>
                        <option value="High Performance">High Performance</option>
                        <option value="Low Memory">Low Memory</option>
                    </select>
                    <div id="safety-badge" style="padding: 10px; background: rgba(51, 65, 85, 0.6); border-radius: 8px; text-align: center; font-weight: 600; color: #e2e8f0; margin-bottom: 20px;">SAFE</div>
                </div>
                
                <div class="sidebar-section">
                    <div class="section-title">Navigation</div>
                    <div class="nav-tabs">
                <button class="nav-tab active" data-tab="run">▶ Run</button>
                <button class="nav-tab" data-tab="train">🎓 Train</button>
                <button class="nav-tab" data-tab="build">🔨 Build</button>
                <button class="nav-tab" data-tab="editor">✏️ Editor</button>
                <button class="nav-tab" data-tab="inspect">🔍 Inspect</button>
                <button class="nav-tab" data-tab="scripts">📜 Scripts</button>
                <button class="nav-tab" data-tab="settings">⚙️ Settings</button>
                    </div>
                </div>
            </div>
            
            <div class="workspace">
                <div id="tab-run" class="tab-content active">
                    <div class="content-header">Run 4DLLM/GGUF Models</div>
                    <div style="margin-bottom: 20px;">
                        <div style="font-size: 14px; color: #94a3b8; margin-bottom: 8px;">Selected File:</div>
                        <div id="selected-file" style="padding: 12px; background: rgba(15, 23, 42, 0.6); border-radius: 8px; color: #cbd5e1; min-height: 40px; display: flex; align-items: center;">No file selected<br><span style="font-size: 11px; color: #64748b;">(Supports .4dllm and .gguf)</span></div>
                    </div>
                    
                    <div style="display: flex; gap: 12px; margin-bottom: 20px;">
                        <button class="btn-primary" onclick="window.bridge.selectFile()">📂 Select</button>
                        <button class="btn-primary" onclick="window.bridge.runModel()">▶ Run</button>
                        <button class="btn-secondary" onclick="window.bridge.stopModel()">■ Stop</button>
                        <button class="btn-secondary" onclick="window.bridge.copyCommand()">📋 Copy Cmd</button>
                    </div>
                    
                    <div id="safety-warning" style="padding: 16px; background: rgba(251, 191, 36, 0.1); border: 1px solid rgba(251, 191, 36, 0.3); border-radius: 10px; margin-bottom: 16px; display: none;">
                        <div style="color: #fbbf24; font-weight: 600; margin-bottom: 8px;">⚠️ Safety Warning</div>
                        <div id="warning-text" style="color: #fbbf24; font-size: 13px;"></div>
                        <label style="display: flex; align-items: center; gap: 8px; margin-top: 12px; color: #e2e8f0; cursor: pointer;">
                            <input type="checkbox" id="unsafe-check" onchange="window.bridge.toggleUnsafe(this.checked)">
                            <span>Allow Unsafe Modules</span>
                        </label>
                    </div>
                    
                    <div class="terminal-container">
                        <div class="terminal-overlay-logo">
                            <img src="TERMINAL_LOGO_PLACEHOLDER" alt="RomanAILabs Logo" style="width: 288px; height: 288px; object-fit: contain;" onerror="console.error('Failed to load terminal logo:', this.src);">
                        </div>
                        <div class="terminal-output" id="terminal-output"></div>
                        <div class="chat-input-container">
                            <textarea class="chat-input" id="chat-input" placeholder="Type your message here... (Enter to send, Shift+Enter for newline)" onkeydown="handleChatKey(event)"></textarea>
                            <button class="btn-send" onclick="sendChatMessage()">📤 Send</button>
                        </div>
                    </div>
                </div>
                
                <div id="tab-train" class="tab-content">
                    <div class="content-header">🎓 Train 4DLLM/GGUF Model</div>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                        <!-- Left Column: File Selection -->
                        <div style="display: flex; flex-direction: column; gap: 16px;">
                            <div>
                                <div style="font-size: 14px; color: #94a3b8; margin-bottom: 8px; font-weight: 600;">📂 Input Model File</div>
                                <div id="train-input-file" style="padding: 12px; background: rgba(15, 23, 42, 0.6); border-radius: 8px; color: #cbd5e1; margin-bottom: 12px; min-height: 40px; display: flex; align-items: center;">No file selected<br><span style="font-size: 11px; color: #64748b;">(Supports .4dllm and .gguf)</span></div>
                                <div style="display: flex; gap: 8px; margin-bottom: 16px;">
                                    <button class="btn-primary" onclick="window.bridge.selectTrainInputFile()" style="flex: 1;">📂 Select Model File</button>
                                    <button class="btn-secondary" id="train-load-btn" onclick="window.bridge.loadTrainModel()" style="flex: 1;" disabled>🔍 Load Model</button>
                                </div>
                                <div id="train-model-status" style="padding: 8px; background: rgba(15, 23, 42, 0.4); border-radius: 6px; color: #94a3b8; font-size: 12px; margin-bottom: 8px; display: none;"></div>
                            </div>
                            
                            <div>
                                <div style="font-size: 14px; color: #94a3b8; margin-bottom: 8px; font-weight: 600;">📊 Training Dataset</div>
                                <div id="train-dataset-file" style="padding: 12px; background: rgba(15, 23, 42, 0.6); border-radius: 8px; color: #cbd5e1; margin-bottom: 12px; min-height: 40px; display: flex; align-items: center;">No dataset selected<br><span style="font-size: 11px; color: #64748b;">(JSON, JSONL, or TXT format)</span></div>
                                <button class="btn-primary" onclick="window.bridge.selectTrainDataset()" style="margin-bottom: 16px;">📊 Select Dataset</button>
                            </div>
                            
                            <div>
                                <div style="font-size: 14px; color: #94a3b8; margin-bottom: 8px; font-weight: 600;">💾 Output 4DLLM File</div>
                                <div id="train-output-file" style="padding: 12px; background: rgba(15, 23, 42, 0.6); border-radius: 8px; color: #cbd5e1; margin-bottom: 12px; min-height: 40px; display: flex; align-items: center;">Auto-generated from input</div>
                                <button class="btn-secondary" onclick="window.bridge.selectTrainOutputFile()">💾 Choose Output Path</button>
                            </div>
                        </div>
                        
                        <!-- Right Column: Training Configuration -->
                        <div style="display: flex; flex-direction: column; gap: 16px;">
                            <div>
                                <div style="font-size: 14px; color: #94a3b8; margin-bottom: 8px; font-weight: 600;">⚙️ Training Preset</div>
                                <select id="train-preset" style="width: 100%; padding: 12px; background: rgba(15, 23, 42, 0.6); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 8px; color: #e2e8f0; margin-bottom: 16px;" onchange="window.bridge.loadTrainPreset(this.value)">
                                    <option value="Quick Fine-Tune">Quick Fine-Tune</option>
                                    <option value="Standard Training" selected>Standard Training</option>
                                    <option value="Advanced Training">Advanced Training</option>
                                </select>
                            </div>
                            
                            <div style="background: rgba(15, 23, 42, 0.4); border-radius: 12px; padding: 16px; border: 1px solid rgba(71, 85, 105, 0.3);">
                                <div style="font-size: 14px; color: #06b6d4; margin-bottom: 12px; font-weight: 600;">📋 Training Parameters</div>
                                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                                    <div>
                                        <label style="display: block; font-size: 12px; color: #94a3b8; margin-bottom: 4px;">Epochs</label>
                                        <input type="text" id="train-epochs" value="5" style="width: 100%; padding: 8px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 6px; color: #e2e8f0;">
                                    </div>
                                    <div>
                                        <label style="display: block; font-size: 12px; color: #94a3b8; margin-bottom: 4px;">Learning Rate</label>
                                        <input type="text" id="train-learning-rate" value="0.0001" style="width: 100%; padding: 8px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 6px; color: #e2e8f0;">
                                    </div>
                                    <div>
                                        <label style="display: block; font-size: 12px; color: #94a3b8; margin-bottom: 4px;">Batch Size</label>
                                        <input type="text" id="train-batch-size" value="8" style="width: 100%; padding: 8px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 6px; color: #e2e8f0;">
                                    </div>
                                    <div>
                                        <label style="display: block; font-size: 12px; color: #94a3b8; margin-bottom: 4px;">Context Size</label>
                                        <input type="text" id="train-context-size" value="4096" style="width: 100%; padding: 8px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 6px; color: #e2e8f0;">
                                    </div>
                                    <div>
                                        <label style="display: block; font-size: 12px; color: #94a3b8; margin-bottom: 4px;">LoRA Rank (r)</label>
                                        <input type="text" id="train-lora-r" value="16" style="width: 100%; padding: 8px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 6px; color: #e2e8f0;">
                                    </div>
                                    <div>
                                        <label style="display: block; font-size: 12px; color: #94a3b8; margin-bottom: 4px;">LoRA Alpha</label>
                                        <input type="text" id="train-lora-alpha" value="32" style="width: 100%; padding: 8px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 6px; color: #e2e8f0;">
                                    </div>
                                    <div style="grid-column: 1 / -1;">
                                        <label style="display: block; font-size: 12px; color: #94a3b8; margin-bottom: 4px;">LoRA Dropout</label>
                                        <input type="text" id="train-lora-dropout" value="0.1" style="width: 100%; padding: 8px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 6px; color: #e2e8f0;">
                                    </div>
                                </div>
                            </div>
                            
                            <div style="display: flex; gap: 12px; margin-top: 8px;">
                                <button class="btn-primary" onclick="window.bridge.startTraining()" id="train-start-btn" style="flex: 1;">🚀 Start Training</button>
                                <button class="btn-secondary" onclick="window.bridge.stopTraining()" id="train-stop-btn" style="flex: 1; display: none;">■ Stop Training</button>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Training Progress & Stats -->
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                        <div style="background: rgba(15, 23, 42, 0.4); border-radius: 12px; padding: 16px; border: 1px solid rgba(71, 85, 105, 0.3);">
                            <div style="font-size: 14px; color: #06b6d4; margin-bottom: 12px; font-weight: 600;">📊 Training Statistics</div>
                            <div id="train-stats" style="color: #cbd5e1; font-family: 'Consolas', monospace; font-size: 13px; line-height: 1.8;">
                                <div>Epoch: <span style="color: #06b6d4;">-</span></div>
                                <div>Loss: <span style="color: #06b6d4;">-</span></div>
                                <div>Time: <span style="color: #06b6d4;">-</span></div>
                                <div>Status: <span style="color: #64748b;">Ready</span></div>
                            </div>
                        </div>
                        
                        <div style="background: rgba(15, 23, 42, 0.4); border-radius: 12px; padding: 16px; border: 1px solid rgba(71, 85, 105, 0.3);">
                            <div style="font-size: 14px; color: #06b6d4; margin-bottom: 12px; font-weight: 600;">📈 Progress</div>
                            <div style="background: rgba(0, 0, 0, 0.3); border-radius: 8px; height: 24px; overflow: hidden; margin-bottom: 8px; position: relative;">
                                <div id="train-progress-bar" style="background: linear-gradient(90deg, #06b6d4 0%, #22d3ee 100%); height: 100%; width: 0%; transition: width 0.3s ease; box-shadow: 0 0 10px rgba(6, 182, 212, 0.5);"></div>
                            </div>
                            <div id="train-progress-text" style="color: #94a3b8; font-size: 12px; text-align: center;">Not started</div>
                        </div>
                    </div>
                    
                    <!-- Training Logs -->
                    <div>
                        <div style="font-size: 14px; color: #06b6d4; margin-bottom: 12px; font-weight: 600;">📝 Training Log</div>
                        <div class="terminal-container" style="min-height: 300px;">
                            <div class="terminal-overlay-logo">
                                <img src="TERMINAL_LOGO_PLACEHOLDER" alt="RomanAILabs Logo" style="width: 288px; height: 288px; object-fit: contain;" onerror="console.error('Failed to load terminal logo:', this.src);">
                            </div>
                            <div class="terminal-output" id="train-output"></div>
                        </div>
                    </div>
                </div>
                
                <div id="tab-build" class="tab-content">
                    <div class="content-header">Build 4DLLM Package</div>
                    <div style="margin-bottom: 20px;">
                        <div style="font-size: 14px; color: #94a3b8; margin-bottom: 8px;">GGUF Model:</div>
                        <div id="build-gguf-file" style="padding: 12px; background: rgba(15, 23, 42, 0.6); border-radius: 8px; color: #cbd5e1; margin-bottom: 12px;">No GGUF selected</div>
                        <button class="btn-primary" onclick="window.bridge.selectGguf()">📂 Select GGUF File</button>
                    </div>
                    <div style="margin-bottom: 20px;">
                        <div style="font-size: 14px; color: #94a3b8; margin-bottom: 8px;">Modules Folder:</div>
                        <div style="display: flex; gap: 8px; margin-bottom: 12px;">
                            <button class="btn-secondary" onclick="window.bridge.loadModules()">📁 Load from modules/</button>
                            <div id="modules-status" style="padding: 8px; color: #94a3b8; font-size: 12px; align-self: center;">No modules loaded</div>
                        </div>
                    </div>
                    <div style="margin-bottom: 20px;">
                        <div style="font-size: 14px; color: #94a3b8; margin-bottom: 8px;">Scripts:</div>
                        <div id="scripts-list" style="max-height: 300px; overflow-y: auto; background: rgba(15, 23, 42, 0.6); border-radius: 8px; padding: 12px; margin-bottom: 12px; min-height: 100px;">
                            <div style="color: #64748b; font-size: 12px;">No scripts added. Click 'Load from modules/' or 'Add Script'</div>
                        </div>
                        <button class="btn-secondary" onclick="addScriptDialog()" style="margin-bottom: 8px;">➕ Add Script</button>
                    </div>
                    <div style="margin-bottom: 20px;">
                        <div style="font-size: 14px; color: #94a3b8; margin-bottom: 8px;">Output Path:</div>
                        <input type="text" id="build-output-path" placeholder="Output .4dllm path (optional)" style="width: 100%; padding: 12px; background: rgba(15, 23, 42, 0.6); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 8px; color: #e2e8f0; margin-bottom: 12px;">
                        <div style="display: flex; gap: 12px; margin-bottom: 12px;">
                            <label style="color: #cbd5e1; font-size: 13px; display: flex; align-items: center; gap: 8px; cursor: pointer;">
                                <input type="checkbox" id="compress-scripts" checked style="cursor: pointer;">
                                Compress Scripts
                            </label>
                            <label style="color: #cbd5e1; font-size: 13px; display: flex; align-items: center; gap: 8px; cursor: pointer;">
                                <input type="checkbox" id="compress-metadata" checked style="cursor: pointer;">
                                Compress Metadata
                            </label>
                        </div>
                    </div>
                    <button class="btn-primary" onclick="window.bridge.buildPackage()">🔨 Build Package</button>
                    <div id="build-status" style="margin-top: 16px; color: #94a3b8; font-size: 13px;">Ready</div>
                </div>
                
                <div id="tab-editor" class="tab-content">
                    <div class="content-header">Edit GGUF / 4DLLM File</div>
                    <div style="margin-bottom: 20px;">
                        <div style="display: flex; gap: 12px; margin-bottom: 12px;">
                            <button class="btn-primary" onclick="window.bridge.loadEditorFile()">📂 Load File (.gguf or .4dllm)</button>
                            <button class="btn-secondary" onclick="window.bridge.saveEditorFile()">💾 Save Changes</button>
                            <button class="btn-secondary" onclick="window.bridge.createBackup()">📋 Create Backup</button>
                        </div>
                        <div id="editor-file-info" style="padding: 12px; background: rgba(15, 23, 42, 0.6); border-radius: 8px; color: #cbd5e1; margin-bottom: 12px;">No file loaded</div>
                    </div>
                    <div style="display: flex; gap: 12px; margin-bottom: 20px;">
                        <button class="btn-secondary" id="easy-mode-btn" onclick="switchEditorMode('easy')">📝 Easy Mode</button>
                        <button class="btn-secondary" id="advanced-mode-btn" onclick="switchEditorMode('advanced')">🔧 Advanced Mode</button>
                    </div>
                    <div id="editor-content" style="flex: 1; overflow-y: auto; min-height: 400px;">
                        <div style="padding: 40px; text-align: center; color: #64748b;">
                            <div style="font-size: 18px; margin-bottom: 12px;">Load a file to start editing</div>
                            <div style="font-size: 13px;">Supports both .gguf and .4dllm files</div>
                        </div>
                    </div>
                </div>
                
                <div id="tab-inspect" class="tab-content">
                    <div class="content-header">Inspect File (GGUF / 4DLLM)</div>
                    <div style="display: flex; gap: 12px; margin-bottom: 20px;">
                        <button class="btn-primary" onclick="window.bridge.inspectFile()">📂 Load File (.gguf or .4dllm)</button>
                        <button class="btn-secondary" onclick="window.bridge.refreshInspect()">🔄 Refresh</button>
                    </div>
                    <div class="terminal-container">
                        <div class="terminal-overlay-logo">
                            <img src="TERMINAL_LOGO_PLACEHOLDER" alt="RomanAILabs Logo" style="width: 288px; height: 288px; object-fit: contain;" onerror="console.error('Failed to load terminal logo:', this.src);">
                        </div>
                        <div class="terminal-output" id="inspect-output"></div>
                    </div>
                </div>
                
                <div id="tab-scripts" class="tab-content">
                    <div class="content-header">Scripts & Modules</div>
                    <div style="margin-bottom: 20px;">
                        <input type="text" id="script-search" placeholder="Search scripts..." style="width: 100%; padding: 12px; background: rgba(15, 23, 42, 0.6); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 8px; color: #e2e8f0;">
                    </div>
                    <div class="terminal-container">
                        <div class="terminal-overlay-logo">
                            <img src="TERMINAL_LOGO_PLACEHOLDER" alt="RomanAILabs Logo" style="width: 288px; height: 288px; object-fit: contain;" onerror="console.error('Failed to load terminal logo:', this.src);">
                        </div>
                        <div class="terminal-output" id="scripts-output">Load a .4dllm file to view scripts</div>
                    </div>
                </div>
                
                <div id="tab-settings" class="tab-content">
                    <div class="content-header">⚙️ Settings</div>
                    
                    <!-- Settings Navigation Tabs -->
                    <div style="display: flex; gap: 8px; margin-bottom: 24px; border-bottom: 2px solid rgba(71, 85, 105, 0.3); padding-bottom: 12px;">
                        <button class="settings-tab-btn active" data-settings-tab="profiles" onclick="switchSettingsTab('profiles')">📋 Profiles</button>
                        <button class="settings-tab-btn" data-settings-tab="general" onclick="switchSettingsTab('general')">⚙️ General</button>
                        <button class="settings-tab-btn" data-settings-tab="performance" onclick="switchSettingsTab('performance')">🚀 Performance</button>
                        <button class="settings-tab-btn" data-settings-tab="ui" onclick="switchSettingsTab('ui')">🎨 Interface</button>
                        <button class="settings-tab-btn" data-settings-tab="advanced" onclick="switchSettingsTab('advanced')">🔧 Advanced</button>
                    </div>
                    
                    <!-- Profiles Tab -->
                    <div id="settings-profiles" class="settings-panel active">
                        <div style="margin-bottom: 24px;">
                            <div style="font-size: 18px; font-weight: 700; color: #06b6d4; margin-bottom: 16px;">📋 Profile Management</div>
                            
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                                <div>
                                    <label style="display: block; font-size: 13px; color: #94a3b8; margin-bottom: 8px; font-weight: 600;">Current Profile</label>
                                    <select id="settings-profile-select" style="width: 100%; padding: 12px; background: rgba(15, 23, 42, 0.6); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 8px; color: #e2e8f0; margin-bottom: 16px;" onchange="window.bridge.selectProfile(this.value)">
                                        <option value="Default">Default</option>
                                        <option value="High Performance">High Performance</option>
                                        <option value="Low Memory">Low Memory</option>
                                    </select>
                                </div>
                                <div>
                                    <label style="display: block; font-size: 13px; color: #94a3b8; margin-bottom: 8px; font-weight: 600;">Actions</label>
                                    <div style="display: flex; gap: 8px;">
                                        <button class="btn-secondary" onclick="createNewProfile()" style="flex: 1;">➕ New Profile</button>
                                        <button class="btn-secondary" onclick="duplicateProfile()" style="flex: 1;">📋 Duplicate</button>
                                        <button class="btn-secondary" onclick="deleteProfile()" style="flex: 1; background: rgba(239, 68, 68, 0.2); border-color: rgba(239, 68, 68, 0.5);">🗑️ Delete</button>
                                    </div>
                                </div>
                            </div>
                            
                            <div style="background: rgba(15, 23, 42, 0.4); border-radius: 12px; padding: 20px; border: 1px solid rgba(71, 85, 105, 0.3); margin-bottom: 20px;">
                                <div style="font-size: 14px; color: #06b6d4; margin-bottom: 16px; font-weight: 600;">Profile Parameters</div>
                                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                                    <div>
                                        <label style="display: block; font-size: 12px; color: #94a3b8; margin-bottom: 6px;">Context Size (n_ctx)</label>
                                        <input type="text" id="profile-n-ctx" placeholder="4096" style="width: 100%; padding: 10px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 6px; color: #e2e8f0;">
                                    </div>
                                    <div>
                                        <label style="display: block; font-size: 12px; color: #94a3b8; margin-bottom: 6px;">Threads</label>
                                        <input type="text" id="profile-threads" placeholder="4" style="width: 100%; padding: 10px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 6px; color: #e2e8f0;">
                                    </div>
                                    <div>
                                        <label style="display: block; font-size: 12px; color: #94a3b8; margin-bottom: 6px;">GPU Layers</label>
                                        <input type="text" id="profile-gpu-layers" placeholder="0" style="width: 100%; padding: 10px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 6px; color: #e2e8f0;">
                                    </div>
                                    <div>
                                        <label style="display: block; font-size: 12px; color: #94a3b8; margin-bottom: 6px;">Max Tokens</label>
                                        <input type="text" id="profile-max-tokens" placeholder="256" style="width: 100%; padding: 10px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 6px; color: #e2e8f0;">
                                    </div>
                                    <div>
                                        <label style="display: block; font-size: 12px; color: #94a3b8; margin-bottom: 6px;">Temperature</label>
                                        <input type="text" id="profile-temp" placeholder="0.7" style="width: 100%; padding: 10px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 6px; color: #e2e8f0;">
                                    </div>
                                    <div>
                                        <label style="display: block; font-size: 12px; color: #94a3b8; margin-bottom: 6px;">Backend</label>
                                        <select id="profile-backend" style="width: 100%; padding: 10px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 6px; color: #e2e8f0;">
                                            <option value="llama_cpp">llama_cpp</option>
                                            <option value="llama_cli">llama_cli</option>
                                        </select>
                                    </div>
                                </div>
                                <button class="btn-primary" onclick="saveProfile()" style="margin-top: 16px; width: 100%;">💾 Save Profile Changes</button>
                            </div>
                            
                            <div id="profile-display" style="padding: 16px; background: rgba(15, 23, 42, 0.6); border-radius: 8px; font-family: 'Consolas', monospace; font-size: 12px; white-space: pre-wrap; color: #94a3b8;">Current profile settings will be displayed here when a profile is selected.</div>
                        </div>
                    </div>
                    
                    <!-- General Settings Tab -->
                    <div id="settings-general" class="settings-panel">
                        <div style="font-size: 18px; font-weight: 700; color: #06b6d4; margin-bottom: 24px;">⚙️ General Settings</div>
                        
                        <div style="background: rgba(15, 23, 42, 0.4); border-radius: 12px; padding: 20px; border: 1px solid rgba(71, 85, 105, 0.3); margin-bottom: 20px;">
                            <div style="font-size: 14px; color: #06b6d4; margin-bottom: 16px; font-weight: 600;">Application Behavior</div>
                            <div style="display: flex; flex-direction: column; gap: 12px;">
                                <label style="display: flex; align-items: center; gap: 12px; cursor: pointer; padding: 10px; background: rgba(15, 23, 42, 0.3); border-radius: 8px;">
                                    <input type="checkbox" id="setting-auto-save" style="cursor: pointer;">
                                    <div>
                                        <div style="font-weight: 600; color: #e2e8f0;">Auto-save Settings</div>
                                        <div style="font-size: 11px; color: #94a3b8;">Automatically save settings when changed</div>
                                    </div>
                                </label>
                                <label style="display: flex; align-items: center; gap: 12px; cursor: pointer; padding: 10px; background: rgba(15, 23, 42, 0.3); border-radius: 8px;">
                                    <input type="checkbox" id="setting-confirm-exit" checked style="cursor: pointer;">
                                    <div>
                                        <div style="font-weight: 600; color: #e2e8f0;">Confirm Before Exit</div>
                                        <div style="font-size: 11px; color: #94a3b8;">Show confirmation dialog when closing the application</div>
                                    </div>
                                </label>
                                <label style="display: flex; align-items: center; gap: 12px; cursor: pointer; padding: 10px; background: rgba(15, 23, 42, 0.3); border-radius: 8px;">
                                    <input type="checkbox" id="setting-remember-files" checked style="cursor: pointer;">
                                    <div>
                                        <div style="font-weight: 600; color: #e2e8f0;">Remember Recent Files</div>
                                        <div style="font-size: 11px; color: #94a3b8;">Keep track of recently opened files</div>
                                    </div>
                                </label>
                                <label style="display: flex; align-items: center; gap: 12px; cursor: pointer; padding: 10px; background: rgba(15, 23, 42, 0.3); border-radius: 8px;">
                                    <input type="checkbox" id="setting-check-updates" checked style="cursor: pointer;">
                                    <div>
                                        <div style="font-weight: 600; color: #e2e8f0;">Check for Updates</div>
                                        <div style="font-size: 11px; color: #94a3b8;">Automatically check for application updates on startup</div>
                                    </div>
                                </label>
                            </div>
                        </div>
                        
                        <div style="background: rgba(15, 23, 42, 0.4); border-radius: 12px; padding: 20px; border: 1px solid rgba(71, 85, 105, 0.3); margin-bottom: 20px;">
                            <div style="font-size: 14px; color: #06b6d4; margin-bottom: 16px; font-weight: 600;">File Operations</div>
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                                <div>
                                    <label style="display: block; font-size: 12px; color: #94a3b8; margin-bottom: 6px;">Default Save Location</label>
                                    <input type="text" id="setting-default-save-path" placeholder="Leave empty for current directory" style="width: 100%; padding: 10px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 6px; color: #e2e8f0;">
                                </div>
                                <div>
                                    <label style="display: block; font-size: 12px; color: #94a3b8; margin-bottom: 6px;">Backup Location</label>
                                    <input type="text" id="setting-backup-path" placeholder="Leave empty for same as file" style="width: 100%; padding: 10px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 6px; color: #e2e8f0;">
                                </div>
                            </div>
                        </div>
                        
                        <div style="background: rgba(15, 23, 42, 0.4); border-radius: 12px; padding: 20px; border: 1px solid rgba(71, 85, 105, 0.3);">
                            <div style="font-size: 14px; color: #06b6d4; margin-bottom: 16px; font-weight: 600;">Language & Region</div>
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                                <div>
                                    <label style="display: block; font-size: 12px; color: #94a3b8; margin-bottom: 6px;">Language</label>
                                    <select id="setting-language" style="width: 100%; padding: 10px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 6px; color: #e2e8f0;">
                                        <option value="en">English</option>
                                        <option value="es">Español</option>
                                        <option value="fr">Français</option>
                                        <option value="de">Deutsch</option>
                                        <option value="ja">日本語</option>
                                    </select>
                                </div>
                                <div>
                                    <label style="display: block; font-size: 12px; color: #94a3b8; margin-bottom: 6px;">Date Format</label>
                                    <select id="setting-date-format" style="width: 100%; padding: 10px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 6px; color: #e2e8f0;">
                                        <option value="YYYY-MM-DD">YYYY-MM-DD</option>
                                        <option value="MM/DD/YYYY">MM/DD/YYYY</option>
                                        <option value="DD/MM/YYYY">DD/MM/YYYY</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Performance Settings Tab -->
                    <div id="settings-performance" class="settings-panel">
                        <div style="font-size: 18px; font-weight: 700; color: #06b6d4; margin-bottom: 24px;">🚀 Performance Settings</div>
                        
                        <div style="background: rgba(15, 23, 42, 0.4); border-radius: 12px; padding: 20px; border: 1px solid rgba(71, 85, 105, 0.3); margin-bottom: 20px;">
                            <div style="font-size: 14px; color: #06b6d4; margin-bottom: 16px; font-weight: 600;">Memory Management</div>
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                                <div>
                                    <label style="display: block; font-size: 12px; color: #94a3b8; margin-bottom: 6px;">Memory Limit (MB)</label>
                                    <input type="text" id="setting-memory-limit" placeholder="0 = Unlimited" style="width: 100%; padding: 10px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 6px; color: #e2e8f0;">
                                </div>
                                <div>
                                    <label style="display: block; font-size: 12px; color: #94a3b8; margin-bottom: 6px;">Cache Size (MB)</label>
                                    <input type="text" id="setting-cache-size" placeholder="1024" style="width: 100%; padding: 10px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 6px; color: #e2e8f0;">
                                </div>
                            </div>
                        </div>
                        
                        <div style="background: rgba(15, 23, 42, 0.4); border-radius: 12px; padding: 20px; border: 1px solid rgba(71, 85, 105, 0.3); margin-bottom: 20px;">
                            <div style="font-size: 14px; color: #06b6d4; margin-bottom: 16px; font-weight: 600;">Processing</div>
                            <div style="display: flex; flex-direction: column; gap: 12px;">
                                <label style="display: flex; align-items: center; gap: 12px; cursor: pointer; padding: 10px; background: rgba(15, 23, 42, 0.3); border-radius: 8px;">
                                    <input type="checkbox" id="setting-use-gpu" checked style="cursor: pointer;">
                                    <div>
                                        <div style="font-weight: 600; color: #e2e8f0;">Use GPU Acceleration</div>
                                        <div style="font-size: 11px; color: #94a3b8;">Enable GPU processing when available</div>
                                    </div>
                                </label>
                                <label style="display: flex; align-items: center; gap: 12px; cursor: pointer; padding: 10px; background: rgba(15, 23, 42, 0.3); border-radius: 8px;">
                                    <input type="checkbox" id="setting-multithreading" checked style="cursor: pointer;">
                                    <div>
                                        <div style="font-weight: 600; color: #e2e8f0;">Enable Multithreading</div>
                                        <div style="font-size: 11px; color: #94a3b8;">Use multiple CPU cores for processing</div>
                                    </div>
                                </label>
                            </div>
                        </div>
                        
                        <div style="background: rgba(15, 23, 42, 0.4); border-radius: 12px; padding: 20px; border: 1px solid rgba(71, 85, 105, 0.3);">
                            <div style="font-size: 14px; color: #06b6d4; margin-bottom: 16px; font-weight: 600;">Background Tasks</div>
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                                <div>
                                    <label style="display: block; font-size: 12px; color: #94a3b8; margin-bottom: 6px;">Worker Threads</label>
                                    <input type="text" id="setting-worker-threads" placeholder="Auto" style="width: 100%; padding: 10px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 6px; color: #e2e8f0;">
                                </div>
                                <div>
                                    <label style="display: block; font-size: 12px; color: #94a3b8; margin-bottom: 6px;">Task Priority</label>
                                    <select id="setting-task-priority" style="width: 100%; padding: 10px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 6px; color: #e2e8f0;">
                                        <option value="low">Low</option>
                                        <option value="normal" selected>Normal</option>
                                        <option value="high">High</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- UI Settings Tab -->
                    <div id="settings-ui" class="settings-panel">
                        <div style="font-size: 18px; font-weight: 700; color: #06b6d4; margin-bottom: 24px;">🎨 Interface Settings</div>
                        
                        <div style="background: rgba(15, 23, 42, 0.4); border-radius: 12px; padding: 20px; border: 1px solid rgba(71, 85, 105, 0.3); margin-bottom: 20px;">
                            <div style="font-size: 14px; color: #06b6d4; margin-bottom: 16px; font-weight: 600;">Appearance</div>
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                                <div>
                                    <label style="display: block; font-size: 12px; color: #94a3b8; margin-bottom: 6px;">Theme</label>
                                    <select id="setting-theme" style="width: 100%; padding: 10px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 6px; color: #e2e8f0;">
                                        <option value="dark" selected>Dark</option>
                                        <option value="light">Light</option>
                                        <option value="auto">Auto (System)</option>
                                    </select>
                                </div>
                                <div>
                                    <label style="display: block; font-size: 12px; color: #94a3b8; margin-bottom: 6px;">Font Size</label>
                                    <select id="setting-font-size" style="width: 100%; padding: 10px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 6px; color: #e2e8f0;">
                                        <option value="small">Small (12px)</option>
                                        <option value="medium" selected>Medium (13px)</option>
                                        <option value="large">Large (14px)</option>
                                        <option value="xlarge">Extra Large (16px)</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <div style="background: rgba(15, 23, 42, 0.4); border-radius: 12px; padding: 20px; border: 1px solid rgba(71, 85, 105, 0.3); margin-bottom: 20px;">
                            <div style="font-size: 14px; color: #06b6d4; margin-bottom: 16px; font-weight: 600;">Animations & Effects</div>
                            <div style="display: flex; flex-direction: column; gap: 12px;">
                                <label style="display: flex; align-items: center; gap: 12px; cursor: pointer; padding: 10px; background: rgba(15, 23, 42, 0.3); border-radius: 8px;">
                                    <input type="checkbox" id="setting-animations" checked style="cursor: pointer;">
                                    <div>
                                        <div style="font-weight: 600; color: #e2e8f0;">Enable Animations</div>
                                        <div style="font-size: 11px; color: #94a3b8;">Smooth transitions and animations</div>
                                    </div>
                                </label>
                                <label style="display: flex; align-items: center; gap: 12px; cursor: pointer; padding: 10px; background: rgba(15, 23, 42, 0.3); border-radius: 8px;">
                                    <input type="checkbox" id="setting-effects" checked style="cursor: pointer;">
                                    <div>
                                        <div style="font-weight: 600; color: #e2e8f0;">Visual Effects</div>
                                        <div style="font-size: 11px; color: #94a3b8;">Glows, shadows, and other visual enhancements</div>
                                    </div>
                                </label>
                                <label style="display: flex; align-items: center; gap: 12px; cursor: pointer; padding: 10px; background: rgba(15, 23, 42, 0.3); border-radius: 8px;">
                                    <input type="checkbox" id="setting-reduced-motion" style="cursor: pointer;">
                                    <div>
                                        <div style="font-weight: 600; color: #e2e8f0;">Reduce Motion</div>
                                        <div style="font-size: 11px; color: #94a3b8;">Minimize animations for accessibility</div>
                                    </div>
                                </label>
                            </div>
                        </div>
                        
                        <div style="background: rgba(15, 23, 42, 0.4); border-radius: 12px; padding: 20px; border: 1px solid rgba(71, 85, 105, 0.3);">
                            <div style="font-size: 14px; color: #06b6d4; margin-bottom: 16px; font-weight: 600;">Terminal Display</div>
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                                <div>
                                    <label style="display: block; font-size: 12px; color: #94a3b8; margin-bottom: 6px;">Font Family</label>
                                    <select id="setting-terminal-font" style="width: 100%; padding: 10px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 6px; color: #e2e8f0;">
                                        <option value="Consolas" selected>Consolas</option>
                                        <option value="Monaco">Monaco</option>
                                        <option value="Courier New">Courier New</option>
                                        <option value="Fira Code">Fira Code</option>
                                        <option value="JetBrains Mono">JetBrains Mono</option>
                                    </select>
                                </div>
                                <div>
                                    <label style="display: block; font-size: 12px; color: #94a3b8; margin-bottom: 6px;">Max Log Lines</label>
                                    <input type="text" id="setting-max-log-lines" placeholder="500" style="width: 100%; padding: 10px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 6px; color: #e2e8f0;">
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Advanced Settings Tab -->
                    <div id="settings-advanced" class="settings-panel">
                        <div style="font-size: 18px; font-weight: 700; color: #06b6d4; margin-bottom: 24px;">🔧 Advanced Settings</div>
                        
                        <div style="background: rgba(251, 191, 36, 0.1); border: 1px solid rgba(251, 191, 36, 0.3); border-radius: 12px; padding: 16px; margin-bottom: 24px;">
                            <div style="color: #fbbf24; font-weight: 600; margin-bottom: 8px;">⚠️ Warning</div>
                            <div style="color: #fbbf24; font-size: 12px;">Modifying these settings may affect application stability. Only change if you know what you're doing.</div>
                        </div>
                        
                        <div style="background: rgba(15, 23, 42, 0.4); border-radius: 12px; padding: 20px; border: 1px solid rgba(71, 85, 105, 0.3); margin-bottom: 20px;">
                            <div style="font-size: 14px; color: #06b6d4; margin-bottom: 16px; font-weight: 600;">Logging</div>
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                                <div>
                                    <label style="display: block; font-size: 12px; color: #94a3b8; margin-bottom: 6px;">Log Level</label>
                                    <select id="setting-log-level" style="width: 100%; padding: 10px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 6px; color: #e2e8f0;">
                                        <option value="DEBUG">DEBUG</option>
                                        <option value="INFO" selected>INFO</option>
                                        <option value="WARNING">WARNING</option>
                                        <option value="ERROR">ERROR</option>
                                    </select>
                                </div>
                                <div>
                                    <label style="display: block; font-size: 12px; color: #94a3b8; margin-bottom: 6px;">Log File Path</label>
                                    <input type="text" id="setting-log-path" placeholder="Default location" style="width: 100%; padding: 10px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 6px; color: #e2e8f0;">
                                </div>
                            </div>
                            <label style="display: flex; align-items: center; gap: 12px; cursor: pointer; padding: 10px; background: rgba(15, 23, 42, 0.3); border-radius: 8px; margin-top: 12px;">
                                <input type="checkbox" id="setting-log-to-file" checked style="cursor: pointer;">
                                <div style="font-weight: 600; color: #e2e8f0;">Enable File Logging</div>
                            </label>
                        </div>
                        
                        <div style="background: rgba(15, 23, 42, 0.4); border-radius: 12px; padding: 20px; border: 1px solid rgba(71, 85, 105, 0.3); margin-bottom: 20px;">
                            <div style="font-size: 14px; color: #06b6d4; margin-bottom: 16px; font-weight: 600;">Paths & Directories</div>
                            <div style="display: flex; flex-direction: column; gap: 12px;">
                                <div>
                                    <label style="display: block; font-size: 12px; color: #94a3b8; margin-bottom: 6px;">Modules Directory</label>
                                    <input type="text" id="setting-modules-dir" placeholder="modules/" style="width: 100%; padding: 10px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 6px; color: #e2e8f0;">
                                </div>
                                <div>
                                    <label style="display: block; font-size: 12px; color: #94a3b8; margin-bottom: 6px;">Temp Directory</label>
                                    <input type="text" id="setting-temp-dir" placeholder="System default" style="width: 100%; padding: 10px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 6px; color: #e2e8f0;">
                                </div>
                            </div>
                        </div>
                        
                        <div style="background: rgba(15, 23, 42, 0.4); border-radius: 12px; padding: 20px; border: 1px solid rgba(71, 85, 105, 0.3); margin-bottom: 20px;">
                            <div style="font-size: 14px; color: #06b6d4; margin-bottom: 16px; font-weight: 600;">Developer Options</div>
                            <div style="display: flex; flex-direction: column; gap: 12px;">
                                <label style="display: flex; align-items: center; gap: 12px; cursor: pointer; padding: 10px; background: rgba(15, 23, 42, 0.3); border-radius: 8px;">
                                    <input type="checkbox" id="setting-debug-mode" style="cursor: pointer;">
                                    <div>
                                        <div style="font-weight: 600; color: #e2e8f0;">Debug Mode</div>
                                        <div style="font-size: 11px; color: #94a3b8;">Enable verbose debugging output</div>
                                    </div>
                                </label>
                                <label style="display: flex; align-items: center; gap: 12px; cursor: pointer; padding: 10px; background: rgba(15, 23, 42, 0.3); border-radius: 8px;">
                                    <input type="checkbox" id="setting-dev-tools" style="cursor: pointer;">
                                    <div>
                                        <div style="font-weight: 600; color: #e2e8f0;">Enable Developer Tools</div>
                                        <div style="font-size: 11px; color: #94a3b8;">Access browser developer tools (F12)</div>
                                    </div>
                                </label>
                            </div>
                        </div>
                        
                        <div style="background: rgba(15, 23, 42, 0.4); border-radius: 12px; padding: 20px; border: 1px solid rgba(71, 85, 105, 0.3);">
                            <div style="font-size: 14px; color: #06b6d4; margin-bottom: 16px; font-weight: 600;">Reset & Maintenance</div>
                            <div style="display: flex; gap: 12px;">
                                <button class="btn-secondary" onclick="resetSettings()" style="flex: 1;">🔄 Reset All Settings</button>
                                <button class="btn-secondary" onclick="exportSettings()" style="flex: 1;">📤 Export Settings</button>
                                <button class="btn-secondary" onclick="importSettings()" style="flex: 1;">📥 Import Settings</button>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Settings Action Buttons -->
                    <div style="display: flex; gap: 12px; margin-top: 24px; padding-top: 24px; border-top: 2px solid rgba(71, 85, 105, 0.3);">
                        <button class="btn-primary" onclick="saveAllSettings()" style="flex: 1;">💾 Save All Settings</button>
                        <button class="btn-secondary" onclick="resetToDefaults()" style="flex: 1;">🔄 Reset to Defaults</button>
                    </div>
                </div>
            </div>
            
            <div class="details-panel">
                <div class="details-section">
                    <div class="details-header">Details</div>
                    <div class="details-content" id="details-content">Select a file to view details</div>
                </div>
                <div class="details-section">
                    <div class="details-header">Debug Log</div>
                    <div class="debug-log" id="debug-log">
                        <div class="debug-log-entry info">[System] Debug log initialized</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="qrc:///qtwebchannel/qwebchannel.js"></script>
    <script>
        // Initialize QWebChannel
        let bridge = null;
        let channelReady = false;
        
        function initBridge() {
            if (typeof qt !== 'undefined' && qt.webChannelTransport) {
                try {
                    new QWebChannel(qt.webChannelTransport, function(channel) {
                        bridge = channel.objects.bridge;
                        window.bridge = bridge;
                        channelReady = true;
                        console.log('QWebChannel bridge connected');
                    });
                } catch (e) {
                    console.error('QWebChannel init error:', e);
                    setupFallbackBridge();
                }
            } else {
                console.warn('QWebChannel transport not available, using fallback');
                setupFallbackBridge();
            }
        }
        
        function setupFallbackBridge() {
            // Fallback bridge for testing (will show errors in console)
            window.bridge = {
                open4dllm: () => console.warn('Bridge not connected: open4dllm'),
                openGguf: () => console.warn('Bridge not connected: openGguf'),
                selectFile: () => console.warn('Bridge not connected: selectFile'),
                runModel: () => console.warn('Bridge not connected: runModel'),
                stopModel: () => console.warn('Bridge not connected: stopModel'),
                copyCommand: () => console.warn('Bridge not connected: copyCommand'),
                selectGguf: () => console.warn('Bridge not connected: selectGguf'),
                buildPackage: () => console.warn('Bridge not connected: buildPackage'),
                inspectFile: () => console.warn('Bridge not connected: inspectFile'),
                refreshInspect: () => console.warn('Bridge not connected: refreshInspect'),
                selectProfile: (p) => console.warn('Bridge not connected: selectProfile', p),
                toggleUnsafe: (e) => console.warn('Bridge not connected: toggleUnsafe', e),
                sendChatMessage: (t) => console.warn('Bridge not connected: sendChatMessage', t),
                loadModules: () => console.warn('Bridge not connected: loadModules'),
                loadEditorFile: () => console.warn('Bridge not connected: loadEditorFile'),
                saveEditorFile: () => console.warn('Bridge not connected: saveEditorFile'),
                createBackup: () => console.warn('Bridge not connected: createBackup'),
                refreshEditorDisplay: () => console.warn('Bridge not connected: refreshEditorDisplay'),
                setEditorMode: (m) => console.warn('Bridge not connected: setEditorMode', m),
                selectTrainInputFile: () => console.warn('Bridge not connected: selectTrainInputFile'),
                loadTrainModel: () => console.warn('Bridge not connected: loadTrainModel'),
                selectTrainDataset: () => console.warn('Bridge not connected: selectTrainDataset'),
                selectTrainOutputFile: () => console.warn('Bridge not connected: selectTrainOutputFile'),
                loadTrainPreset: (p) => console.warn('Bridge not connected: loadTrainPreset', p),
                startTraining: () => console.warn('Bridge not connected: startTraining'),
                stopTraining: () => console.warn('Bridge not connected: stopTraining'),
                advancedRefreshMetadata: () => console.warn('Bridge not connected: advancedRefreshMetadata'),
                advancedAddKey: () => console.warn('Bridge not connected: advancedAddKey'),
                advancedDeleteKey: () => console.warn('Bridge not connected: advancedDeleteKey'),
                advancedSaveItemWithData: (k, v, t) => console.warn('Bridge not connected: advancedSaveItemWithData', k, v, t)
            };
        }
        
        // Try to initialize immediately
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', initBridge);
        } else {
            initBridge();
        }
        
        // Also try after a short delay in case QWebChannel loads later
        setTimeout(initBridge, 100);
        
        // Tab switching
        document.querySelectorAll('.nav-tab').forEach(tab => {
            tab.addEventListener('click', () => {
                const tabName = tab.dataset.tab;
                document.querySelectorAll('.nav-tab').forEach(t => t.classList.remove('active'));
                document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
                document.getElementById(`tab-${tabName}`).classList.add('active');
            });
        });
        
        // Chat input handling
        function handleChatKey(event) {
            if (event.key === 'Enter' && !event.shiftKey) {
                event.preventDefault();
                sendChatMessage();
            }
        }
        
        function sendChatMessage() {
            const input = document.getElementById('chat-input');
            const text = input.value.trim();
            if (text && window.bridge) {
                window.bridge.sendChatMessage(text);
                input.value = '';
            }
        }
        
        // Editor mode switching
        function switchEditorMode(mode) {
            window.editorMode = mode;
            // Store mode and refresh the editor display
            // The Python side will check window.editorMode via execute_js
            // Update button states
            const easyBtn = document.getElementById('easy-mode-btn');
            const advancedBtn = document.getElementById('advanced-mode-btn');
            if (easyBtn && advancedBtn) {
                if (mode === 'easy') {
                    easyBtn.classList.add('active');
                    advancedBtn.classList.remove('active');
                } else {
                    easyBtn.classList.remove('active');
                    advancedBtn.classList.add('active');
                }
            }
            // Refresh the editor display
            if (window.bridge && window.bridge.refreshEditorDisplay) {
                window.bridge.refreshEditorDisplay();
            }
        }
        
        // Initialize editor mode
        window.editorMode = 'easy';
        
        // Settings tab switching
        function switchSettingsTab(tabName) {
            // Hide all panels
            document.querySelectorAll('.settings-panel').forEach(panel => {
                panel.classList.remove('active');
            });
            // Remove active from all buttons
            document.querySelectorAll('.settings-tab-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            // Show selected panel
            const panel = document.getElementById(`settings-${tabName}`);
            if (panel) {
                panel.classList.add('active');
            }
            // Activate selected button
            const btn = document.querySelector(`.settings-tab-btn[data-settings-tab="${tabName}"]`);
            if (btn) {
                btn.classList.add('active');
            }
        }
        
        // Settings functions (placeholder implementations)
        function createNewProfile() {
            const name = prompt('Enter profile name:');
            if (name && name.trim()) {
                console.log('Creating new profile:', name);
                // Implementation would go here
            }
        }
        
        function duplicateProfile() {
            console.log('Duplicating current profile');
            // Implementation would go here
        }
        
        function deleteProfile() {
            if (confirm('Are you sure you want to delete this profile?')) {
                console.log('Deleting profile');
                // Implementation would go here
            }
        }
        
        function saveProfile() {
            console.log('Saving profile changes');
            // Implementation would go here
        }
        
        function saveAllSettings() {
            console.log('Saving all settings');
            alert('Settings saved! (This is a placeholder - actual implementation would save to storage)');
        }
        
        function resetToDefaults() {
            if (confirm('Are you sure you want to reset all settings to defaults?')) {
                console.log('Resetting to defaults');
                // Implementation would go here
            }
        }
        
        function resetSettings() {
            if (confirm('Are you sure you want to reset all settings? This cannot be undone.')) {
                console.log('Resetting settings');
                // Implementation would go here
            }
        }
        
        function exportSettings() {
            console.log('Exporting settings');
            alert('Settings export feature - would export to JSON file');
        }
        
        function importSettings() {
            console.log('Importing settings');
            alert('Settings import feature - would import from JSON file');
        }
    </script>
</body>
</html>
"""


class WebBridge(QWidget):
    """Bridge object for Python-Qt communication"""
    # Signals
    open4dllmRequested = pyqtSignal()
    openGgufRequested = pyqtSignal()
    selectFileRequested = pyqtSignal()
    runModelRequested = pyqtSignal()
    stopModelRequested = pyqtSignal()
    copyCommandRequested = pyqtSignal()
    selectGgufRequested = pyqtSignal()
    buildPackageRequested = pyqtSignal()
    inspectFileRequested = pyqtSignal()
    refreshInspectRequested = pyqtSignal()
    selectProfileRequested = pyqtSignal(str)
    toggleUnsafeRequested = pyqtSignal(bool)
    sendChatMessageRequested = pyqtSignal(str)
    # Builder signals
    loadModulesRequested = pyqtSignal()
    addScriptRequested = pyqtSignal(str, str, int, bool)  # name, content, priority, enabled
    removeScriptRequested = pyqtSignal(str)
    buildPackageRequested = pyqtSignal(str, bool, bool)  # output_path, compress_scripts, compress_metadata
    # Editor signals
    loadEditorFileRequested = pyqtSignal()
    saveEditorFileRequested = pyqtSignal()
    createBackupRequested = pyqtSignal()
    refreshEditorDisplayRequested = pyqtSignal()
    getEditorMetadataRequested = pyqtSignal()
    updateEditorMetadataRequested = pyqtSignal(str, str)  # key, value
    # Advanced editor signals
    advancedRefreshMetadataRequested = pyqtSignal()
    advancedAddKeyRequested = pyqtSignal()
    advancedDeleteKeyRequested = pyqtSignal()
    advancedSaveItemRequested = pyqtSignal(str, str, str)  # key, value, value_type
    # Trainer signals
    selectTrainInputFileRequested = pyqtSignal()
    selectTrainDatasetRequested = pyqtSignal()
    selectTrainOutputFileRequested = pyqtSignal()
    loadTrainModelRequested = pyqtSignal()
    loadTrainPresetRequested = pyqtSignal(str)
    startTrainingRequested = pyqtSignal()
    stopTrainingRequested = pyqtSignal()
    
    def __init__(self):
        super().__init__()
    
    @pyqtSlot()
    def open4dllm(self):
        self.open4dllmRequested.emit()
    
    @pyqtSlot()
    def openGguf(self):
        self.openGgufRequested.emit()
    
    @pyqtSlot()
    def selectFile(self):
        self.selectFileRequested.emit()
    
    @pyqtSlot()
    def runModel(self):
        self.runModelRequested.emit()
    
    @pyqtSlot()
    def stopModel(self):
        self.stopModelRequested.emit()
    
    @pyqtSlot()
    def copyCommand(self):
        self.copyCommandRequested.emit()
    
    @pyqtSlot()
    def selectGguf(self):
        self.selectGgufRequested.emit()
    
    @pyqtSlot()
    def buildPackage(self):
        self.buildPackageRequested.emit()
    
    @pyqtSlot()
    def inspectFile(self):
        self.inspectFileRequested.emit()
    
    @pyqtSlot()
    def refreshInspect(self):
        self.refreshInspectRequested.emit()
    
    @pyqtSlot(str)
    def selectProfile(self, profile: str):
        self.selectProfileRequested.emit(profile)
    
    @pyqtSlot(bool)
    def toggleUnsafe(self, enabled: bool):
        self.toggleUnsafeRequested.emit(enabled)
    
    @pyqtSlot(str)
    def sendChatMessage(self, text: str):
        self.sendChatMessageRequested.emit(text)
    
    # Builder slots
    @pyqtSlot()
    def loadModules(self):
        self.loadModulesRequested.emit()
    
    @pyqtSlot(str, str, int, bool)
    def addScript(self, name: str, content: str, priority: int, enabled: bool):
        self.addScriptRequested.emit(name, content, priority, enabled)
    
    @pyqtSlot(str)
    def removeScript(self, name: str):
        self.removeScriptRequested.emit(name)
    
    # Editor slots
    @pyqtSlot()
    def loadEditorFile(self):
        self.loadEditorFileRequested.emit()
    
    @pyqtSlot()
    def saveEditorFile(self):
        self.saveEditorFileRequested.emit()
    
    @pyqtSlot()
    def createBackup(self):
        self.createBackupRequested.emit()
    
    @pyqtSlot()
    def refreshEditorDisplay(self):
        self.refreshEditorDisplayRequested.emit()
    
    @pyqtSlot()
    def getEditorMetadata(self):
        self.getEditorMetadataRequested.emit()
    
    @pyqtSlot(str, str)
    def updateEditorMetadata(self, key: str, value: str):
        self.updateEditorMetadataRequested.emit(key, value)
    
    # Advanced editor slots
    @pyqtSlot()
    def advancedRefreshMetadata(self):
        self.advancedRefreshMetadataRequested.emit()
    
    @pyqtSlot()
    def advancedAddKey(self):
        self.advancedAddKeyRequested.emit()
    
    @pyqtSlot()
    def advancedDeleteKey(self):
        self.advancedDeleteKeyRequested.emit()
    
    @pyqtSlot()
    def advancedSaveItem(self):
        # Get values from JavaScript and emit
        # We'll use JavaScript to call this with the actual values
        # For now, we need a way to pass the data - using a workaround with executeJS
        pass
    
    @pyqtSlot(str, str, str)
    def advancedSaveItemWithData(self, key: str, value: str, value_type: str):
        self.advancedSaveItemRequested.emit(key, value, value_type)
    
    # Trainer slots
    @pyqtSlot()
    def selectTrainInputFile(self):
        self.selectTrainInputFileRequested.emit()
    
    @pyqtSlot()
    def loadTrainModel(self):
        self.loadTrainModelRequested.emit()
    
    @pyqtSlot()
    def selectTrainDataset(self):
        self.selectTrainDatasetRequested.emit()
    
    @pyqtSlot()
    def selectTrainOutputFile(self):
        self.selectTrainOutputFileRequested.emit()
    
    @pyqtSlot(str)
    def loadTrainPreset(self, preset: str):
        self.loadTrainPresetRequested.emit(preset)
    
    @pyqtSlot()
    def startTraining(self):
        try:
            DEBUG_LOGGER.info("="*80)
            DEBUG_LOGGER.info("WebBridge.startTraining() CALLED FROM JAVASCRIPT")
            DEBUG_LOGGER.info("="*80)
            self.startTrainingRequested.emit()
            DEBUG_LOGGER.info("startTrainingRequested signal emitted successfully")
        except Exception as e:
            DEBUG_LOGGER.error(f"CRITICAL ERROR in WebBridge.startTraining: {e}", exc_info=True)
            import traceback
            DEBUG_LOGGER.error(f"Traceback:\n{traceback.format_exc()}")
            raise
    
    @pyqtSlot()
    def stopTraining(self):
        self.stopTrainingRequested.emit()


class OutputReaderThread(QThread):
    """Thread for reading subprocess output - optimized for speed"""
    outputReceived = pyqtSignal(str)
    finished = pyqtSignal()
    
    def __init__(self, process):
        super().__init__()
        self.process = process
        self.running = True
    
    def run(self):
        """Read output with LIGHTNING FAST polling - optimized for real-time"""
        partial = ""
        buffer_size = 4096  # 4KB chunks for optimal speed
        
        while self.running:
            try:
                # Check if process ended
                if self.process.poll() is not None:
                    # Process finished, read any remaining data
                    try:
                        remaining = self.process.stdout.read()
                        if remaining:
                            data = partial + remaining
                            if data:
                                self.outputReceived.emit(data)
                    except:
                        pass
                    break
                
                # LIGHTNING FAST non-blocking read check (1ms timeout)
                if sys.platform != "win32":
                    try:
                        ready, _, _ = select.select([self.process.stdout], [], [], 0.001)
                        if not ready:
                            time.sleep(0.001)  # Minimal sleep - 1ms
                            continue
                    except (ValueError, OSError):
                        break
                
                # Read chunk immediately
                try:
                    chunk = self.process.stdout.read(buffer_size)
                except (ValueError, OSError, AttributeError):
                    break
                
                if not chunk:
                    # No data, minimal sleep
                    time.sleep(0.001)  # 1ms
                    continue
                
                # Combine with partial line
                data = partial + chunk
                lines = data.split('\n')
                
                # Process complete lines
                if data.endswith('\n'):
                    partial = ""
                    complete_lines = lines[:-1]
                else:
                    partial = lines[-1]
                    complete_lines = lines[:-1]
                
                # Emit lines - filter out auto-prompts
                for line in complete_lines:
                    # Filter out standalone "You> " prompts (runner waiting for input)
                    if line.strip() == "You>":
                        continue
                    # Filter duplicate "You> You>" patterns
                    if line.strip().startswith("You> You>"):
                        # Keep only one "You>"
                        line = "You>" + line.split("You>", 2)[-1] if "You>" in line else line
                    
                    # Emit the line
                    self.outputReceived.emit(line + '\n')
                
            except Exception as e:
                DEBUG_LOGGER.error(f"Reader error: {e}", exc_info=True)
                break
        
        # Flush any remaining partial line
        if partial:
            self.outputReceived.emit(partial + '\n')
        
        self.finished.emit()
    
    def stop(self):
        """Stop the reader thread"""
        self.running = False


class WorldClassStudio(QMainWindow):
    """World-class 4DLLM Studio with PyQt6 + HTML/CSS/JS"""
    
    # Signals for thread-safe UI updates
    trainLogAppended = pyqtSignal(str, str)  # text, tag
    trainStatsUpdated = pyqtSignal(str)  # stats HTML
    trainProgressUpdated = pyqtSignal(int, str)  # progress percent, text
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("4DLLM Studio — RomanAILabs")
        self.setGeometry(100, 100, 1600, 1000)
        
        # Connect training signals
        self.trainLogAppended.connect(self._append_train_log_safe)
        self.trainStatsUpdated.connect(self._update_train_stats_safe)
        self.trainProgressUpdated.connect(self._update_train_progress_safe)
        
        # No longer using signal-based approach - using queue instead
        
        # JavaScript execution queue for thread-safe UI updates
        self.js_queue = queue.Queue()
        self.js_timer = QTimer()
        self.js_timer.timeout.connect(self._process_js_queue)
        self.js_timer.start(10)  # Check queue every 10ms
        
        # State
        self.run_path: Optional[Path] = None
        self.gguf_path: Optional[Path] = None
        self.is_gguf_file: bool = False  # Track if run_path is a GGUF file
        self.proc: Optional[subprocess.Popen] = None
        self.reader_thread: Optional[OutputReaderThread] = None
        self.unsafe_enabled = True
        self.waiting_for_ai = False  # Track if AI is generating
        self.streaming_indicator = None  # Timer for streaming dots
        self.last_ai_line_time = 0  # Track when we last saw an "AI>" line
        self.last_output_time = 0  # Track when we last saw ANY output
        self.ai_timeout_id = None  # Timeout to reset waiting state if detection fails
        self.inactivity_timeout_id = None  # Shorter timeout for inactivity detection
        self._last_log_times = {}  # Track last time each log message was printed (for deduplication)
        self._last_debug_log_messages = {}  # Track last debug log messages to prevent duplicates (message -> timestamp)
        
        # Editor state
        self._editor_instance = None
        self._editor_file_path = None
        
        # Trainer state
        self.train_input_file: Optional[Path] = None
        self.train_output_file: Optional[Path] = None
        self.train_dataset_file: Optional[Path] = None
        self.training_process: Optional[subprocess.Popen] = None
        self.training_thread: Optional[threading.Thread] = None
        self.is_training = False
        
        self.profiles = {
            "Default": {"n_ctx": "4096", "threads": "4", "gpu_layers": "0", "max_tokens": "256", "temp": "0.7", "backend": "llama_cpp"},
            "High Performance": {"n_ctx": "8192", "threads": "8", "gpu_layers": "35", "max_tokens": "512", "temp": "0.8", "backend": "llama_cpp"},
            "Low Memory": {"n_ctx": "2048", "threads": "2", "gpu_layers": "0", "max_tokens": "128", "temp": "0.6", "backend": "llama_cli"},
        }
        self.current_profile = self.profiles["Default"].copy()
        
        # Setup UI
        self._setup_ui()
        self._setup_bridge()
        # Setup GUI debug log handler (after bridge is set up)
        QTimer.singleShot(500, self._setup_debug_log_handler)
        # Setup GUI debug log handler (after bridge is set up)
        QTimer.singleShot(500, self._setup_debug_log_handler)
    
    def _setup_ui(self):
        """Setup the main UI with QWebEngineView"""
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)
        layout.setContentsMargins(0, 0, 0, 0)
        
        # Get assets path for logo
        assets_dir = Path(__file__).parent / "assets"
        logo_path = assets_dir / "RomanAILabs.png"
        header_logo_path = assets_dir / "RomanAILabs.png"
        
        # Replace logo placeholders in HTML template
        html_template = HTML_TEMPLATE
        
        # Convert paths to file:// URLs for QWebEngineView
        if logo_path.exists():
            logo_url = QUrl.fromLocalFile(str(logo_path.absolute())).toString()
            DEBUG_LOGGER.info(f"Terminal logo URL: {logo_url}")
            # Replace all terminal logo placeholders
            html_template = html_template.replace('TERMINAL_LOGO_PLACEHOLDER', logo_url)
            html_template = html_template.replace('TERMINAL_LOGO_DIM_PLACEHOLDER', logo_url)
            html_template = html_template.replace('TERMINAL_LOGO_BOLD_PLACEHOLDER', logo_url)
        else:
            DEBUG_LOGGER.warning(f"Terminal logo not found at: {logo_path}")
            html_template = html_template.replace('TERMINAL_LOGO_PLACEHOLDER', '')
            html_template = html_template.replace('TERMINAL_LOGO_DIM_PLACEHOLDER', '')
            html_template = html_template.replace('TERMINAL_LOGO_BOLD_PLACEHOLDER', '')
        
        if header_logo_path.exists():
            header_logo_url = QUrl.fromLocalFile(str(header_logo_path.absolute())).toString()
            DEBUG_LOGGER.info(f"Header logo URL: {header_logo_url}")
            html_template = html_template.replace('HEADER_LOGO_PLACEHOLDER', header_logo_url)
        else:
            DEBUG_LOGGER.warning(f"Header logo not found at: {header_logo_path}")
            html_template = html_template.replace('HEADER_LOGO_PLACEHOLDER', '')
        
        # Web view for HTML/CSS/JS interface
        self.web_view = QWebEngineView()
        # Set base URL to allow loading local files
        base_url = QUrl.fromLocalFile(str(Path(__file__).parent.absolute()) + "/")
        self.web_view.setHtml(html_template, base_url)
        layout.addWidget(self.web_view)
    
    def _setup_bridge(self):
        """Setup WebChannel bridge for Python-JS communication"""
        self.bridge = WebBridge()
        self.channel = QWebChannel()
        self.channel.registerObject("bridge", self.bridge)
        self.web_view.page().setWebChannel(self.channel)
        
        # Connect signals
        self.bridge.open4dllmRequested.connect(self._open_4dllm)
        self.bridge.openGgufRequested.connect(self._open_gguf)
        self.bridge.selectFileRequested.connect(self._select_file)
        self.bridge.runModelRequested.connect(self._run_model)
        self.bridge.stopModelRequested.connect(self._stop_model)
        self.bridge.copyCommandRequested.connect(self._copy_command)
        self.bridge.selectGgufRequested.connect(self._select_gguf)
        self.bridge.buildPackageRequested.connect(self._build_package)
        self.bridge.inspectFileRequested.connect(self._inspect_file)
        self.bridge.refreshInspectRequested.connect(self._refresh_inspect)
        self.bridge.selectProfileRequested.connect(self._select_profile)
        self.bridge.toggleUnsafeRequested.connect(self._toggle_unsafe)
        self.bridge.sendChatMessageRequested.connect(self._send_chat_message)
        # Builder signals
        self.bridge.loadModulesRequested.connect(self._load_modules)
        self.bridge.addScriptRequested.connect(self._add_script)
        self.bridge.removeScriptRequested.connect(self._remove_script)
        # Editor signals
        self.bridge.loadEditorFileRequested.connect(self._load_editor_file)
        self.bridge.saveEditorFileRequested.connect(self._save_editor_file)
        self.bridge.createBackupRequested.connect(self._create_backup)
        self.bridge.refreshEditorDisplayRequested.connect(self._refresh_editor_display)
        self.bridge.getEditorMetadataRequested.connect(self._get_editor_metadata)
        self.bridge.updateEditorMetadataRequested.connect(self._update_editor_metadata)
        # Advanced editor signals
        self.bridge.advancedRefreshMetadataRequested.connect(self._advanced_refresh_metadata)
        self.bridge.advancedAddKeyRequested.connect(self._advanced_add_key)
        self.bridge.advancedDeleteKeyRequested.connect(self._advanced_delete_key)
        self.bridge.advancedSaveItemRequested.connect(self._advanced_save_item)
        # Initialize editor mode
        self._editor_mode = 'easy'
        # Trainer signals
        self.bridge.selectTrainInputFileRequested.connect(self._select_train_input_file)
        self.bridge.selectTrainDatasetRequested.connect(self._select_train_dataset)
        self.bridge.selectTrainOutputFileRequested.connect(self._select_train_output_file)
        self.bridge.loadTrainModelRequested.connect(self._load_train_model)
        self.bridge.loadTrainPresetRequested.connect(self._load_train_preset)
        self.bridge.startTrainingRequested.connect(self._start_training)
        self.bridge.stopTrainingRequested.connect(self._stop_training)
        DEBUG_LOGGER.info("Training signals connected: startTrainingRequested -> _start_training")
    
    def _generate_error_code(self, error_type: str = "INSPECT") -> str:
        """Generate a unique error code for tracking"""
        import time
        import random
        timestamp = int(time.time() * 1000)
        random_part = random.randint(1000, 9999)
        return f"{error_type}-{timestamp}-{random_part}"
    
    def _show_inspect_error_dialog(self, error: Exception, context: str = ""):
        """Show error dialog for inspect feature - SELF-HEALING: Never crashes"""
        # OUTER TRY: Catch everything
        try:
            import traceback
            # Safe error code generation
            try:
                error_code = self._generate_error_code("INSPECT")
            except Exception:
                error_code = "INSPECT-UNKNOWN"
            
            # Safe error type/message extraction
            try:
                error_type = type(error).__name__ if error else "UnknownError"
                error_msg = str(error) if error else "Unknown error"
            except Exception:
                error_type = "UnknownError"
                error_msg = "Failed to extract error message"
            
            # Safe traceback generation
            try:
                traceback_str = traceback.format_exc()
            except Exception:
                traceback_str = "Failed to generate traceback"
            
            # Safe message construction
            try:
                full_message = f"An error occurred while inspecting the file.\n\n"
                if context:
                    full_message += f"Context: {context}\n\n"
                full_message += f"Error Type: {error_type}\nError Message: {error_msg}"
            except Exception:
                full_message = "An error occurred while inspecting the file."
            
            # Safe error details construction
            try:
                error_details = f"Error Code: {error_code}\n\n"
                error_details += f"Error Type: {error_type}\n"
                error_details += f"Error Message: {error_msg}\n\n"
                error_details += f"Traceback:\n{traceback_str}"
            except Exception:
                error_details = f"Error Code: {error_code}\n\nError: {error_msg}"
            
            # Log the error - wrapped in try-except
            try:
                DEBUG_LOGGER.error(f"[INSPECT] Error Code: {error_code}")
                DEBUG_LOGGER.error(f"[INSPECT] Error: {error}", exc_info=True)
            except Exception:
                pass  # Logging failed, continue anyway
            
            # Use QTimer to ensure we're on the main thread - wrapped in try-except
            try:
                def show_dialog_safe():
                    """Safe dialog display wrapper"""
                    try:
                        self._show_error_dialog("Inspect Error", full_message, error_details)
                    except Exception as dialog_error:
                        # Even _show_error_dialog failed, try basic message box
                        try:
                            DEBUG_LOGGER.error(f"[INSPECT] _show_error_dialog failed: {dialog_error}", exc_info=True)
                            QMessageBox.critical(self, "Inspect Error", f"{full_message}\n\nError Code: {error_code}")
                        except Exception:
                            # Even basic message box failed, just log it
                            DEBUG_LOGGER.error(f"[INSPECT] All error dialog methods failed", exc_info=True)
                
                QTimer.singleShot(0, show_dialog_safe)
            except Exception as timer_error:
                # QTimer failed, try direct call (might be on main thread already)
                try:
                    DEBUG_LOGGER.error(f"[INSPECT] QTimer failed: {timer_error}", exc_info=True)
                    self._show_error_dialog("Inspect Error", full_message, error_details)
                except Exception:
                    # Even direct call failed, try basic message box
                    try:
                        QMessageBox.critical(self, "Inspect Error", f"{full_message}\n\nError Code: {error_code}")
                    except Exception:
                        DEBUG_LOGGER.error(f"[INSPECT] All error display methods failed", exc_info=True)
        except Exception as e:
            # ABSOLUTE CATCH-ALL: Even error dialog creation failed
            try:
                DEBUG_LOGGER.error(f"[INSPECT] CRITICAL: Failed to show error dialog: {e}", exc_info=True)
                # Last resort: try basic message box
                try:
                    QMessageBox.critical(self, "Critical Error", f"Inspect feature error:\n\n{str(e) if e else 'Unknown error'}")
                except Exception:
                    pass  # Everything failed, just log it
            except Exception:
                pass  # Even logging failed, give up
    
    def _show_error_dialog(self, title: str, message: str, error_code: str = ""):
        """Show error dialog with Copy Error Code and OK buttons - NEVER CRASHES"""
        try:
            dialog = QDialog(self)
            dialog.setWindowTitle(title)
            dialog.setMinimumWidth(500)
            dialog.setMinimumHeight(200)
            
            layout = QVBoxLayout(dialog)
            
            # Error message label
            msg_label = QLabel(message)
            msg_label.setWordWrap(True)
            msg_label.setStyleSheet("color: #e2e8f0; padding: 10px;")
            layout.addWidget(msg_label)
            
            # Error code text area (if provided)
            if error_code:
                code_label = QLabel("Error Code:")
                code_label.setStyleSheet("color: #94a3b8; font-weight: bold; margin-top: 10px;")
                layout.addWidget(code_label)
                
                code_text = QTextEdit()
                code_text.setPlainText(error_code)
                code_text.setReadOnly(True)
                code_text.setMaximumHeight(150)
                code_text.setStyleSheet("background: #1a1f2e; color: #cbd5e1; font-family: monospace; padding: 8px;")
                layout.addWidget(code_text)
            
            # Buttons
            button_layout = QHBoxLayout()
            
            if error_code:
                copy_btn = QPushButton("📋 Copy Error Code")
                copy_btn.setStyleSheet("""
                    QPushButton {
                        background: #3b82f6;
                        color: white;
                        padding: 8px 16px;
                        border-radius: 6px;
                        font-weight: 600;
                    }
                    QPushButton:hover {
                        background: #2563eb;
                    }
                """)
                def copy_error():
                    try:
                        clipboard = QApplication.clipboard()
                        clipboard.setText(error_code)
                        copy_btn.setText("✓ Copied!")
                        QTimer.singleShot(2000, lambda: copy_btn.setText("📋 Copy Error Code"))
                    except Exception as e:
                        DEBUG_LOGGER.error(f"Error copying to clipboard: {e}")
                copy_btn.clicked.connect(copy_error)
                button_layout.addWidget(copy_btn)
            
            ok_btn = QPushButton("OK")
            ok_btn.setStyleSheet("""
                QPushButton {
                    background: #06b6d4;
                    color: white;
                    padding: 8px 24px;
                    border-radius: 6px;
                    font-weight: 600;
                }
                QPushButton:hover {
                    background: #0891b2;
                }
            """)
            ok_btn.clicked.connect(dialog.accept)
            button_layout.addWidget(ok_btn)
            
            layout.addLayout(button_layout)
            dialog.exec()
        except Exception as e:
            # Fallback to simple message box if dialog creation fails
            DEBUG_LOGGER.error(f"Error showing error dialog: {e}", exc_info=True)
            try:
                QMessageBox.critical(self, title, f"{message}\n\nError Code:\n{error_code}" if error_code else message)
            except:
                pass  # If even this fails, just log it
    
    def _setup_debug_log_handler(self):
        """Setup the GUI debug log handler"""
        gui_handler = GUIDebugLogHandler(self)
        DEBUG_LOGGER.addHandler(gui_handler)
        # Prevent DEBUG_LOGGER from propagating to root to avoid duplicate messages
        DEBUG_LOGGER.propagate = False
        # Also add to root logger to catch all module logs (but not DEBUG_LOGGER messages)
        root_logger = logging.getLogger()
        root_logger.addHandler(gui_handler)
        DEBUG_LOGGER.info("GUI debug log handler initialized")
    
    def _append_debug_log(self, message: str, level: str = "info"):
        """Append a message to the debug log with deduplication"""
        import time
        current_time = time.time()
        
        # Deduplication: Only show the same message once per 2 seconds
        if message in self._last_debug_log_messages:
            last_time = self._last_debug_log_messages[message]
            if current_time - last_time < 2.0:
                return  # Skip duplicate message
        
        # Update last seen time for this message
        self._last_debug_log_messages[message] = current_time
        
        # Clean up old entries (keep only last 100 messages)
        if len(self._last_debug_log_messages) > 100:
            # Remove entries older than 10 seconds
            cutoff_time = current_time - 10.0
            self._last_debug_log_messages = {msg: t for msg, t in self._last_debug_log_messages.items() if t > cutoff_time}
        
        from datetime import datetime
        timestamp = datetime.now().strftime("%H:%M:%S")
        # Escape message for JavaScript
        escaped_msg = message.replace('\\', '\\\\').replace("'", "\\'").replace('\n', '\\n').replace('\r', '').replace('</', '<\\/')
        js_code = f"""
            (function() {{
                const log = document.getElementById('debug-log');
                if (!log) return;
                const entry = document.createElement('div');
                entry.className = 'debug-log-entry {level}';
                entry.textContent = '[{timestamp}] {escaped_msg}';
                log.appendChild(entry);
                // Auto-scroll to bottom
                log.scrollTop = log.scrollHeight;
                // Limit to 500 entries to prevent memory issues
                while (log.children.length > 500) {{
                    log.removeChild(log.firstChild);
                }}
            }})();
        """
        self._execute_js(js_code)
    
    @pyqtSlot()
    def _process_js_queue(self):
        """Process JavaScript execution queue from main thread"""
        try:
            processed = 0
            while True:
                try:
                    script = self.js_queue.get_nowait()
                    if self.web_view:
                        self.web_view.page().runJavaScript(script)
                    processed += 1
                except queue.Empty:
                    break
                except Exception as e:
                    DEBUG_LOGGER.error(f"Error processing JS queue: {e}", exc_info=True)
                    break
        except Exception as e:
            DEBUG_LOGGER.error(f"CRITICAL error in _process_js_queue: {e}", exc_info=True)
    
    def _execute_js(self, script: str, callback=None):
        """Execute JavaScript in the web view (direct call, must be on main thread)"""
        try:
            if self.web_view is None:
                DEBUG_LOGGER.error("web_view is None - cannot execute JavaScript")
                return
            
            if callback:
                self.web_view.page().runJavaScript(script, callback)
            else:
                self.web_view.page().runJavaScript(script)
        except Exception as e:
            DEBUG_LOGGER.error(f"Failed to execute JavaScript: {e}", exc_info=True)
            raise
    
    def _execute_js_safe(self, script: str):
        """Thread-safe wrapper for _execute_js - can be called from any thread"""
        try:
            # Add script to queue - will be processed by main thread timer
            self.js_queue.put(script)
        except Exception as e:
            DEBUG_LOGGER.error(f"Failed to add script to queue: {e}", exc_info=True)
            # Don't raise - just log the error to prevent crashes
    
    def _append_terminal(self, text: str, tag: str = "output"):
        """Append text to terminal IMMEDIATELY - no batching for real-time display"""
        if not text:
            return
        
        import time
        text_lower = text.lower()
        text_stripped = text.strip()
        
        DEBUG_LOGGER.debug(f"[DETECT] Processing line: waiting_for_ai={self.waiting_for_ai}, text='{text_stripped[:100]}'")
        
        # Update last output time for any output
        if text_stripped:
            old_output_time = self.last_output_time
            self.last_output_time = time.time()
            DEBUG_LOGGER.debug(f"[TIMING] Output received: last_output_time={self.last_output_time:.3f} (was {old_output_time:.3f})")
            self._reset_inactivity_timeout()
        
        # Detect AI response start
        if text_stripped.startswith("AI>"):
            old_ai_time = self.last_ai_line_time
            self.waiting_for_ai = True
            self.last_ai_line_time = time.time()
            # Clear log cache when starting new AI response cycle
            self._last_log_times.clear()
            DEBUG_LOGGER.info(f"[AI_START] AI response detected: last_ai_line_time={self.last_ai_line_time:.3f} (was {old_ai_time:.3f}), waiting_for_ai={self.waiting_for_ai}")
            self._start_streaming_indicator()
            self._start_ai_timeout()
            self._reset_inactivity_timeout()
        
        # Detect when AI finishes - multiple patterns:
        # 1. Standalone "You>" or "You> " prompt (runner waiting for input)
        # 2. "[4DLLM] Chat ready" message (system ready)
        # 3. System output (performance metrics) after AI response
        is_you_prompt = (
            text_stripped == "You>" or 
            text_stripped == "You> " or
            (text_stripped.startswith("You> ") and len(text_stripped) <= 10 and not text_stripped.startswith("You> You>"))
        )
        is_ready_message = (
            "[4DLLM] Chat ready" in text_stripped or
            (text_stripped.startswith("[4DLLM]") and "ready" in text_lower)
        )
        
        # Detect system output after AI response (performance metrics)
        if self.waiting_for_ai and self.last_ai_line_time > 0:
            time_since_ai = time.time() - self.last_ai_line_time
            DEBUG_LOGGER.debug(f"[AI_CHECK] waiting_for_ai={self.waiting_for_ai}, last_ai_line_time={self.last_ai_line_time:.3f}, time_since_ai={time_since_ai:.3f}s")
            if time_since_ai > 2.0:
                is_system_output = (
                    "llama_perf" in text_lower or
                    "load time" in text_lower or
                    "eval time" in text_lower or
                    "total time" in text_lower or
                    "graphs reused" in text_lower or
                    text_stripped == "" or  # Empty line after AI response
                    (not text_stripped.startswith("AI>") and time_since_ai > 3.0)  # Any non-AI content after 3s
                )
                DEBUG_LOGGER.debug(f"[SYSTEM_CHECK] time_since_ai={time_since_ai:.3f}s, is_system_output={is_system_output}, text='{text_stripped[:50]}'")
                if is_system_output:
                    DEBUG_LOGGER.info(f"[AI_END] Detected AI response end (system output after {time_since_ai:.1f}s): '{text_stripped[:50]}'")
                    self.waiting_for_ai = False
                    self._stop_streaming_indicator()
                    self._cancel_ai_timeout()
                    self._cancel_inactivity_timeout()
                    self.last_ai_line_time = 0
        
        DEBUG_LOGGER.debug(f"[PROMPT_CHECK] is_you_prompt={is_you_prompt}, is_ready_message={is_ready_message}, text='{text_stripped[:50]}'")
        
        if is_you_prompt or is_ready_message:
            # AI finished responding - allow new messages
            if self.waiting_for_ai:
                DEBUG_LOGGER.info(f"[AI_END] AI finished responding (detected: '{text_stripped[:50]}'), ready for new input")
                self.waiting_for_ai = False
                self._stop_streaming_indicator()
                self._cancel_ai_timeout()
                self._cancel_inactivity_timeout()
                self.last_ai_line_time = 0
            else:
                DEBUG_LOGGER.debug(f"[PROMPT_CHECK] Prompt detected but waiting_for_ai=False (already reset?)")
        
        # Filter out duplicate "You> " prompts from the runner (but allow standalone "You>" for detection)
        if text_stripped == "You> " or text_stripped.startswith("You> You>"):
            # Skip auto-generated prompts (but we already detected it above)
            pass  # Don't skip - we need it for detection
        
        colors = {
            "output": "#e2e8f0",
            "success": "#34d399",
            "error": "#f87171",
            "warning": "#fbbf24",
            "info": "#60a5fa",
            "command": "#3b82f6"
        }
        color = colors.get(tag, "#e2e8f0")
        
        # Escape text properly for JavaScript (handle special chars)
        escaped_text = json.dumps(text)
        
        # Direct DOM update - no batching for instant display
        script = f"""
            (function() {{
                const output = document.getElementById('terminal-output');
                if (!output) {{ console.error('Terminal output element not found!'); return; }}
                
                // Remove streaming indicator if present
                const existingIndicator = output.querySelector('.streaming-indicator');
                if (existingIndicator) {{
                    existingIndicator.remove();
                }}
                
                const span = document.createElement('span');
                span.style.color = '{color}';
                span.textContent = {escaped_text};
                output.appendChild(span);
                
                // Always auto-scroll for real-time updates
                output.scrollTop = output.scrollHeight;
            }})();
        """
        # Execute immediately - don't queue
        self.web_view.page().runJavaScript(script)
    
    def _start_streaming_indicator(self):
        """Start showing streaming dots like Ollama"""
        if self.streaming_indicator:
            return
        
        self._dot_count = 0
        
        def update_dots():
            if not self.waiting_for_ai:
                self._stop_streaming_indicator()
                return
            
            self._dot_count = (self._dot_count + 1) % 3
            dots = "." * (self._dot_count + 1)
            
            script = f"""
                (function() {{
                    const output = document.getElementById('terminal-output');
                    if (!output) return;
                    
                    // Remove old indicator
                    const old = output.querySelector('.streaming-indicator');
                    if (old) old.remove();
                    
                    // Add new indicator
                    const span = document.createElement('span');
                    span.className = 'streaming-indicator';
                    span.style.color = '#60a5fa';
                    span.textContent = '{dots}';
                    output.appendChild(span);
                    output.scrollTop = output.scrollHeight;
                }})();
            """
            self.web_view.page().runJavaScript(script)
            
            # Schedule next update
            if self.waiting_for_ai:
                QTimer.singleShot(500, update_dots)
        
        # Start the animation
        update_dots()
    
    def _stop_streaming_indicator(self):
        """Stop streaming indicator"""
        if self.streaming_indicator:
            try:
                QTimer.singleShot(0, lambda: None)  # Cancel if possible
            except:
                pass
            self.streaming_indicator = None
        
        # Remove indicator from DOM
        script = """
            (function() {
                const output = document.getElementById('terminal-output');
                if (!output) return;
                const indicator = output.querySelector('.streaming-indicator');
                if (indicator) indicator.remove();
            })();
        """
        self.web_view.page().runJavaScript(script)
    
    def _start_ai_timeout(self):
        """Start a timeout to reset waiting state if detection fails"""
        self._cancel_ai_timeout()
        DEBUG_LOGGER.debug(f"[TIMEOUT] Starting AI timeout (30s) - waiting_for_ai={self.waiting_for_ai}")
        # Set timeout for 30 seconds - if no "You>" prompt detected, reset anyway
        def timeout_reset():
            if self.waiting_for_ai:
                DEBUG_LOGGER.warning(f"[TIMEOUT] AI timeout (30s): resetting waiting state (no 'You>' prompt detected)")
                DEBUG_LOGGER.warning(f"[TIMEOUT] State at timeout: last_output_time={self.last_output_time:.3f}, last_ai_line_time={self.last_ai_line_time:.3f}")
                self.waiting_for_ai = False
                self._stop_streaming_indicator()
            else:
                DEBUG_LOGGER.debug(f"[TIMEOUT] AI timeout triggered but waiting_for_ai=False (already reset)")
        
        # Use QTimer object for proper cancellation
        self.ai_timeout_id = QTimer()
        self.ai_timeout_id.setSingleShot(True)
        self.ai_timeout_id.timeout.connect(timeout_reset)
        self.ai_timeout_id.start(30000)  # 30 second timeout
    
    def _cancel_ai_timeout(self):
        """Cancel the AI timeout"""
        if self.ai_timeout_id:
            try:
                self.ai_timeout_id.stop()
                self.ai_timeout_id.deleteLater()
            except:
                pass
            self.ai_timeout_id = None
    
    def _reset_inactivity_timeout(self):
        """Reset the inactivity timeout - called when we see output"""
        self._cancel_inactivity_timeout()
        if not self.waiting_for_ai:
            DEBUG_LOGGER.debug(f"[TIMEOUT] Not resetting inactivity timeout - waiting_for_ai=False")
            return
        
        DEBUG_LOGGER.debug(f"[TIMEOUT] Resetting inactivity timeout - last_output_time={self.last_output_time:.3f}")
        
        # If no output for 3 seconds, assume AI finished (even without "You>" prompt)
        def inactivity_check():
            if not self.waiting_for_ai:
                DEBUG_LOGGER.debug(f"[TIMEOUT] Inactivity check skipped - waiting_for_ai=False")
                return
            
            import time
            current_time = time.time()
            time_since_output = current_time - self.last_output_time
            time_since_ai = current_time - self.last_ai_line_time if self.last_ai_line_time > 0 else 999
            
            # Deduplication: Use generic message type key to prevent duplicate logs
            check_log_key = "timeout_inactivity_check"
            if check_log_key not in self._last_log_times or (current_time - self._last_log_times[check_log_key]) >= 2.0:
                DEBUG_LOGGER.debug(f"[TIMEOUT] Inactivity check: time_since_output={time_since_output:.3f}s, time_since_ai={time_since_ai:.3f}s")
                self._last_log_times[check_log_key] = current_time
            
            # If no output for 3 seconds OR no AI output for 3 seconds, reset
            if time_since_output >= 2.5 or (time_since_ai >= 2.5 and self.last_ai_line_time > 0):
                # Deduplication: Use generic message type key
                inactivity_log_key = "timeout_inactivity_detected"
                if inactivity_log_key not in self._last_log_times or (current_time - self._last_log_times[inactivity_log_key]) >= 2.0:
                    DEBUG_LOGGER.warning(f"[TIMEOUT] Inactivity detected (output: {time_since_output:.1f}s, AI: {time_since_ai:.1f}s): resetting waiting state")
                    self._last_log_times[inactivity_log_key] = current_time
                self.waiting_for_ai = False
                self._stop_streaming_indicator()
                self._cancel_ai_timeout()
                self.last_ai_line_time = 0
            else:
                # Check again in 500ms for faster response
                DEBUG_LOGGER.debug(f"[TIMEOUT] Scheduling next inactivity check in 500ms")
                self.inactivity_timeout_id = QTimer()
                self.inactivity_timeout_id.setSingleShot(True)
                self.inactivity_timeout_id.timeout.connect(inactivity_check)
                self.inactivity_timeout_id.start(500)
        
        # Start checking after 3 seconds of inactivity (shorter for faster recovery)
        DEBUG_LOGGER.debug(f"[TIMEOUT] Starting inactivity timeout - will check in 3 seconds")
        self.inactivity_timeout_id = QTimer()
        self.inactivity_timeout_id.setSingleShot(True)
        self.inactivity_timeout_id.timeout.connect(inactivity_check)
        self.inactivity_timeout_id.start(3000)
    
    def _cancel_inactivity_timeout(self):
        """Cancel the inactivity timeout"""
        if self.inactivity_timeout_id:
            try:
                self.inactivity_timeout_id.stop()
                self.inactivity_timeout_id.deleteLater()
            except:
                pass
            self.inactivity_timeout_id = None
    
    def _open_4dllm(self):
        """Open 4DLLM file - safe with error handling (also supports GGUF for universal access)"""
        try:
            DEBUG_LOGGER.info("Opening file dialog (supports both .4dllm and .gguf)...")
            file_path, _ = QFileDialog.getOpenFileName(
                self, "Open Model File", "", 
                "Model Files (*.4dllm *.gguf);;4DLLM Files (*.4dllm);;GGUF Files (*.gguf);;All Files (*)"
            )
            if file_path:
                file_path_obj = Path(file_path)
                DEBUG_LOGGER.info(f"Selected file: {file_path_obj}")
                
                # Validate file exists
                if not file_path_obj.exists():
                    self._show_error_dialog("File Not Found", f"The selected file does not exist:\n{file_path_obj}", "ERR-RUNNER-FILE-NOT-FOUND-001")
                    return
                
                # Determine file type from extension
                file_ext = file_path_obj.suffix.lower()
                is_gguf = file_ext == '.gguf'
                is_4dllm = file_ext == '.4dllm'
                
                if not (is_gguf or is_4dllm):
                    self._show_error_dialog("Unsupported File Type", 
                                      f"Selected file must be a .4dllm or .gguf file.\nGot: {file_ext}", "ERR-RUNNER-UNSUPPORTED-TYPE-001")
                    return
                
                # Set file path and type
                self.run_path = file_path_obj
                self.is_gguf_file = is_gguf
                
                # Also update gguf_path if it's a GGUF file (for compatibility with build tab)
                if is_gguf:
                    self.gguf_path = file_path_obj
                
                # Update UI safely
                try:
                    file_name_escaped = file_path_obj.name.replace("'", "\\'").replace("\\", "\\\\")
                    file_type_label = 'GGUF' if is_gguf else '4DLLM'
                    file_type_escaped = file_type_label.replace("'", "\\'")
                    update_js = f"""
                        const el = document.getElementById('selected-file');
                        el.innerHTML = '{file_name_escaped}<br><span style="font-size: 11px; color: #64748b;">({file_type_escaped} file)</span>';
                    """
                    self._execute_js(update_js)
                    DEBUG_LOGGER.info(f"Updated UI with file: {file_path_obj.name} (type: {file_type_label})")
                except Exception as ui_err:
                    DEBUG_LOGGER.error(f"Error updating UI: {ui_err}", exc_info=True)
                    # Still set the path even if UI update fails
                
                # Add to recent files (in background to prevent freeze)
                def add_to_recent():
                    try:
                        recent_files_js = f"""
                            const recentEl = document.getElementById('recent-files');
                            if (recentEl) {{
                                const currentText = recentEl.textContent || '';
                                const fileName = {json.dumps(file_path_obj.name)};
                                if (!currentText.includes(fileName)) {{
                                    recentEl.textContent = (currentText.trim() ? currentText + '\\n' : '') + fileName;
                                }}
                            }}
                        """
                        QTimer.singleShot(0, lambda: self._execute_js(recent_files_js))
                    except Exception as e:
                        DEBUG_LOGGER.error(f"Error adding to recent files: {e}")
                
                # Run in background thread
                import threading
                threading.Thread(target=add_to_recent, daemon=True).start()
                
        except Exception as e:
            import traceback
            DEBUG_LOGGER.error(f"Error in _open_4dllm: {e}", exc_info=True)
            self._show_error_dialog("Error", f"Failed to open 4DLLM file:\n{e}", f"ERR-RUNNER-OPEN-4DLLM-001\n\n{traceback.format_exc()}")
    
    def _open_gguf(self):
        """Open GGUF file - safe with error handling (also supports 4DLLM for universal access)"""
        try:
            DEBUG_LOGGER.info("Opening file dialog (supports both .4dllm and .gguf)...")
            file_path, _ = QFileDialog.getOpenFileName(
                self, "Open Model File", "", 
                "Model Files (*.4dllm *.gguf);;GGUF Files (*.gguf);;4DLLM Files (*.4dllm);;All Files (*)"
            )
            if file_path:
                file_path_obj = Path(file_path)
                DEBUG_LOGGER.info(f"Selected file: {file_path_obj}")
                
                # Validate file exists
                if not file_path_obj.exists():
                    self._show_error_dialog("File Not Found", f"The selected file does not exist:\n{file_path_obj}", "ERR-RUNNER-FILE-NOT-FOUND-001")
                    return
                
                # Determine file type from extension
                file_ext = file_path_obj.suffix.lower()
                is_gguf = file_ext == '.gguf'
                is_4dllm = file_ext == '.4dllm'
                
                if not (is_gguf or is_4dllm):
                    self._show_error_dialog("Unsupported File Type", 
                                      f"Selected file must be a .4dllm or .gguf file.\nGot: {file_ext}", "ERR-RUNNER-UNSUPPORTED-TYPE-001")
                    return
                
                # Set file paths (for both runner and build tab)
                self.run_path = file_path_obj
                self.is_gguf_file = is_gguf
                
                # Also update gguf_path if it's a GGUF file (for compatibility with build tab)
                if is_gguf:
                    self.gguf_path = file_path_obj
                
                # Update UI safely
                try:
                    file_name_escaped = file_path_obj.name.replace("'", "\\'").replace("\\", "\\\\")
                    file_type_label = 'GGUF' if is_gguf else '4DLLM'
                    file_type_escaped = file_type_label.replace("'", "\\'")
                    # Update selected file display (for Run tab)
                    update_js = f"""
                        const el = document.getElementById('selected-file');
                        if (el) {{
                            el.innerHTML = '{file_name_escaped}<br><span style="font-size: 11px; color: #64748b;">({file_type_escaped} file)</span>';
                        }}
                    """
                    self._execute_js(update_js)
                    # Also update if there's a gguf-file element
                    self._execute_js(f"""
                        const ggufEl = document.getElementById('gguf-file');
                        if (ggufEl) {{
                            ggufEl.textContent = '{file_name_escaped}';
                        }}
                    """)
                    DEBUG_LOGGER.info(f"Updated UI with file: {file_path_obj.name} (type: {file_type_label})")
                except Exception as ui_err:
                    DEBUG_LOGGER.error(f"Error updating UI: {ui_err}", exc_info=True)
                
                # Add to recent files (in background to prevent freeze)
                def add_to_recent():
                    try:
                        recent_files_js = f"""
                            const recentEl = document.getElementById('recent-files');
                            if (recentEl) {{
                                const currentText = recentEl.textContent || '';
                                const fileName = {json.dumps(file_path_obj.name)};
                                if (!currentText.includes(fileName)) {{
                                    recentEl.textContent = (currentText.trim() ? currentText + '\\n' : '') + fileName;
                                }}
                            }}
                        """
                        QTimer.singleShot(0, lambda: self._execute_js(recent_files_js))
                    except Exception as e:
                        DEBUG_LOGGER.error(f"Error adding to recent files: {e}")
                
                # Run in background thread
                import threading
                threading.Thread(target=add_to_recent, daemon=True).start()
                
        except Exception as e:
            import traceback
            DEBUG_LOGGER.error(f"Error in _open_gguf: {e}", exc_info=True)
            self._show_error_dialog("Error", f"Failed to open GGUF file:\n{e}", f"ERR-RUNNER-OPEN-GGUF-001\n\n{traceback.format_exc()}")
    
    def _select_file(self):
        """Select file for running - supports both .4dllm and .gguf"""
        try:
            DEBUG_LOGGER.info("Opening file dialog for runner (supports .4dllm and .gguf)...")
            file_path, _ = QFileDialog.getOpenFileName(
                self, "Open Model File", "", 
                "Model Files (*.4dllm *.gguf);;4DLLM Files (*.4dllm);;GGUF Files (*.gguf);;All Files (*)"
            )
            if file_path:
                file_path_obj = Path(file_path)
                DEBUG_LOGGER.info(f"Selected file for running: {file_path_obj}")
                
                # Validate file exists
                if not file_path_obj.exists():
                    self._show_error_dialog("File Not Found", f"The selected file does not exist:\n{file_path_obj}", "ERR-RUNNER-FILE-NOT-FOUND-001")
                    return
                
                # Determine file type
                file_ext = file_path_obj.suffix.lower()
                is_gguf = file_ext == '.gguf'
                is_4dllm = file_ext == '.4dllm'
                
                if not (is_gguf or is_4dllm):
                    self._show_error_dialog("Unsupported File Type", 
                                      f"Selected file must be a .4dllm or .gguf file.\nGot: {file_ext}", "ERR-RUNNER-UNSUPPORTED-TYPE-001")
                    return
                
                # Set file path and type
                self.run_path = file_path_obj
                self.is_gguf_file = is_gguf
                
                # Also update gguf_path if it's a GGUF file (for compatibility with build tab)
                if is_gguf:
                    self.gguf_path = file_path_obj
                
                # Update UI safely
                try:
                    file_name_escaped = file_path_obj.name.replace("'", "\\'").replace("\\", "\\\\")
                    file_type_label = 'GGUF' if is_gguf else '4DLLM'
                    file_type_escaped = file_type_label.replace("'", "\\'")
                    update_js = f"""
                        const el = document.getElementById('selected-file');
                        el.innerHTML = '{file_name_escaped}<br><span style="font-size: 11px; color: #64748b;">({file_type_escaped} file)</span>';
                    """
                    self._execute_js(update_js)
                    DEBUG_LOGGER.info(f"Updated UI with file: {file_path_obj.name} (type: {file_type_label})")
                except Exception as ui_err:
                    DEBUG_LOGGER.error(f"Error updating UI: {ui_err}", exc_info=True)
                
                # Add to recent files (in background to prevent freeze)
                def add_to_recent():
                    try:
                        recent_files_js = f"""
                            const recentEl = document.getElementById('recent-files');
                            if (recentEl) {{
                                const currentText = recentEl.textContent || '';
                                const fileName = {json.dumps(file_path_obj.name)};
                                if (!currentText.includes(fileName)) {{
                                    recentEl.textContent = (currentText.trim() ? currentText + '\\n' : '') + fileName;
                                }}
                            }}
                        """
                        QTimer.singleShot(0, lambda: self._execute_js(recent_files_js))
                    except Exception as e:
                        DEBUG_LOGGER.error(f"Error adding to recent files: {e}")
                
                # Run in background thread
                import threading
                threading.Thread(target=add_to_recent, daemon=True).start()
                
        except Exception as e:
            import traceback
            DEBUG_LOGGER.error(f"Error selecting file: {e}", exc_info=True)
            self._show_error_dialog("Error", f"Failed to select file:\n{e}", f"ERR-RUNNER-SELECT-FILE-001\n\n{traceback.format_exc()}")
    
    def _run_model(self):
        if self.proc or not self.run_path:
            if not self.run_path:
                self._show_error_dialog("No File Selected", "Please select a .4dllm or .gguf file first.", "ERR-RUNNER-NO-FILE-001")
            return
        
        # Clear terminal
        self._execute_js("document.getElementById('terminal-output').textContent = '';")
        
        cmd = self._build_command()
        env = os.environ.copy()
        env['PYTHONUNBUFFERED'] = '1'
        env['PYTHONIOENCODING'] = 'utf-8'
        
        # Ensure unbuffered Python
        if cmd[0] == sys.executable:
            cmd = [cmd[0], '-u'] + cmd[1:]
        
        try:
            self._append_terminal(f"Starting: {' '.join(shlex.quote(str(arg)) for arg in cmd)}\n", "info")
            
            # CRITICAL: Line-buffered for immediate output
            self.proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                stdin=subprocess.PIPE,
                text=True,
                bufsize=1,  # Line buffered for immediate output
                env=env,
                universal_newlines=True,
                cwd=str(Path(__file__).parent)
            )
            
            # Make stdout non-blocking for faster reads (Unix only)
            if HAS_FCNTL and sys.platform != "win32":
                try:
                    flags = fcntl.fcntl(self.proc.stdout.fileno(), fcntl.F_GETFL)
                    fcntl.fcntl(self.proc.stdout.fileno(), fcntl.F_SETFL, flags | os.O_NONBLOCK)
                except Exception as e:
                    DEBUG_LOGGER.debug(f"Could not set non-blocking mode: {e}")
            
            # Start reader thread
            self.reader_thread = OutputReaderThread(self.proc)
            self.reader_thread.outputReceived.connect(self._append_terminal)
            self.reader_thread.finished.connect(self._on_process_finished)
            self.reader_thread.start()
            
            self._append_terminal("Process started. Waiting for output...\n", "info")
        except Exception as e:
            import traceback
            error_msg = f"Failed to start process: {str(e)}"
            DEBUG_LOGGER.error(error_msg, exc_info=True)
            self._show_error_dialog("Run Failed", error_msg, f"ERR-RUNNER-START-001\n\n{traceback.format_exc()}")
            self._append_terminal(f"ERROR: {error_msg}\n", "error")
    
    def _stop_model(self):
        if not self.proc:
            return
        
        try:
            # Stop reader thread first
            if self.reader_thread:
                self.reader_thread.stop()
                self.reader_thread.wait(1000)  # Wait up to 1 second
            
            # Close stdin to signal termination
            if self.proc.stdin:
                try:
                    self.proc.stdin.close()
                except:
                    pass
            
            # Terminate process
            self.proc.terminate()
            time.sleep(0.5)
            
            # Force kill if still running
            if self.proc.poll() is None:
                self.proc.kill()
                time.sleep(0.1)
            
            self._append_terminal("\n[Process terminated]\n", "warning")
        except Exception as e:
            DEBUG_LOGGER.error(f"Error stopping process: {e}", exc_info=True)
        
        # Always clean up state
        self._stop_streaming_indicator()
        self._cancel_ai_timeout()
        self._cancel_inactivity_timeout()
        self.waiting_for_ai = False
        self.last_ai_line_time = 0
        self.proc = None
        self.reader_thread = None
    
    def _copy_command(self):
        if not self.run_path:
            QMessageBox.warning(self, "No File", "Select a .4dllm or .gguf file first.")
            return
        cmd = self._build_command()
        # For GGUF files, the command includes a temp script path which isn't useful to copy
        # So we'll provide a simplified version
        if self.is_gguf_file:
            cmd_str = f"# GGUF file: {self.run_path}\n# Use llama-cpp-python to load and run this file"
            QApplication.clipboard().setText(cmd_str)
            QMessageBox.information(self, "Copied", "GGUF file path copied to clipboard!\nNote: GGUF files require llama-cpp-python to run.")
        else:
            cmd_str = " ".join(shlex.quote(str(arg)) for arg in cmd)
            QApplication.clipboard().setText(cmd_str)
            QMessageBox.information(self, "Copied", "Command copied to clipboard!")
    
    def _select_gguf(self):
        self._open_gguf()
        if self.gguf_path:
            # Update build tab GGUF display
            self._execute_js(f"document.getElementById('build-gguf-file').textContent = '{self.gguf_path.name}';")
    
    def _build_package(self):
        """Build 4DLLM package using builder"""
        if not builder_module:
            QMessageBox.warning(self, "Error", "Builder module not available!")
            return
        
        if not self.gguf_path or not self.gguf_path.exists():
            QMessageBox.warning(self, "Error", "Please select a GGUF file first!")
            return
        
        # Get output path from UI
        output_path = None
        def get_output_path():
            nonlocal output_path
            script = "document.getElementById('build-output-path').value;"
            self.web_view.page().runJavaScript(script, lambda result: setattr(self, '_js_result', result))
            time.sleep(0.1)  # Wait for JS execution
            output_path = getattr(self, '_js_result', None) if hasattr(self, '_js_result') else None
        
        get_output_path()
        
        if not output_path:
            output_path, _ = QFileDialog.getSaveFileName(
                self, "Save 4DLLM File", "", "4DLLM Files (*.4dllm);;All Files (*)"
            )
            if not output_path:
                return
        
        # Get compression settings
        compress_scripts = True
        compress_metadata = True
        
        try:
            self._append_terminal(f"Building 4DLLM package...\n", "info")
            self._append_terminal(f"GGUF: {self.gguf_path.name}\n", "info")
            self._append_terminal(f"Output: {output_path}\n", "info")
            
            # Create builder
            builder = builder_module.FourDLLMBuilderV2(str(self.gguf_path))
            
            # Get scripts from JavaScript
            scripts_data = []
            def get_scripts():
                nonlocal scripts_data
                script = "JSON.stringify(window.builderScripts || []);"
                self.web_view.page().runJavaScript(script, lambda result: setattr(self, '_scripts_result', result))
                time.sleep(0.1)
                if hasattr(self, '_scripts_result'):
                    try:
                        scripts_data = json.loads(self._scripts_result)
                    except:
                        scripts_data = []
            
            get_scripts()
            
            # Add scripts
            if scripts_data:
                for script in scripts_data:
                    script_item = builder_module.ScriptItem(
                        name=script.get('name', 'script'),
                        content=script.get('content', ''),
                        priority=script.get('priority', 0),
                        enabled=script.get('enabled', True),
                        source_path=script.get('source_path', ''),
                        description=script.get('description', '')
                    )
                    builder.add_script(script_item)
                self._append_terminal(f"Added {len(scripts_data)} script(s)\n", "info")
            
            # Build
            result_path = builder.build(output_path, compress_scripts, compress_metadata)
            file_size = Path(result_path).stat().st_size / (1024 * 1024)
            
            self._append_terminal(f"✓ Build successful!\n", "success")
            self._append_terminal(f"File: {Path(result_path).name}\n", "info")
            self._append_terminal(f"Size: {file_size:.2f} MB\n", "info")
            
            QMessageBox.information(
                self, "Success",
                f"4DLLM file created successfully!\n\n"
                f"File: {Path(result_path).name}\n"
                f"Size: {file_size:.2f} MB"
            )
        except Exception as e:
            error_msg = f"Build failed: {str(e)}"
            DEBUG_LOGGER.error(error_msg, exc_info=True)
            self._append_terminal(f"✗ {error_msg}\n", "error")
            QMessageBox.critical(self, "Build Failed", error_msg)
    
    def _load_modules(self):
        """Load scripts from modules/ folder"""
        if not builder_module:
            QMessageBox.warning(self, "Error", "Builder module not available!")
            return
        
        modules_dir = Path(__file__).parent / "modules"
        if not modules_dir.exists():
            QMessageBox.information(self, "Info", f"Modules folder not found at: {modules_dir}")
            return
        
        try:
            scripts_loaded = []
            for script_file in sorted(modules_dir.glob("*.py")):
                try:
                    content = script_file.read_text(encoding='utf-8')
                    script_item = builder_module.ScriptItem(
                        name=script_file.stem,
                        content=content,
                        priority=0,
                        enabled=True,
                        source_path=str(script_file),
                        description=f"Loaded from {script_file.name}"
                    )
                    scripts_loaded.append({
                        'name': script_item.name,
                        'content': script_item.content,
                        'priority': script_item.priority,
                        'enabled': script_item.enabled,
                        'source_path': script_item.source_path,
                        'description': script_item.description
                    })
                except Exception as e:
                    DEBUG_LOGGER.warning(f"Failed to load {script_file}: {e}")
            
            if scripts_loaded:
                # Send to JavaScript
                scripts_json = json.dumps(scripts_loaded)
                self._execute_js(f"window.builderScripts = {scripts_json}; updateScriptsList();")
                self._execute_js(f"document.getElementById('modules-status').textContent = 'Loaded {len(scripts_loaded)} script(s)';")
                QMessageBox.information(self, "Success", f"Loaded {len(scripts_loaded)} script(s) from modules/")
            else:
                QMessageBox.information(self, "Info", "No Python scripts found in modules/ folder")
        except Exception as e:
            DEBUG_LOGGER.error(f"Error loading modules: {e}", exc_info=True)
            QMessageBox.critical(self, "Error", f"Failed to load modules: {e}")
    
    def _add_script(self, name: str, content: str, priority: int, enabled: bool):
        """Add a script to builder"""
        script_data = {
            'name': name,
            'content': content,
            'priority': priority,
            'enabled': enabled,
            'source_path': '',
            'description': ''
        }
        scripts_json = json.dumps([script_data])
        self._execute_js(f"window.builderScripts.push({scripts_json}[0]); updateScriptsList();")
    
    def _remove_script(self, name: str):
        """Remove a script from builder"""
        self._execute_js(f"window.builderScripts = window.builderScripts.filter(s => s.name !== '{name}'); updateScriptsList();")
    
    def _load_editor_file(self):
        """Load a file for editing (.gguf or .4dllm) - runs in background thread to prevent freeze"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Load File for Editing", "", 
            "All Supported (*.gguf *.4dllm);;GGUF Files (*.gguf);;4DLLM Files (*.4dllm);;All Files (*)"
        )
        if not file_path:
            return
        
        file_path_obj = Path(file_path)
        file_size_mb = file_path_obj.stat().st_size / (1024*1024)
        self._execute_js(f"document.getElementById('editor-file-info').textContent = 'Loading: {file_path_obj.name} ({file_size_mb:.2f} MB)...';")
        self._execute_js("document.getElementById('editor-content').innerHTML = '<div style=\"padding: 40px; text-align: center; color: #06b6d4;\"><div style=\"font-size: 18px; margin-bottom: 12px;\">⏳ Loading file...</div><div style=\"font-size: 13px;\">Please wait, this may take a moment for large files</div></div>';")
        
        # Load in background thread to prevent UI freeze
        def load_in_thread():
            try:
                DEBUG_LOGGER.info(f"Loading file for editing: {file_path_obj}")
                # Detect file type and load accordingly
                if file_path_obj.suffix.lower() == '.4dllm':
                    self._load_4dllm_for_editing(file_path_obj)
                elif file_path_obj.suffix.lower() == '.gguf':
                    self._load_gguf_for_editing(file_path_obj)
                else:
                    error_msg = "Unsupported file type!"
                    QTimer.singleShot(0, lambda: self._show_error_dialog("Editor Error", error_msg, "ERR-EDITOR-005"))
                    QTimer.singleShot(0, lambda: self._execute_js("document.getElementById('editor-file-info').textContent = 'Error: Unsupported file type';"))
            except Exception as e:
                import traceback
                error_msg = f"Failed to load file: {e}"
                error_code = "ERR-EDITOR-006"
                traceback_str = traceback.format_exc()
                DEBUG_LOGGER.error(f"[{error_code}] {error_msg}", exc_info=True)
                QTimer.singleShot(0, lambda: self._show_error_dialog("Editor Error", error_msg, f"{error_code}\n\n{traceback_str}"))
                QTimer.singleShot(0, lambda: self._execute_js("document.getElementById('editor-file-info').textContent = 'Error loading file';"))
        
        # Start loading in background thread
        import threading
        thread = threading.Thread(target=load_in_thread, daemon=True)
        thread.start()
    
    def _load_4dllm_for_editing(self, file_path: Path):
        """Load 4DLLM file for editing - runs in background thread"""
        try:
            # Extract GGUF from 4DLLM for editing
            QTimer.singleShot(0, lambda: self._append_terminal(f"Loading 4DLLM file: {file_path.name}\n", "info"))
            # Use runner utilities to extract GGUF
            if runner_module:
                entries, toc_offset = runner_module.read_and_validate_toc(file_path)
                gguf_entry = next((e for e in entries if e.section_type == runner_module.SECTION_GGUF_DATA), None)
                if gguf_entry:
                    QTimer.singleShot(0, lambda: self._append_terminal(f"Found GGUF section in 4DLLM file\n", "info"))
                    
                    # Extract GGUF to temp file for editing
                    import tempfile
                    temp_gguf = tempfile.NamedTemporaryFile(delete=False, suffix='.gguf')
                    temp_gguf_path = Path(temp_gguf.name)
                    temp_gguf.close()
                    
                    # Read GGUF section
                    section = runner_module.read_section_small(file_path, gguf_entry)
                    if section:
                        try:
                            # Decode and validate the section
                            gguf_data = runner_module.decode_and_validate(section)
                            with open(temp_gguf_path, 'wb') as f:
                                f.write(gguf_data)
                        except Exception as e:
                            import traceback
                            error_msg = f"Failed to decode GGUF section: {e}"
                            error_code = "ERR-EDITOR-4DLLM-001"
                            traceback_str = traceback.format_exc()
                            DEBUG_LOGGER.error(f"[{error_code}] {error_msg}", exc_info=True)
                            QTimer.singleShot(0, lambda: self._show_error_dialog("Editor Error", error_msg, f"{error_code}\n\n{traceback_str}"))
                            return
                        
                        # Load metadata from 4DLLM
                        metadata_entry = next((e for e in entries if e.section_type == runner_module.SECTION_METADATA), None)
                        metadata = {}
                        if metadata_entry:
                            try:
                                meta_section = runner_module.read_section_small(file_path, metadata_entry)
                                if meta_section:
                                    meta_data = runner_module.decode_and_validate(meta_section)
                                    metadata = json.loads(meta_data.decode('utf-8'))
                            except Exception as e:
                                DEBUG_LOGGER.warning(f"Failed to load 4DLLM metadata section: {e}, using empty metadata", exc_info=True)
                                metadata = {}
                        
                        # Also load GGUF metadata
                        if editor_module:
                            try:
                                editor = editor_module.GGUFEditor(str(temp_gguf_path))
                                try:
                                    gguf_metadata = editor.load_metadata_only() if hasattr(editor, 'load_metadata_only') else editor.load()
                                except Exception as e:
                                    DEBUG_LOGGER.warning(f"Failed to load metadata-only, trying full load: {e}")
                                    try:
                                        gguf_metadata = editor.load()
                                    except Exception as e2:
                                        DEBUG_LOGGER.error(f"Failed to load GGUF metadata: {e2}", exc_info=True)
                                        gguf_metadata = {}
                                
                                # Ensure metadata is a dict
                                if not isinstance(gguf_metadata, dict):
                                    DEBUG_LOGGER.warning(f"GGUF metadata is not a dict: {type(gguf_metadata)}, using empty dict")
                                    gguf_metadata = {}
                                
                                # Merge metadata (4DLLM metadata takes precedence)
                                if not isinstance(metadata, dict):
                                    metadata = {}
                                metadata.update(gguf_metadata)
                                
                                # Store editor instance and file paths
                                self._editor_instance = editor
                                self._editor_file_path = file_path  # Original 4DLLM path
                                self._editor_temp_gguf = temp_gguf_path  # Temp GGUF for editing
                                self._editor_metadata = metadata
                                self._editor_file_type = "4dllm"
                                
                                # Update UI on main thread
                                QTimer.singleShot(0, lambda: self._display_editor_metadata(metadata, file_path))
                                file_size_mb = file_path.stat().st_size / (1024*1024)
                                QTimer.singleShot(0, lambda: self._execute_js(f"document.getElementById('editor-file-info').textContent = 'File: {file_path.name} ({file_size_mb:.2f} MB)';"))
                            except Exception as e:
                                import traceback
                                error_msg = f"Failed to create editor instance: {e}"
                                error_code = "ERR-EDITOR-4DLLM-002"
                                traceback_str = traceback.format_exc()
                                DEBUG_LOGGER.error(f"[{error_code}] {error_msg}", exc_info=True)
                                QTimer.singleShot(0, lambda: self._show_error_dialog("Editor Error", error_msg, f"{error_code}\n\n{traceback_str}"))
                        else:
                            error_msg = "Editor module not available"
                            QTimer.singleShot(0, lambda: self._show_error_dialog("Editor Error", error_msg, "ERR-EDITOR-4DLLM-003"))
                    else:
                        error_msg = "Failed to read GGUF section"
                        QTimer.singleShot(0, lambda: self._show_error_dialog("Editor Error", error_msg, "ERR-EDITOR-4DLLM-004"))
                else:
                    error_msg = "No GGUF section found in 4DLLM file"
                    QTimer.singleShot(0, lambda: self._show_error_dialog("Editor Error", error_msg, "ERR-EDITOR-4DLLM-005"))
            else:
                error_msg = "Runner module not available"
                QTimer.singleShot(0, lambda: self._show_error_dialog("Editor Error", error_msg, "ERR-EDITOR-4DLLM-006"))
        except Exception as e:
            import traceback
            error_msg = f"Failed to load 4DLLM file: {e}"
            error_code = "ERR-EDITOR-4DLLM-007"
            traceback_str = traceback.format_exc()
            DEBUG_LOGGER.error(f"[{error_code}] {error_msg}", exc_info=True)
            QTimer.singleShot(0, lambda: self._show_error_dialog("Editor Error", error_msg, f"{error_code}\n\n{traceback_str}"))
    
    def _load_gguf_for_editing(self, file_path: Path):
        """Load GGUF file for editing - runs in background thread"""
        import traceback
        
        if not editor_module:
            error_msg = "Editor module not available!"
            DEBUG_LOGGER.error(f"[ERR-EDITOR-001] {error_msg}")
            QTimer.singleShot(0, lambda: self._show_error_dialog("Editor Error", error_msg, "ERR-EDITOR-001"))
            QTimer.singleShot(0, lambda: self._execute_js("document.getElementById('editor-file-info').textContent = 'Error: Editor module not available';"))
            return
        
        try:
            QTimer.singleShot(0, lambda: self._append_terminal(f"Loading GGUF file: {file_path.name}\n", "info"))
            # Create editor instance
            try:
                editor = editor_module.GGUFEditor(str(file_path))
            except Exception as e:
                error_msg = f"Failed to create GGUF editor instance: {e}"
                error_code = "ERR-EDITOR-002"
                traceback_str = traceback.format_exc()
                DEBUG_LOGGER.error(f"[{error_code}] {error_msg}", exc_info=True)
                QTimer.singleShot(0, lambda: self._show_error_dialog("Editor Error", error_msg, f"{error_code}\n\n{traceback_str}"))
                QTimer.singleShot(0, lambda: self._execute_js("document.getElementById('editor-file-info').textContent = 'Error: Failed to create editor';"))
                return
            
            # Load metadata
            try:
                metadata = editor.load_metadata_only() if hasattr(editor, 'load_metadata_only') else editor.load()
            except Exception as e:
                DEBUG_LOGGER.warning(f"Failed to load metadata-only, trying full load: {e}")
                try:
                    metadata = editor.load()
                except Exception as e2:
                    error_msg = f"Failed to load GGUF metadata: {e2}"
                    error_code = "ERR-EDITOR-003"
                    traceback_str = traceback.format_exc()
                    DEBUG_LOGGER.error(f"[{error_code}] {error_msg}", exc_info=True)
                    QTimer.singleShot(0, lambda: self._show_error_dialog("Editor Error", error_msg, f"{error_code}\n\n{traceback_str}"))
                    QTimer.singleShot(0, lambda: self._execute_js("document.getElementById('editor-file-info').textContent = 'Error: Failed to load metadata';"))
                    return
            
            # Ensure metadata is a dict
            if not isinstance(metadata, dict):
                DEBUG_LOGGER.warning(f"Metadata is not a dict, converting: {type(metadata)}")
                metadata = {}
            
            # Store editor instance and file path
            self._editor_instance = editor
            self._editor_file_path = file_path
            self._editor_metadata = metadata
            self._editor_file_type = "gguf"
            
            # Capture values for lambda (thread-safe)
            metadata_copy = metadata.copy() if isinstance(metadata, dict) else {}
            file_path_str = str(file_path)
            file_name = file_path.name
            
            # Get file size safely
            try:
                file_size_mb = file_path.stat().st_size / (1024*1024)
                file_size_str = f"{file_size_mb:.2f} MB"
            except Exception as size_err:
                DEBUG_LOGGER.warning(f"Failed to get file size: {size_err}")
                file_size_str = "Unknown size"
            
            # Update UI on main thread - wrap in try-except to prevent crashes
            def safe_display():
                try:
                    self._display_editor_metadata(metadata_copy, file_path)
                except Exception as display_err:
                    import traceback
                    error_msg = f"Error displaying editor metadata: {display_err}"
                    error_code = "ERR-EDITOR-DISPLAY-001"
                    traceback_str = traceback.format_exc()
                    DEBUG_LOGGER.error(f"[{error_code}] {error_msg}", exc_info=True)
                    self._show_error_dialog("Editor Error", error_msg, f"{error_code}\n\n{traceback_str}")
                    error_html = f"<div style='padding: 40px; text-align: center; color: #f87171;'><div style='font-size: 18px; margin-bottom: 12px;'>❌ Error Displaying Editor</div><div style='font-size: 13px;'>{str(display_err)}</div></div>"
                    try:
                        self._execute_js(f"document.getElementById('editor-content').innerHTML = {json.dumps(error_html)};")
                    except:
                        pass
            
            def safe_update_file_info():
                try:
                    self._execute_js(f"document.getElementById('editor-file-info').textContent = 'File: {file_name} ({file_size_str})';")
                except Exception as js_err:
                    DEBUG_LOGGER.warning(f"Failed to update file info: {js_err}")
            
            QTimer.singleShot(0, safe_display)
            QTimer.singleShot(0, safe_update_file_info)
        except Exception as e:
            error_msg = f"Error loading GGUF for editing: {e}"
            error_code = "ERR-EDITOR-004"
            traceback_str = traceback.format_exc()
            DEBUG_LOGGER.error(f"[{error_code}] {error_msg}", exc_info=True)
            QTimer.singleShot(0, lambda: self._show_error_dialog("Editor Error", error_msg, f"{error_code}\n\n{traceback_str}"))
            QTimer.singleShot(0, lambda: self._execute_js("document.getElementById('editor-file-info').textContent = 'Error loading file';"))
            QTimer.singleShot(0, lambda: self._execute_js("document.getElementById('editor-content').innerHTML = '<div style=\"padding: 40px; text-align: center; color: #f87171;\"><div style=\"font-size: 18px; margin-bottom: 12px;\">❌ Error Loading File</div><div style=\"font-size: 13px;\">Please check the logs for details</div></div>';"))
    
    def _display_editor_metadata(self, metadata: Dict[str, Any], file_path: Path):
        """Display metadata in editor UI - supports easy and advanced modes"""
        # Ensure metadata is a dict
        if not isinstance(metadata, dict):
            DEBUG_LOGGER.warning(f"Metadata is not a dict in _display_editor_metadata: {type(metadata)}, using empty dict")
            metadata = {}
        
        # Default to easy mode - mode switching is handled via refreshEditorDisplay
        # which is called when the user clicks the mode buttons
        mode = getattr(self, '_editor_mode', 'easy')
        
        try:
            if mode == 'advanced':
                self._display_advanced_mode(metadata, file_path)
            else:
                self._display_easy_mode(metadata, file_path)
        except Exception as e:
            DEBUG_LOGGER.error(f"Error in _display_editor_metadata: {e}", exc_info=True)
            error_html = f"<div style='padding: 40px; text-align: center; color: #f87171;'><div style='font-size: 18px; margin-bottom: 12px;'>❌ Error Displaying Editor</div><div style='font-size: 13px;'>{str(e)}</div></div>"
            self._execute_js(f"document.getElementById('editor-content').innerHTML = {json.dumps(error_html)};")
    
    def _display_easy_mode(self, metadata: Dict[str, Any], file_path: Path):
        """Display easy mode editor with system prompt and persona prompt"""
        try:
            # Get file name safely
            file_name = file_path.name if file_path and hasattr(file_path, 'name') else str(file_path) if file_path else "Unknown"
            
            # Extract system and persona prompts
            system_prompt = metadata.get('llama.system_prompt') or metadata.get('chat_template.system_prompt') or ''
            persona_prompt = metadata.get('llama.persona_prompt') or metadata.get('chat_template.persona_prompt') or ''
            
            # Convert to strings if needed
            if not isinstance(system_prompt, str):
                system_prompt = str(system_prompt) if system_prompt else ''
            if not isinstance(persona_prompt, str):
                persona_prompt = str(persona_prompt) if persona_prompt else ''
            
            # Escape HTML in prompts for safe display
            def escape_html(text):
                return str(text).replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;').replace("'", '&#x27;')
            
            system_prompt_escaped = escape_html(system_prompt)
            persona_prompt_escaped = escape_html(persona_prompt)
            
            html = f"""
        <div style='padding: 20px; color: #cbd5e1;'>
            <h3 style='color: #06b6d4; margin-bottom: 20px;'>✨ Easy Editor Mode - {escape_html(file_name)}</h3>
            
            <div style='margin-bottom: 24px; padding: 16px; background: rgba(6, 182, 212, 0.1); border: 1px solid rgba(6, 182, 212, 0.3); border-radius: 10px;'>
                <div style='font-size: 13px; color: #06b6d4; margin-bottom: 8px; font-weight: 600;'>⚙️ System Prompt</div>
                <div style='font-size: 11px; color: #94a3b8; margin-bottom: 12px;'>Define the system behavior and instructions</div>
                <textarea id='editor-system-prompt' style='width: 100%; min-height: 120px; padding: 12px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 8px; color: #e2e8f0; font-family: monospace; font-size: 13px; resize: vertical;'>{system_prompt_escaped}</textarea>
                <div id='system-prompt-count' style='font-size: 11px; color: #64748b; margin-top: 4px; text-align: right;'>{len(system_prompt)} characters</div>
            </div>
            
            <div style='margin-bottom: 24px; padding: 16px; background: rgba(6, 182, 212, 0.1); border: 1px solid rgba(6, 182, 212, 0.3); border-radius: 10px;'>
                <div style='font-size: 13px; color: #06b6d4; margin-bottom: 8px; font-weight: 600;'>👤 Persona Prompt</div>
                <div style='font-size: 11px; color: #94a3b8; margin-bottom: 12px;'>Define the character persona and personality</div>
                <textarea id='editor-persona-prompt' style='width: 100%; min-height: 120px; padding: 12px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 8px; color: #e2e8f0; font-family: monospace; font-size: 13px; resize: vertical;'>{persona_prompt_escaped}</textarea>
                <div id='persona-prompt-count' style='font-size: 11px; color: #64748b; margin-top: 4px; text-align: right;'>{len(persona_prompt)} characters</div>
            </div>
            
            <div style='padding: 12px; background: rgba(15, 23, 42, 0.4); border-radius: 8px; border: 1px solid rgba(71, 85, 105, 0.3);'>
                <div style='font-size: 12px; color: #94a3b8; line-height: 1.6;'>
                    💡 <strong>Tip:</strong> Changes will be saved to both <code>llama.system_prompt</code> and <code>chat_template.system_prompt</code> (and similarly for persona prompts) for maximum compatibility.
                </div>
            </div>
        </div>
        
        <script>
            // Update character counts
            function updateCounts() {{
                const systemEl = document.getElementById('editor-system-prompt');
                const personaEl = document.getElementById('editor-persona-prompt');
                if (systemEl) {{
                    document.getElementById('system-prompt-count').textContent = systemEl.value.length + ' characters';
                }}
                if (personaEl) {{
                    document.getElementById('persona-prompt-count').textContent = personaEl.value.length + ' characters';
                }}
            }}
            
            const systemEl = document.getElementById('editor-system-prompt');
            const personaEl = document.getElementById('editor-persona-prompt');
            if (systemEl) {{
                systemEl.addEventListener('input', updateCounts);
            }}
            if (personaEl) {{
                personaEl.addEventListener('input', updateCounts);
            }}
        </script>
        """
            
            self._execute_js(f"document.getElementById('editor-content').innerHTML = {json.dumps(html)};")
        except Exception as e:
            import traceback
            error_msg = f"Error displaying easy mode: {e}"
            error_code = "ERR-EDITOR-EASY-001"
            traceback_str = traceback.format_exc()
            DEBUG_LOGGER.error(f"[{error_code}] {error_msg}", exc_info=True)
            error_html = f"<div style='padding: 40px; text-align: center; color: #f87171;'><div style='font-size: 18px; margin-bottom: 12px;'>❌ Error Displaying Easy Mode</div><div style='font-size: 13px;'>{str(e)}</div></div>"
            try:
                self._execute_js(f"document.getElementById('editor-content').innerHTML = {json.dumps(error_html)};")
            except:
                pass
    
    def _display_advanced_mode(self, metadata: Dict[str, Any], file_path: Path):
        """Display advanced mode editor with full metadata tree and hack features"""
        try:
            # Get file name safely
            file_name = file_path.name if file_path and hasattr(file_path, 'name') else str(file_path) if file_path else "Unknown"
            
            # Escape HTML in values
            def escape_html(text):
                return str(text).replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;').replace("'", '&#x27;')
            
            def format_value(v):
                if isinstance(v, (dict, list)):
                    return json.dumps(v, indent=2)
                return str(v)
            
            # Create comprehensive advanced mode HTML with hack features
            html = f"""
        <div style='padding: 20px; color: #cbd5e1;'>
            <div style='display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;'>
                <h3 style='color: #06b6d4; margin: 0;'>🔧 Advanced Mode - Metadata Editor (Hack Mode)</h3>
                <div style='padding: 6px 12px; background: rgba(251, 191, 36, 0.2); border: 1px solid rgba(251, 191, 36, 0.4); border-radius: 6px; font-size: 11px; color: #fbbf24; font-weight: 600;'>⚠️ DIRECT METADATA EDITING</div>
            </div>
            
            <!-- Toolbar -->
            <div style='display: flex; gap: 8px; margin-bottom: 16px; padding: 12px; background: rgba(15, 23, 42, 0.4); border-radius: 8px; border: 1px solid rgba(71, 85, 105, 0.3);'>
                <button onclick="window.bridge.advancedRefreshMetadata()" style='padding: 8px 16px; background: linear-gradient(135deg, rgba(51, 65, 85, 0.8), rgba(71, 85, 105, 0.8)); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 6px; color: #e2e8f0; font-weight: 600; cursor: pointer;'>🔄 Refresh Metadata</button>
                <button onclick="window.bridge.advancedAddKey()" style='padding: 8px 16px; background: linear-gradient(135deg, rgba(34, 211, 57, 0.2), rgba(34, 211, 57, 0.3)); border: 1px solid rgba(34, 211, 57, 0.5); border-radius: 6px; color: #34d399; font-weight: 600; cursor: pointer;'>➕ Add Key</button>
                <button onclick="window.bridge.advancedDeleteKey()" style='padding: 8px 16px; background: linear-gradient(135deg, rgba(239, 68, 68, 0.2), rgba(239, 68, 68, 0.3)); border: 1px solid rgba(239, 68, 68, 0.5); border-radius: 6px; color: #f87171; font-weight: 600; cursor: pointer;'>➖ Delete Selected</button>
            </div>
            
            <!-- Search Bar -->
            <div style='margin-bottom: 16px;'>
                <input type='text' id='advanced-search' placeholder='🔍 Search metadata keys or values...' oninput='advancedFilterMetadata()' style='width: 100%; padding: 10px 16px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 8px; color: #e2e8f0; font-size: 13px;'>
            </div>
            
            <!-- Metadata Tree View -->
            <div style='background: rgba(15, 23, 42, 0.4); border-radius: 8px; border: 1px solid rgba(71, 85, 105, 0.3); overflow: hidden; margin-bottom: 16px;'>
                <div style='display: grid; grid-template-columns: 2fr 3fr 1fr; padding: 12px; background: rgba(6, 182, 212, 0.1); border-bottom: 1px solid rgba(71, 85, 105, 0.3); font-weight: 600; color: #06b6d4; font-size: 12px;'>
                    <div>Key</div>
                    <div>Value</div>
                    <div>Type</div>
                </div>
                <div id='advanced-metadata-tree' style='max-height: 400px; overflow-y: auto;'>
        """
            
            # Add metadata items
            for key, value in sorted(metadata.items()):
                value_str = format_value(value)
                if len(value_str) > 150:
                    value_str = value_str[:147] + "..."
                
                value_type = type(value).__name__
                if isinstance(value, list):
                    value_type = f"array[{len(value)}]"
                elif isinstance(value, dict):
                    value_type = f"dict[{len(value)}]"
                
                value_display = escape_html(value_str)
                key_display = escape_html(key)
                
                html += f"""
                    <div class='metadata-row' data-key='{key_display}' onclick='advancedSelectRow(this, {json.dumps(key)}, {json.dumps(value)})' style='display: grid; grid-template-columns: 2fr 3fr 1fr; padding: 10px 12px; border-bottom: 1px solid rgba(71, 85, 105, 0.2); cursor: pointer; transition: background 0.2s;' onmouseover='this.style.background="rgba(6, 182, 212, 0.1)"' onmouseout='if(!this.classList.contains("selected")) this.style.background="transparent"'>
                        <div style='font-weight: 600; color: #22d3ee; font-family: monospace; font-size: 12px;'>{key_display}</div>
                        <div style='color: #94a3b8; font-family: monospace; font-size: 11px; white-space: pre-wrap; word-break: break-word;'>{value_display}</div>
                        <div style='color: #64748b; font-size: 11px; text-align: right;'>{value_type}</div>
                    </div>
                """
            
            html += """
                </div>
            </div>
            
            <!-- Edit Panel -->
            <div style='background: rgba(15, 23, 42, 0.4); border-radius: 8px; border: 1px solid rgba(71, 85, 105, 0.3); padding: 16px;'>
                <div style='font-weight: 600; color: #06b6d4; margin-bottom: 12px; font-size: 14px;'>✏️ Edit Selected Item</div>
                
                <div style='margin-bottom: 12px;'>
                    <label style='display: block; font-size: 12px; color: #94a3b8; margin-bottom: 6px;'>Key:</label>
                    <input type='text' id='advanced-edit-key' placeholder='Metadata key name' style='width: 100%; padding: 10px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 6px; color: #e2e8f0; font-family: monospace; font-size: 13px;'>
                </div>
                
                <div style='margin-bottom: 12px;'>
                    <label style='display: block; font-size: 12px; color: #94a3b8; margin-bottom: 6px;'>Value:</label>
                    <textarea id='advanced-edit-value' placeholder='Metadata value (JSON for arrays/objects)' style='width: 100%; min-height: 120px; padding: 10px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 6px; color: #e2e8f0; font-family: monospace; font-size: 12px; resize: vertical;'></textarea>
                </div>
                
                <div style='margin-bottom: 16px;'>
                    <label style='display: block; font-size: 12px; color: #94a3b8; margin-bottom: 6px;'>Type:</label>
                    <select id='advanced-edit-type' style='width: 100%; padding: 10px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 6px; color: #e2e8f0; font-size: 13px;'>
                        <option value='string'>String</option>
                        <option value='int'>Integer</option>
                        <option value='float'>Float</option>
                        <option value='bool'>Boolean</option>
                        <option value='array'>Array (JSON)</option>
                    </select>
                </div>
                
                <button onclick='advancedSaveItemJS()' style='width: 100%; padding: 12px; background: linear-gradient(135deg, #1e40af 0%, #3b82f6 50%, #06b6d4 100%); border: none; border-radius: 8px; color: #ffffff; font-weight: 600; cursor: pointer; font-size: 13px;'>💾 Save Item</button>
            </div>
            
            <!-- Info Panel -->
            <div style='margin-top: 16px; padding: 12px; background: rgba(6, 182, 212, 0.1); border: 1px solid rgba(6, 182, 212, 0.3); border-radius: 8px;'>
                <div style='font-size: 12px; color: #94a3b8; line-height: 1.6;'>
                    <strong style='color: #06b6d4;'>💡 Advanced Mode Features:</strong><br>
                    • <strong>Double-click</strong> any row to edit it<br>
                    • <strong>Add Key:</strong> Create new metadata keys (hack: add custom keys!)<br>
                    • <strong>Delete Key:</strong> Remove unwanted metadata (hack: clean up GGUF!)<br>
                    • <strong>Edit Values:</strong> Modify any metadata value with type conversion<br>
                    • <strong>Search:</strong> Quickly find keys or values in large metadata<br>
                    • <strong>Type Support:</strong> String, Int, Float, Bool, and JSON Arrays<br>
                    <span style='color: #fbbf24; font-weight: 600;'>⚠️ Warning: Direct metadata editing can break compatibility if misused!</span>
                </div>
            </div>
        </div>
        
        <script>
            let selectedMetadataKey = null;
            let metadataData = """ + json.dumps(metadata) + """;
            
            function advancedSelectRow(element, key, value) {
                // Remove previous selection
                document.querySelectorAll('.metadata-row').forEach(row => {
                    row.classList.remove('selected');
                    row.style.background = 'transparent';
                });
                
                // Select new row
                element.classList.add('selected');
                element.style.background = 'rgba(6, 182, 212, 0.2)';
                selectedMetadataKey = key;
                
                // Populate edit form
                document.getElementById('advanced-edit-key').value = key;
                
                let valueStr = '';
                let valueType = 'string';
                
                if (Array.isArray(value)) {
                    valueStr = JSON.stringify(value, null, 2);
                    valueType = 'array';
                } else if (typeof value === 'object' && value !== null) {
                    valueStr = JSON.stringify(value, null, 2);
                    valueType = 'array'; // Treat objects as JSON
                } else if (typeof value === 'number') {
                    valueStr = String(value);
                    valueType = Number.isInteger(value) ? 'int' : 'float';
                } else if (typeof value === 'boolean') {
                    valueStr = String(value);
                    valueType = 'bool';
                } else {
                    valueStr = String(value);
                    valueType = 'string';
                }
                
                document.getElementById('advanced-edit-value').value = valueStr;
                document.getElementById('advanced-edit-type').value = valueType;
            }
            
            function advancedFilterMetadata() {
                const searchText = document.getElementById('advanced-search').value.toLowerCase();
                const rows = document.querySelectorAll('.metadata-row');
                
                rows.forEach(row => {
                    const key = row.dataset.key.toLowerCase();
                    const value = row.textContent.toLowerCase();
                    
                    if (searchText === '' || key.includes(searchText) || value.includes(searchText)) {
                        row.style.display = 'grid';
                    } else {
                        row.style.display = 'none';
                    }
                });
            }
            
            function advancedSaveItemJS() {
                const key = document.getElementById('advanced-edit-key').value.trim();
                if (!key) {
                    alert('⚠️ Key cannot be empty!');
                    return;
                }
                
                const valueText = document.getElementById('advanced-edit-value').value.trim();
                const valueType = document.getElementById('advanced-edit-type').value;
                
                // Call bridge method with data
                if (window.bridge && window.bridge.advancedSaveItemWithData) {
                    window.bridge.advancedSaveItemWithData(key, valueText, valueType);
                } else {
                    alert('⚠️ Bridge not connected. Please refresh the page.');
                }
            }
            
            // Enable double-click to edit
            document.addEventListener('DOMContentLoaded', function() {
                setTimeout(function() {
                    document.querySelectorAll('.metadata-row').forEach(row => {
                        row.addEventListener('dblclick', function() {
                            const key = this.dataset.key;
                            const value = metadataData[key];
                            advancedSelectRow(this, key, value);
                        });
                    });
                }, 100);
            });
        </script>
        """
        
            self._execute_js(f"document.getElementById('editor-content').innerHTML = {json.dumps(html)};")
        except Exception as e:
            import traceback
            error_msg = f"Error displaying advanced mode: {e}"
            error_code = "ERR-EDITOR-ADVANCED-001"
            traceback_str = traceback.format_exc()
            DEBUG_LOGGER.error(f"[{error_code}] {error_msg}", exc_info=True)
            error_html = f"<div style='padding: 40px; text-align: center; color: #f87171;'><div style='font-size: 18px; margin-bottom: 12px;'>❌ Error Displaying Advanced Mode</div><div style='font-size: 13px;'>{str(e)}</div></div>"
            try:
                self._execute_js(f"document.getElementById('editor-content').innerHTML = {json.dumps(error_html)};")
            except:
                pass
    
    def _save_editor_file(self):
        """Save edited file with metadata changes"""
        if not hasattr(self, '_editor_instance') or not self._editor_instance:
            QMessageBox.warning(self, "Error", "No file loaded for editing!")
            return
        
        try:
            if hasattr(self, '_editor_file_path'):
                output_path, _ = QFileDialog.getSaveFileName(
                    self, "Save File", str(self._editor_file_path),
                    "GGUF Files (*.gguf);;All Files (*)"
                )
                if output_path:
                    # Get updated metadata if available
                    custom_metadata = None
                    if hasattr(self, '_editor_metadata') and self._editor_metadata:
                        custom_metadata = self._editor_metadata
                    
                    # Extract common fields from metadata
                    name = None
                    system_prompt = None
                    persona_prompt = None
                    
                    if custom_metadata:
                        name = custom_metadata.get('general.name') or custom_metadata.get('general.description')
                        system_prompt = custom_metadata.get('llama.system_prompt') or custom_metadata.get('chat_template.system_prompt')
                        persona_prompt = custom_metadata.get('llama.persona_prompt') or custom_metadata.get('chat_template.persona_prompt')
                        
                        # Remove fields that will be handled separately
                        custom_metadata = {k: v for k, v in custom_metadata.items() 
                                         if k not in ('general.name', 'general.description',
                                                    'llama.system_prompt', 'chat_template.system_prompt',
                                                    'llama.persona_prompt', 'chat_template.persona_prompt')}
                    
                    # Call save with metadata
                    if hasattr(self._editor_instance, 'save'):
                        # Check if save method accepts custom_metadata parameter
                        import inspect
                        sig = inspect.signature(self._editor_instance.save)
                        if 'custom_metadata' in sig.parameters:
                            self._editor_instance.save(
                                output_path=output_path,
                                name=str(name) if name else None,
                                system_prompt=str(system_prompt) if system_prompt else None,
                                persona_prompt=str(persona_prompt) if persona_prompt else None,
                                custom_metadata=custom_metadata if custom_metadata else None
                            )
                        else:
                            # Fallback: just save with output path
                            self._editor_instance.save(output_path)
                    
                    QMessageBox.information(self, "Success", "File saved successfully!")
        except Exception as e:
            DEBUG_LOGGER.error(f"Error saving file: {e}", exc_info=True)
            QMessageBox.critical(self, "Error", f"Failed to save file: {e}")
    
    def _create_backup(self):
        """Create backup of current file"""
        if not hasattr(self, '_editor_file_path') or not self._editor_file_path:
            QMessageBox.warning(self, "Error", "No file loaded!")
            return
        
        try:
            backup_path = self._editor_file_path.with_suffix(
                self._editor_file_path.suffix + f".backup_{int(time.time())}"
            )
            import shutil
            shutil.copy2(self._editor_file_path, backup_path)
            QMessageBox.information(self, "Success", f"Backup created: {backup_path.name}")
        except Exception as e:
            DEBUG_LOGGER.error(f"Error creating backup: {e}", exc_info=True)
            QMessageBox.critical(self, "Error", f"Failed to create backup: {e}")
    
    def _get_editor_metadata(self):
        """Get current editor metadata"""
        # Return metadata as JSON string to JavaScript
        if hasattr(self, '_editor_instance') and self._editor_instance:
            try:
                metadata = self._editor_instance.metadata if hasattr(self._editor_instance, 'metadata') else {}
                metadata_json = json.dumps(metadata)
                self._execute_js(f"window.editorMetadata = {metadata_json};")
            except Exception as e:
                DEBUG_LOGGER.error(f"Error getting metadata: {e}")
    
    def _refresh_editor_display(self):
        """Refresh the editor display with current metadata"""
        if not hasattr(self, '_editor_instance') or not self._editor_instance:
            return
        if not hasattr(self, '_editor_file_path') or not self._editor_file_path:
            return
        if not hasattr(self, '_editor_metadata'):
            self._editor_metadata = {}
        
        try:
            # Ensure metadata is a dict
            if not isinstance(self._editor_metadata, dict):
                DEBUG_LOGGER.warning(f"Editor metadata is not a dict: {type(self._editor_metadata)}, resetting")
                self._editor_metadata = {}
            
            # Reload metadata from editor instance if possible
            if hasattr(self._editor_instance, 'metadata'):
                instance_metadata = self._editor_instance.metadata
                if isinstance(instance_metadata, dict):
                    self._editor_metadata = instance_metadata
            
            # Get mode from JavaScript using execute_js with a callback approach
            # Since we can't get sync result, we'll use execute_js to store it in a hidden element
            # and then read it, or just default to easy mode for now
            # The mode should be stored when switchEditorMode is called
            mode = getattr(self, '_editor_mode', 'easy')
            
            # Use execute_js to get the mode and store it
            js_code = """
            (function() {
                var mode = window.editorMode || 'easy';
                // Store it in a data attribute on the editor content element
                var editorContent = document.getElementById('editor-content');
                if (editorContent) {
                    editorContent.setAttribute('data-editor-mode', mode);
                }
            })();
            """
            self._execute_js(js_code)
            
            # For now, use stored mode or default to easy
            # The mode is set in JavaScript via switchEditorMode
            # Redisplay with current metadata
            self._display_editor_metadata(self._editor_metadata, self._editor_file_path)
        except Exception as e:
            DEBUG_LOGGER.error(f"Error refreshing editor display: {e}", exc_info=True)
    
    # ========== Trainer Methods ==========
    
    def _select_train_input_file(self):
        """Select input file for training (GGUF or 4DLLM)"""
        try:
            file_path, _ = QFileDialog.getOpenFileName(
                self, "Select Model File for Training", "", 
                "Model Files (*.4dllm *.gguf);;4DLLM Files (*.4dllm);;GGUF Files (*.gguf);;All Files (*)"
            )
            if file_path:
                self.train_input_file = Path(file_path)
                file_type = "4DLLM" if self.train_input_file.suffix == ".4dllm" else "GGUF"
                DEBUG_LOGGER.info(f"Selected training input file: {self.train_input_file} (Type: {file_type})")
                
                # Escape single quotes for JavaScript
                file_name_escaped = self.train_input_file.name.replace("'", "\\'")
                self._execute_js(f"document.getElementById('train-input-file').textContent = '{file_name_escaped} ({file_type})';")
                
                # Auto-generate output path
                if not self.train_output_file:
                    if self.train_input_file.suffix == ".4dllm":
                        output_path = self.train_input_file.parent / f"{self.train_input_file.stem}_trained.4dllm"
                    else:
                        output_path = self.train_input_file.parent / f"{self.train_input_file.stem}_trained.gguf"
                    self.train_output_file = output_path
                    output_name_escaped = output_path.name.replace("'", "\\'")
                    self._execute_js(f"document.getElementById('train-output-file').textContent = '{output_name_escaped}';")
        except Exception as e:
            DEBUG_LOGGER.error(f"Error selecting training input file: {e}", exc_info=True)
            QMessageBox.critical(self, "Error", f"Failed to select file: {e}")
    
    def _load_train_model(self):
        """Load and validate model file (4DLLM or GGUF) - handles errors gracefully"""
        if not self.train_input_file:
            QMessageBox.warning(self, "No File Selected", "Please select a model file first.")
            return
        
        if not self.train_input_file.exists():
            error_code = f"ERR-LOAD-{hash('file_not_found') % 10000:04d}"
            error_msg = f"File not found: {self.train_input_file}"
            DEBUG_LOGGER.error(f"[{error_code}] {error_msg}")
            self._show_model_status("error", f"❌ Error [{error_code}]: File not found")
            QMessageBox.critical(self, "Load Error", f"{error_msg}\n\nError Code: {error_code}")
            return
        
        file_suffix = self.train_input_file.suffix.lower()
        self._show_model_status("loading", "⏳ Loading model...")
        
        # Run validation in a thread to prevent UI freeze
        def validate_model():
            try:
                if file_suffix == ".4dllm":
                    self._validate_4dllm_model()
                elif file_suffix == ".gguf":
                    self._validate_gguf_model()
                else:
                    error_code = f"ERR-LOAD-{hash('unsupported_format') % 10000:04d}"
                    error_msg = f"Unsupported file format: {file_suffix}"
                    DEBUG_LOGGER.error(f"[{error_code}] {error_msg}")
                    QTimer.singleShot(0, lambda: self._show_model_status("error", f"❌ Error [{error_code}]: Unsupported format"))
                    QTimer.singleShot(0, lambda: QMessageBox.critical(self, "Load Error", f"{error_msg}\n\nError Code: {error_code}"))
            except Exception as e:
                error_code = f"ERR-LOAD-{hash(str(e)) % 10000:04d}"
                error_msg = f"Error loading model: {e}"
                DEBUG_LOGGER.error(f"[{error_code}] {error_msg}", exc_info=True)
                QTimer.singleShot(0, lambda: self._show_model_status("error", f"❌ Error [{error_code}]: {str(e)[:50]}"))
                QTimer.singleShot(0, lambda: QMessageBox.critical(self, "Load Error", f"{error_msg}\n\nError Code: {error_code}\n\nSee debug log for details."))
        
        import threading
        thread = threading.Thread(target=validate_model, daemon=True)
        thread.start()
    
    def _validate_4dllm_model(self):
        """Validate 4DLLM model file"""
        try:
            DEBUG_LOGGER.info(f"Validating 4DLLM file: {self.train_input_file}")
            
            # Check if runner_module is available
            if not runner_module:
                error_code = f"ERR-LOAD-{hash('runner_module_missing') % 10000:04d}"
                error_msg = "Runner module not available - cannot validate 4DLLM file"
                DEBUG_LOGGER.error(f"[{error_code}] {error_msg}")
                QTimer.singleShot(0, lambda: self._show_model_status("error", f"❌ Error [{error_code}]: Runner module missing"))
                QTimer.singleShot(0, lambda: QMessageBox.critical(self, "Load Error", f"{error_msg}\n\nError Code: {error_code}\n\nPlease ensure 4dllm_runner.py exists."))
                return
            
            # Read and validate TOC
            try:
                entries, toc_offset = read_and_validate_toc(self.train_input_file)
                DEBUG_LOGGER.info(f"4DLLM TOC validated: {len(entries)} sections found")
                
                # Check for GGUF section
                has_gguf = any(entry.section_type == SECTION_GGUF_DATA for entry in entries)
                if not has_gguf:
                    error_code = f"ERR-LOAD-{hash('no_gguf_section') % 10000:04d}"
                    error_msg = "4DLLM file does not contain GGUF data section"
                    DEBUG_LOGGER.error(f"[{error_code}] {error_msg}")
                    QTimer.singleShot(0, lambda: self._show_model_status("error", f"❌ Error [{error_code}]: No GGUF section"))
                    QTimer.singleShot(0, lambda: QMessageBox.critical(self, "Load Error", f"{error_msg}\n\nError Code: {error_code}"))
                    return
                
                # Success
                file_size_mb = self.train_input_file.stat().st_size / (1024 * 1024)
                success_msg = f"✅ 4DLLM model loaded successfully\n{len(entries)} sections, {file_size_mb:.1f} MB"
                DEBUG_LOGGER.info(f"4DLLM model validated successfully: {len(entries)} sections")
                QTimer.singleShot(0, lambda: self._show_model_status("success", success_msg))
                
            except Exception as toc_error:
                error_code = f"ERR-LOAD-{hash(str(toc_error)) % 10000:04d}"
                error_msg = f"Failed to read 4DLLM TOC: {toc_error}"
                DEBUG_LOGGER.error(f"[{error_code}] {error_msg}", exc_info=True)
                QTimer.singleShot(0, lambda: self._show_model_status("error", f"❌ Error [{error_code}]: TOC read failed"))
                QTimer.singleShot(0, lambda: QMessageBox.critical(self, "Load Error", f"{error_msg}\n\nError Code: {error_code}\n\nSee debug log for details."))
                
        except Exception as e:
            error_code = f"ERR-LOAD-{hash(str(e)) % 10000:04d}"
            error_msg = f"Error validating 4DLLM model: {e}"
            DEBUG_LOGGER.error(f"[{error_code}] {error_msg}", exc_info=True)
            QTimer.singleShot(0, lambda: self._show_model_status("error", f"❌ Error [{error_code}]: Validation failed"))
            QTimer.singleShot(0, lambda: QMessageBox.critical(self, "Load Error", f"{error_msg}\n\nError Code: {error_code}"))
    
    def _validate_gguf_model(self):
        """Validate GGUF model file"""
        try:
            DEBUG_LOGGER.info(f"Validating GGUF file: {self.train_input_file}")
            
            # Check file magic (GGUF files start with "GGUF")
            with open(self.train_input_file, "rb") as f:
                magic = f.read(4)
                if magic != b"GGUF":
                    error_code = f"ERR-LOAD-{hash('invalid_gguf_magic') % 10000:04d}"
                    error_msg = f"Invalid GGUF file: magic mismatch (got {magic})"
                    DEBUG_LOGGER.error(f"[{error_code}] {error_msg}")
                    QTimer.singleShot(0, lambda: self._show_model_status("error", f"❌ Error [{error_code}]: Invalid GGUF format"))
                    QTimer.singleShot(0, lambda: QMessageBox.critical(self, "Load Error", f"{error_msg}\n\nError Code: {error_code}"))
                    return
            
            # Success
            file_size_mb = self.train_input_file.stat().st_size / (1024 * 1024)
            success_msg = f"✅ GGUF model loaded successfully\n{file_size_mb:.1f} MB"
            DEBUG_LOGGER.info(f"GGUF model validated successfully: {file_size_mb:.1f} MB")
            QTimer.singleShot(0, lambda: self._show_model_status("success", success_msg))
            
        except Exception as e:
            error_code = f"ERR-LOAD-{hash(str(e)) % 10000:04d}"
            error_msg = f"Error validating GGUF model: {e}"
            DEBUG_LOGGER.error(f"[{error_code}] {error_msg}", exc_info=True)
            QTimer.singleShot(0, lambda: self._show_model_status("error", f"❌ Error [{error_code}]: Validation failed"))
            QTimer.singleShot(0, lambda: QMessageBox.critical(self, "Load Error", f"{error_msg}\n\nError Code: {error_code}"))
    
    def _show_model_status(self, status_type: str, message: str):
        """Show model loading status in UI"""
        try:
            status_el = "document.getElementById('train-model-status')"
            color_map = {
                "loading": "#06b6d4",  # Cyan
                "success": "#34d399",  # Green
                "error": "#f87171"     # Red
            }
            color = color_map.get(status_type, "#94a3b8")
            message_escaped = message.replace("'", "\\'").replace("\n", "\\n")
            self._execute_js(f"""
                {status_el}.style.display = 'block';
                {status_el}.style.color = '{color}';
                {status_el}.textContent = '{message_escaped}';
            """)
        except Exception as e:
            DEBUG_LOGGER.error(f"Error showing model status: {e}")
    
    def _select_train_dataset(self):
        """Select training dataset file"""
        try:
            file_path, _ = QFileDialog.getOpenFileName(
                self, "Select Training Dataset", "", 
                "Dataset Files (*.json *.jsonl *.txt);;All Files (*)"
            )
            if file_path:
                self.train_dataset_file = Path(file_path)
                file_size_kb = self.train_dataset_file.stat().st_size / 1024
                DEBUG_LOGGER.info(f"Selected training dataset: {self.train_dataset_file} ({file_size_kb:.1f} KB)")
                
                # Escape single quotes for JavaScript
                file_name_escaped = self.train_dataset_file.name.replace("'", "\\'")
                self._execute_js(f"document.getElementById('train-dataset-file').innerHTML = '{file_name_escaped}<br><span style=\\'font-size: 11px; color: #64748b;\\'>({file_size_kb:.1f} KB)</span>';")
        except Exception as e:
            DEBUG_LOGGER.error(f"Error selecting training dataset: {e}", exc_info=True)
            QMessageBox.critical(self, "Error", f"Failed to select dataset: {e}")
    
    def _select_train_output_file(self):
        """Select output path for trained model"""
        try:
            if not self.train_input_file:
                QMessageBox.warning(self, "Warning", "Please select an input file first.")
                return
            
            # Determine output format based on input
            if self.train_input_file.suffix == ".4dllm":
                default_path = self.train_input_file.parent / f"{self.train_input_file.stem}_trained.4dllm"
                file_filter = "4DLLM Files (*.4dllm);;GGUF Files (*.gguf);;All Files (*)"
            else:
                default_path = self.train_input_file.parent / f"{self.train_input_file.stem}_trained.gguf"
                file_filter = "GGUF Files (*.gguf);;4DLLM Files (*.4dllm);;All Files (*)"
            
            file_path, _ = QFileDialog.getSaveFileName(
                self, "Save Trained Model File", str(default_path),
                file_filter
            )
            if file_path:
                self.train_output_file = Path(file_path)
                DEBUG_LOGGER.info(f"Selected training output file: {self.train_output_file}")
                file_name_escaped = self.train_output_file.name.replace("'", "\\'")
                self._execute_js(f"document.getElementById('train-output-file').textContent = '{file_name_escaped}';")
        except Exception as e:
            DEBUG_LOGGER.error(f"Error selecting training output file: {e}", exc_info=True)
            QMessageBox.critical(self, "Error", f"Failed to select output file: {e}")
    
    def _load_train_preset(self, preset_name: str):
        """Load training preset parameters"""
        if preset_name in TRAINING_PRESETS:
            preset = TRAINING_PRESETS[preset_name]
            for key, value in preset.items():
                self._execute_js(f"document.getElementById('train-{key.replace('_', '-')}').value = '{value}';")
    
    def _start_training(self):
        """Start training process - NEVER CRASHES, shows error dialog on any error"""
        import traceback
        error_code = ""
        error_msg = ""
        traceback_str = ""
        
        try:
            DEBUG_LOGGER.info("="*80)
            DEBUG_LOGGER.info("_start_training() CALLED")
            DEBUG_LOGGER.info("="*80)
            
            DEBUG_LOGGER.info(f"train_input_file: {self.train_input_file}")
            DEBUG_LOGGER.info(f"train_dataset_file: {self.train_dataset_file}")
            DEBUG_LOGGER.info(f"train_output_file: {self.train_output_file}")
            DEBUG_LOGGER.info(f"is_training: {self.is_training}")
            
            # Validate input file
            try:
                if not self.train_input_file:
                    error_msg = "Please select an input model file (GGUF or 4DLLM) first."
                    error_code = "ERR-TRAIN-INPUT-001"
                    DEBUG_LOGGER.error(f"[{error_code}] {error_msg}")
                    QTimer.singleShot(0, lambda: self._show_error_dialog("Training Error", error_msg, error_code))
                    return
                
                DEBUG_LOGGER.info(f"Checking if input file exists: {self.train_input_file}")
                if not self.train_input_file.exists():
                    error_msg = f"Input file does not exist: {self.train_input_file}"
                    error_code = "ERR-TRAIN-INPUT-002"
                    DEBUG_LOGGER.error(f"[{error_code}] {error_msg}")
                    QTimer.singleShot(0, lambda: self._show_error_dialog("Training Error", error_msg, error_code))
                    return
                DEBUG_LOGGER.info("Input file exists - OK")
            except Exception as e:
                error_msg = f"Error validating input file: {e}"
                error_code = "ERR-TRAIN-INPUT-003"
                traceback_str = traceback.format_exc()
                DEBUG_LOGGER.error(f"[{error_code}] {error_msg}", exc_info=True)
                DEBUG_LOGGER.error(f"Traceback:\n{traceback_str}")
                QTimer.singleShot(0, lambda: self._show_error_dialog("Training Error", error_msg, f"{error_code}\n\n{traceback_str}"))
                return
            
            # Validate dataset
            try:
                if not self.train_dataset_file:
                    error_msg = "Please select a training dataset file first."
                    error_code = "ERR-TRAIN-DATASET-001"
                    DEBUG_LOGGER.error(f"[{error_code}] {error_msg}")
                    QTimer.singleShot(0, lambda: self._show_error_dialog("Training Error", error_msg, error_code))
                    return
                
                DEBUG_LOGGER.info(f"Checking if dataset file exists: {self.train_dataset_file}")
                if not self.train_dataset_file.exists():
                    error_msg = f"Dataset file does not exist: {self.train_dataset_file}"
                    error_code = "ERR-TRAIN-DATASET-002"
                    DEBUG_LOGGER.error(f"[{error_code}] {error_msg}")
                    QTimer.singleShot(0, lambda: self._show_error_dialog("Training Error", error_msg, error_code))
                    return
                DEBUG_LOGGER.info("Dataset file exists - OK")
            except Exception as e:
                error_msg = f"Error validating dataset file: {e}"
                error_code = "ERR-TRAIN-DATASET-003"
                traceback_str = traceback.format_exc()
                DEBUG_LOGGER.error(f"[{error_code}] {error_msg}", exc_info=True)
                DEBUG_LOGGER.error(f"Traceback:\n{traceback_str}")
                QTimer.singleShot(0, lambda: self._show_error_dialog("Training Error", error_msg, f"{error_code}\n\n{traceback_str}"))
                return
            
            # Validate output
            try:
                if not self.train_output_file:
                    error_msg = "Please select an output file path."
                    error_code = "ERR-TRAIN-OUTPUT-001"
                    DEBUG_LOGGER.error(f"[{error_code}] {error_msg}")
                    QTimer.singleShot(0, lambda: self._show_error_dialog("Training Error", error_msg, error_code))
                    return
                DEBUG_LOGGER.info("Output file path set - OK")
            except Exception as e:
                error_msg = f"Error validating output file: {e}"
                error_code = "ERR-TRAIN-OUTPUT-002"
                traceback_str = traceback.format_exc()
                DEBUG_LOGGER.error(f"[{error_code}] {error_msg}", exc_info=True)
                QTimer.singleShot(0, lambda: self._show_error_dialog("Training Error", error_msg, f"{error_code}\n\n{traceback_str}"))
                return
            
            # Check if already training
            try:
                if self.is_training:
                    error_msg = "Training is already in progress."
                    error_code = "ERR-TRAIN-STATUS-001"
                    DEBUG_LOGGER.warning(f"[{error_code}] {error_msg}")
                    QTimer.singleShot(0, lambda: self._show_error_dialog("Training Warning", error_msg, error_code))
                    return
                DEBUG_LOGGER.info("Not currently training - OK")
            except Exception as e:
                error_msg = f"Error checking training status: {e}"
                error_code = "ERR-TRAIN-STATUS-002"
                traceback_str = traceback.format_exc()
                DEBUG_LOGGER.error(f"[{error_code}] {error_msg}", exc_info=True)
                QTimer.singleShot(0, lambda: self._show_error_dialog("Training Error", error_msg, f"{error_code}\n\n{traceback_str}"))
                return
            
            # Get training parameters from UI
            DEBUG_LOGGER.info("Reading training parameters from UI...")
            try:
                params = TRAINING_PRESETS["Standard Training"].copy()
                DEBUG_LOGGER.info(f"Using default params: {params}")
            except Exception as e:
                DEBUG_LOGGER.error(f"Error getting default params: {e}", exc_info=True)
                params = {
                    "epochs": "5",
                    "learning_rate": "0.0001",
                    "batch_size": "8",
                    "context_size": "4096",
                    "lora_r": "16",
                    "lora_alpha": "32",
                    "lora_dropout": "0.1"
                }
            
            DEBUG_LOGGER.info("Calling _get_training_params_and_start...")
            try:
                # Call directly without timer to avoid issues
                self._get_training_params_and_start(params)
            except Exception as e:
                error_msg = f"Error in _get_training_params_and_start: {e}"
                error_code = "ERR-TRAIN-START-001"
                traceback_str = traceback.format_exc()
                DEBUG_LOGGER.error("="*80)
                DEBUG_LOGGER.error(f"[{error_code}] CRITICAL ERROR calling _get_training_params_and_start")
                DEBUG_LOGGER.error(error_msg, exc_info=True)
                DEBUG_LOGGER.error(f"Full traceback:\n{traceback_str}")
                DEBUG_LOGGER.error("="*80)
                self.is_training = False
                try:
                    self._append_train_log(f"\n❌ [{error_code}] {error_msg}\n", "error")
                except:
                    pass
                QTimer.singleShot(0, lambda: self._show_error_dialog("Training Error", error_msg, f"{error_code}\n\n{traceback_str}"))
            
        except Exception as e:
            error_msg = f"Unexpected error starting training: {e}"
            error_code = "ERR-TRAIN-FATAL-001"
            traceback_str = traceback.format_exc()
            DEBUG_LOGGER.error("="*80)
            DEBUG_LOGGER.error(f"[{error_code}] CRITICAL ERROR in _start_training")
            DEBUG_LOGGER.error(error_msg, exc_info=True)
            DEBUG_LOGGER.error(f"Full traceback:\n{traceback_str}")
            DEBUG_LOGGER.error("="*80)
            self.is_training = False
            try:
                self._append_train_log(f"\n❌ [{error_code}] {error_msg}\n", "error")
            except:
                pass
            try:
                QTimer.singleShot(0, lambda: self._show_error_dialog("Training Error", error_msg, f"{error_code}\n\n{traceback_str}"))
            except:
                pass  # If even showing error dialog fails, just log it
    
    def _get_training_params_and_start(self, default_params: Dict[str, str]):
        """Get training parameters from JS and start training - NEVER CRASHES"""
        import traceback
        error_code = ""
        error_msg = ""
        traceback_str = ""
        
        try:
            DEBUG_LOGGER.info("="*80)
            DEBUG_LOGGER.info("_get_training_params_and_start() CALLED")
            DEBUG_LOGGER.info(f"default_params: {default_params}")
            
            # Capture file paths as strings BEFORE starting thread (thread-safe)
            try:
                DEBUG_LOGGER.info("Step 1: Validating file selections...")
                if not self.train_input_file:
                    error_msg = "No input file selected"
                    error_code = "ERR-TRAIN-PARAMS-001"
                    DEBUG_LOGGER.error(f"[{error_code}] {error_msg}")
                    QTimer.singleShot(0, lambda: self._show_error_dialog("Training Error", error_msg, error_code))
                    return
                DEBUG_LOGGER.info(f"Input file: {self.train_input_file}")
                
                if not self.train_dataset_file:
                    error_msg = "No dataset file selected"
                    error_code = "ERR-TRAIN-PARAMS-002"
                    DEBUG_LOGGER.error(f"[{error_code}] {error_msg}")
                    QTimer.singleShot(0, lambda: self._show_error_dialog("Training Error", error_msg, error_code))
                    return
                DEBUG_LOGGER.info(f"Dataset file: {self.train_dataset_file}")
                
                if not self.train_output_file:
                    error_msg = "No output file selected"
                    error_code = "ERR-TRAIN-PARAMS-003"
                    DEBUG_LOGGER.error(f"[{error_code}] {error_msg}")
                    QTimer.singleShot(0, lambda: self._show_error_dialog("Training Error", error_msg, error_code))
                    return
                DEBUG_LOGGER.info(f"Output file: {self.train_output_file}")
            except Exception as e:
                error_msg = f"Error validating file selections: {e}"
                error_code = "ERR-TRAIN-PARAMS-004"
                traceback_str = traceback.format_exc()
                DEBUG_LOGGER.error(f"[{error_code}] {error_msg}", exc_info=True)
                DEBUG_LOGGER.error(f"Traceback:\n{traceback_str}")
                QTimer.singleShot(0, lambda: self._show_error_dialog("Training Error", error_msg, f"{error_code}\n\n{traceback_str}"))
                return
            
            # Convert to strings for thread safety
            try:
                DEBUG_LOGGER.info("Step 2: Converting paths to strings...")
                input_file_str = str(self.train_input_file)
                dataset_file_str = str(self.train_dataset_file)
                output_file_str = str(self.train_output_file)
                DEBUG_LOGGER.info(f"Input file string: {input_file_str}")
                DEBUG_LOGGER.info(f"Dataset file string: {dataset_file_str}")
                DEBUG_LOGGER.info(f"Output file string: {output_file_str}")
            except Exception as e:
                error_msg = f"Error converting paths to strings: {e}"
                error_code = "ERR-TRAIN-PARAMS-005"
                traceback_str = traceback.format_exc()
                DEBUG_LOGGER.error(f"[{error_code}] {error_msg}", exc_info=True)
                DEBUG_LOGGER.error(f"Traceback:\n{traceback_str}")
                QTimer.singleShot(0, lambda: self._show_error_dialog("Training Error", error_msg, f"{error_code}\n\n{traceback_str}"))
                return
            
            # Validate files exist before starting
            try:
                DEBUG_LOGGER.info("Step 3: Validating file existence...")
                input_path = Path(input_file_str)
                if not input_path.exists():
                    error_msg = f"Input file does not exist: {input_file_str}"
                    error_code = "ERR-TRAIN-PARAMS-006"
                    DEBUG_LOGGER.error(f"[{error_code}] {error_msg}")
                    QTimer.singleShot(0, lambda: self._show_error_dialog("Training Error", error_msg, error_code))
                    return
                DEBUG_LOGGER.info("Input file exists - OK")
                
                dataset_path = Path(dataset_file_str)
                if not dataset_path.exists():
                    error_msg = f"Dataset file does not exist: {dataset_file_str}"
                    error_code = "ERR-TRAIN-PARAMS-007"
                    DEBUG_LOGGER.error(f"[{error_code}] {error_msg}")
                    QTimer.singleShot(0, lambda: self._show_error_dialog("Training Error", error_msg, error_code))
                    return
                DEBUG_LOGGER.info("Dataset file exists - OK")
            except Exception as e:
                error_msg = f"Error validating file existence: {e}"
                error_code = "ERR-TRAIN-PARAMS-008"
                traceback_str = traceback.format_exc()
                DEBUG_LOGGER.error(f"[{error_code}] {error_msg}", exc_info=True)
                DEBUG_LOGGER.error(f"Traceback:\n{traceback_str}")
                QTimer.singleShot(0, lambda: self._show_error_dialog("Training Error", error_msg, f"{error_code}\n\n{traceback_str}"))
                return
            
            # Use default params for now
            try:
                DEBUG_LOGGER.info("Step 4: Preparing parameters...")
                params = default_params.copy()
                DEBUG_LOGGER.info(f"Using training parameters: {params}")
            except Exception as e:
                error_msg = f"Error preparing parameters: {e}"
                error_code = "ERR-TRAIN-PARAMS-009"
                traceback_str = traceback.format_exc()
                DEBUG_LOGGER.error(f"[{error_code}] {error_msg}", exc_info=True)
                QTimer.singleShot(0, lambda: self._show_error_dialog("Training Error", error_msg, f"{error_code}\n\n{traceback_str}"))
                return
            
            # Start training in a thread
            try:
                DEBUG_LOGGER.info("Step 5: Setting training flag...")
                self.is_training = True
                DEBUG_LOGGER.info("is_training set to True")
            except Exception as e:
                error_msg = f"Error setting training flag: {e}"
                error_code = "ERR-TRAIN-PARAMS-010"
                traceback_str = traceback.format_exc()
                DEBUG_LOGGER.error(f"[{error_code}] {error_msg}", exc_info=True)
                QTimer.singleShot(0, lambda: self._show_error_dialog("Training Error", error_msg, f"{error_code}\n\n{traceback_str}"))
                return
            
            try:
                DEBUG_LOGGER.info("Step 6: Updating UI...")
                # Update UI immediately - set progress to 1% to show it's starting
                # Wrap in IIFE to avoid variable redeclaration errors
                self._execute_js("""
                    (function() {
                        var startBtn = document.getElementById('train-start-btn');
                        var stopBtn = document.getElementById('train-stop-btn');
                        var stats = document.getElementById('train-stats');
                        var bar = document.getElementById('train-progress-bar');
                        var text = document.getElementById('train-progress-text');
                        if (startBtn) startBtn.style.display = 'none';
                        if (stopBtn) stopBtn.style.display = 'block';
                        if (stats) stats.innerHTML = '<div>Epoch: <span style="color: #06b6d4;">Starting...</span></div><div>Loss: <span style="color: #06b6d4;">-</span></div><div>Time: <span style="color: #06b6d4;">0s</span></div><div>Status: <span style="color: #34d399;">Training</span></div>';
                        if (bar) bar.style.width = '1%';
                        if (text) text.textContent = 'Initializing...';
                    })();
                """)
                DEBUG_LOGGER.info("UI updated - OK")
            except Exception as e:
                DEBUG_LOGGER.warning(f"Error updating UI (non-critical): {e}")
            
            try:
                DEBUG_LOGGER.info("Step 7: Clearing training log...")
                self._execute_js("document.getElementById('train-output').textContent = '';")
                self._append_train_log("Starting training process...\n", "info")
                DEBUG_LOGGER.info("Training log cleared - OK")
            except Exception as e:
                DEBUG_LOGGER.warning(f"Error clearing log (non-critical): {e}")
            
            try:
                DEBUG_LOGGER.info("Step 8: Logging file info...")
                input_path = Path(input_file_str)
                file_type = "4DLLM" if input_path.suffix.lower() == ".4dllm" else "GGUF"
                self._append_train_log(f"Input: {input_path.name} ({file_type})\n", "info")
                self._append_train_log(f"Dataset: {Path(dataset_file_str).name}\n", "info")
                self._append_train_log(f"Output: {Path(output_file_str).name}\n", "info")
                self._append_train_log(f"Parameters: {json.dumps(params, indent=2)}\n", "info")
                DEBUG_LOGGER.info("File info logged - OK")
            except Exception as e:
                DEBUG_LOGGER.warning(f"Error logging file info (non-critical): {e}")
            
            try:
                DEBUG_LOGGER.info("Step 9: Creating training thread...")
                self.training_thread = threading.Thread(
                    target=self._run_training,
                    args=(params, input_file_str, dataset_file_str, output_file_str),
                    daemon=True
                )
                DEBUG_LOGGER.info("Training thread created - OK")
            except Exception as e:
                error_msg = f"Error creating training thread: {e}"
                error_code = "ERR-TRAIN-PARAMS-011"
                traceback_str = traceback.format_exc()
                DEBUG_LOGGER.error(f"[{error_code}] {error_msg}", exc_info=True)
                DEBUG_LOGGER.error(f"Traceback:\n{traceback_str}")
                self.is_training = False
                QTimer.singleShot(0, lambda: self._show_error_dialog("Training Error", error_msg, f"{error_code}\n\n{traceback_str}"))
                return
            
            try:
                DEBUG_LOGGER.info("Step 10: Starting training thread...")
                self.training_thread.start()
                DEBUG_LOGGER.info("Training thread started - OK")
                DEBUG_LOGGER.info("="*80)
            except Exception as e:
                error_msg = f"Error starting training thread: {e}"
                error_code = "ERR-TRAIN-PARAMS-012"
                traceback_str = traceback.format_exc()
                DEBUG_LOGGER.error(f"[{error_code}] {error_msg}", exc_info=True)
                DEBUG_LOGGER.error(f"Traceback:\n{traceback_str}")
                self.is_training = False
                QTimer.singleShot(0, lambda: self._show_error_dialog("Training Error", error_msg, f"{error_code}\n\n{traceback_str}"))
                return
            
        except Exception as e:
            error_msg = f"Unexpected error in training setup: {e}"
            error_code = "ERR-TRAIN-PARAMS-FATAL-001"
            traceback_str = traceback.format_exc()
            DEBUG_LOGGER.error("="*80)
            DEBUG_LOGGER.error(f"[{error_code}] CRITICAL ERROR in _get_training_params_and_start")
            DEBUG_LOGGER.error(error_msg, exc_info=True)
            DEBUG_LOGGER.error(f"Full traceback:\n{traceback_str}")
            DEBUG_LOGGER.error("="*80)
            self.is_training = False
            try:
                self._append_train_log(f"\n❌ [{error_code}] {error_msg}\n", "error")
            except:
                pass
            try:
                QTimer.singleShot(0, lambda: self._show_error_dialog("Training Error", error_msg, f"{error_code}\n\n{traceback_str}"))
            except:
                pass  # If even showing error dialog fails, just log it
    
    def _stop_training(self):
        """Stop training process"""
        DEBUG_LOGGER.info("="*80)
        DEBUG_LOGGER.info("_stop_training() CALLED")
        DEBUG_LOGGER.info(f"is_training: {self.is_training}")
        DEBUG_LOGGER.info("="*80)
        
        try:
            if not self.is_training:
                DEBUG_LOGGER.info("Not training - nothing to stop")
                return
            
            DEBUG_LOGGER.info("Setting is_training = False")
            self.is_training = False
            DEBUG_LOGGER.info(f"is_training set to: {self.is_training}")
            
            if self.training_process:
                try:
                    DEBUG_LOGGER.info("Terminating training process")
                    self.training_process.terminate()
                    DEBUG_LOGGER.info("Training process terminated")
                except Exception as e:
                    DEBUG_LOGGER.error(f"Error terminating process: {e}")
            
            DEBUG_LOGGER.info("Appending stop message to log")
            self._append_train_log("\n[Training stopped by user]\n", "warning")
            
            DEBUG_LOGGER.info("Updating UI to show stopped state")
            self._execute_js("""
                document.getElementById('train-start-btn').style.display = 'block';
                document.getElementById('train-stop-btn').style.display = 'none';
                document.getElementById('train-stats').innerHTML = '<div>Epoch: <span style="color: #64748b;">-</span></div><div>Loss: <span style="color: #64748b;">-</span></div><div>Time: <span style="color: #64748b;">-</span></div><div>Status: <span style="color: #64748b;">Stopped</span></div>';
                document.getElementById('train-progress-bar').style.width = '0%';
                document.getElementById('train-progress-text').textContent = 'Stopped';
            """)
            
            DEBUG_LOGGER.info("Stop training completed successfully")
        except Exception as e:
            DEBUG_LOGGER.error(f"Error in _stop_training: {e}", exc_info=True)
            import traceback
            DEBUG_LOGGER.error(f"Traceback: {traceback.format_exc()}")
    
    def _run_training(self, params: Dict[str, str], input_file_str: str, dataset_file_str: str, output_file_str: str):
        """Run training process (in thread) - receives file paths as strings for thread safety"""
        # CRITICAL: Use direct file logging - NO Qt objects in thread!
        def thread_log(msg, level="INFO"):
            try:
                timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                log_line = f"{timestamp} [{level}] 4dllm_runner_gui_qt: {msg}\n"
                with open(DEBUG_LOG_FILE, 'a', encoding='utf-8') as f:
                    f.write(log_line)
                    f.flush()  # Force write immediately
                # Also print to stderr for immediate visibility
                print(f"[THREAD {level}] {msg}", file=sys.stderr, flush=True)
            except Exception as log_err:
                # Even logging can fail, so we silently continue
                print(f"[THREAD LOG ERROR] {log_err}", file=sys.stderr, flush=True)
        
        def safe_emit_signal(signal_func, *args):
            """Safely emit a signal, catching any errors"""
            try:
                signal_func(*args)
            except Exception as sig_err:
                thread_log(f"Error emitting signal: {sig_err}", "WARNING")
        
        def safe_reset_ui():
            """Safely reset UI on main thread"""
            try:
                QTimer.singleShot(0, lambda: self._reset_training_ui_safe())
            except Exception as ui_err:
                thread_log(f"Error scheduling UI reset: {ui_err}", "WARNING")
        
        gguf_path = None
        import traceback
        
        # CRITICAL: Wrap EVERYTHING in try-except to prevent crashes
        try:
            thread_log("="*80)
            thread_log("_run_training() THREAD STARTED")
            thread_log("="*80)
            thread_log(f"params: {params}")
            thread_log(f"input_file_str: {input_file_str}")
            thread_log(f"dataset_file_str: {dataset_file_str}")
            thread_log(f"output_file_str: {output_file_str}")
            
            # Convert string paths to Path objects in thread
            try:
                thread_log("Converting string paths to Path objects...")
                train_input_file = Path(input_file_str)
                train_dataset_file = Path(dataset_file_str)
                train_output_file = Path(output_file_str)
                thread_log(f"train_input_file: {train_input_file}")
                thread_log(f"train_dataset_file: {train_dataset_file}")
                thread_log(f"train_output_file: {train_output_file}")
            except Exception as e:
                error_msg = f"Error converting paths: {e}"
                traceback_str = traceback.format_exc()
                thread_log(f"{error_msg}\n{traceback_str}", "ERROR")
                # Use signal to show error (thread-safe)
                error_code = "ERR-TRAIN-RUN-001"
                self.trainLogAppended.emit(f"❌ [{error_code}] {error_msg}\n", "error")
                self.is_training = False
                QTimer.singleShot(0, lambda: self._reset_training_ui_safe())
                QTimer.singleShot(0, lambda: self._show_error_dialog("Training Error", error_msg, f"{error_code}\n\n{traceback_str}"))
                return
            
            thread_log(f"Input file: {train_input_file}")
            thread_log(f"Output file: {train_output_file}")
            thread_log(f"Dataset: {train_dataset_file}")
            thread_log(f"Parameters: {params}")
            
            # Check if runner_module is available - try to reload if missing
            # NOTE: We can't modify global variables from a thread safely, so we'll check locally
            # and handle the case where runner_module is None
            
            # Determine file type first
            file_suffix = train_input_file.suffix.lower()
            thread_log(f"File suffix: {file_suffix}")
            
            # Check runner_module availability (read-only check)
            runner_available = runner_module is not None
            thread_log(f"runner_module available: {runner_available}")
            
            # For 4DLLM files, try to extract GGUF (like original trainer)
            # If extraction fails, we'll show error but continue with simulation
            if file_suffix == ".4dllm" and not runner_available:
                # Show warning but continue with simulation (can't extract, but can still simulate)
                error_msg = "Warning: Cannot extract GGUF (runner module not available). Simulating training only."
                thread_log(error_msg, "WARNING")
                self.trainLogAppended.emit(f"⚠️ {error_msg}\n", "warning")
                self.trainLogAppended.emit("💡 Tip: Use a .gguf file directly for full training.\n", "info")
                # Continue anyway - use input file as placeholder
                gguf_path = train_input_file  # Use as placeholder
            
            # Validate files exist before proceeding
            if not train_input_file.exists():
                error_msg = f"Input file does not exist: {train_input_file}"
                thread_log(error_msg, "ERROR")
                self.trainLogAppended.emit(f"❌ {error_msg}\n", "error")
                self.is_training = False
                QTimer.singleShot(0, lambda: self._reset_training_ui_safe())
                return
            
            if not train_dataset_file.exists():
                error_msg = f"Dataset file does not exist: {train_dataset_file}"
                thread_log(error_msg, "ERROR")
                self.trainLogAppended.emit(f"❌ {error_msg}\n", "error")
                self.is_training = False
                QTimer.singleShot(0, lambda: self._reset_training_ui_safe())
                return
            
            # Get GGUF path based on file type (like original trainer)
            if file_suffix == ".4dllm":
                # Extract GGUF from 4DLLM (like original trainer)
                self.trainLogAppended.emit("Extracting GGUF model from 4DLLM file...\n", "info")
                thread_log("Extracting GGUF from 4DLLM file")
                
                # Update progress
                self.trainProgressUpdated.emit(2, 'Extracting GGUF from 4DLLM file...')
                
                try:
                    thread_log("Calling _extract_gguf_for_training...")
                    gguf_path = self._extract_gguf_for_training(train_input_file)
                    thread_log(f"_extract_gguf_for_training returned: {gguf_path}")
                    
                    if not gguf_path:
                        raise Exception("Failed to extract GGUF model")
                    
                    self.trainProgressUpdated.emit(5, 'GGUF extraction complete')
                    self.trainLogAppended.emit("✅ GGUF extracted successfully\n", "success")
                except Exception as extract_error:
                    error_msg = f"Exception during GGUF extraction: {extract_error}"
                    import traceback
                    traceback_str = traceback.format_exc()
                    thread_log("="*80, "ERROR")
                    thread_log("CRITICAL ERROR calling _extract_gguf_for_training", "ERROR")
                    thread_log(f"{error_msg}\n{traceback_str}", "ERROR")
                    thread_log("="*80, "ERROR")
                    
                    error_code = "ERR-TRAIN-RUN-002"
                    QTimer.singleShot(0, lambda: self._show_error_dialog(
                        "Training Error",
                        f"Exception occurred during GGUF extraction:\n\n{error_msg}",
                        f"{error_code}\n\n{traceback_str}"
                    ))
                    
                    self.trainLogAppended.emit(f"❌ {error_msg}\n", "error")
                    self.trainLogAppended.emit("Check debug log for full error details.\n", "error")
                    self.is_training = False
                    QTimer.singleShot(0, lambda: self._reset_training_ui_safe())
                    return
                
                if not gguf_path:
                    error_msg = "Failed to extract GGUF from 4DLLM file (returned None)"
                    thread_log(error_msg, "ERROR")
                    self.trainLogAppended.emit(f"❌ {error_msg}\n", "error")
                    self.trainLogAppended.emit("Check debug log for details.\n", "error")
                    self.is_training = False
                    QTimer.singleShot(0, lambda: self._reset_training_ui_safe())
                    return
                
                if not isinstance(gguf_path, Path):
                    error_msg = f"Invalid GGUF path type: {type(gguf_path)}"
                    thread_log(error_msg, "ERROR")
                    self.trainLogAppended.emit(f"❌ {error_msg}\n", "error")
                    self.is_training = False
                    QTimer.singleShot(0, lambda: self._reset_training_ui_safe())
                    return
                
                try:
                    if not gguf_path.exists():
                        error_msg = f"Extracted GGUF file does not exist: {gguf_path}"
                        thread_log(error_msg, "ERROR")
                        self.trainLogAppended.emit(f"❌ {error_msg}\n", "error")
                        self.is_training = False
                        QTimer.singleShot(0, lambda: self._reset_training_ui_safe())
                        return
                except Exception as check_error:
                    error_msg = f"Error checking GGUF file existence: {check_error}"
                    import traceback
                    thread_log(f"{error_msg}\n{traceback.format_exc()}", "ERROR")
                    self.trainLogAppended.emit(f"❌ {error_msg}\n", "error")
                    self.is_training = False
                    QTimer.singleShot(0, lambda: self._reset_training_ui_safe())
                    return
                
                self.trainLogAppended.emit(f"✅ GGUF extracted: {gguf_path.name}\n", "success")
                try:
                    file_size = gguf_path.stat().st_size
                    thread_log(f"GGUF extracted successfully: {gguf_path} ({file_size} bytes)")
                except:
                    thread_log(f"GGUF extracted successfully: {gguf_path}")
            elif file_suffix == ".gguf":
                # Direct GGUF file
                gguf_path = train_input_file
                self.trainLogAppended.emit(f"Using GGUF file directly: {gguf_path.name}\n", "info")
                thread_log(f"Using GGUF file directly: {gguf_path}")
            else:
                error_msg = f"Unsupported file type: {file_suffix}"
                thread_log(error_msg, "ERROR")
                self.trainLogAppended.emit(f"❌ {error_msg}\n", "error")
                self.trainLogAppended.emit("Supported formats: .4dllm, .gguf\n", "error")
                self.is_training = False
                QTimer.singleShot(0, lambda: self._reset_training_ui_safe())
                return
            
            # Validate GGUF file exists
            if not gguf_path.exists():
                error_msg = f"GGUF file not found: {gguf_path}"
                thread_log(error_msg, "ERROR")
                self.trainLogAppended.emit(f"❌ {error_msg}\n", "error")
                self.is_training = False
                QTimer.singleShot(0, lambda: self._reset_training_ui_safe())
                return
            
            # Validate dataset exists
            if not train_dataset_file.exists():
                error_msg = f"Dataset file not found: {train_dataset_file}"
                thread_log(error_msg, "ERROR")
                self.trainLogAppended.emit(f"❌ {error_msg}\n", "error")
                self.is_training = False
                QTimer.singleShot(0, lambda: self._reset_training_ui_safe())
                return
            
            # Get epochs safely
            try:
                epochs = int(params.get("epochs", "5"))
                if epochs < 1:
                    epochs = 5
                    thread_log("Epochs < 1, using default: 5", "WARNING")
            except (ValueError, TypeError):
                epochs = 5
                thread_log("Invalid epochs value, using default: 5", "WARNING")
            
            # Start training simulation (like original trainer)
            thread_log("="*80)
            thread_log("STEP: Starting training simulation")
            thread_log(f"STEP: Epochs: {epochs}")
            thread_log(f"STEP: is_training flag: {self.is_training}")
            thread_log("="*80)
            
            self.trainLogAppended.emit(f"Training parameters: {params}\n", "info")
            thread_log("STEP: Emitted training parameters to UI")
            
            # Update initial progress - CRITICAL STEP
            thread_log("STEP: Updating initial progress to 10%")
            try:
                self.trainProgressUpdated.emit(10, 'Starting training...')
                thread_log("STEP: trainProgressUpdated signal emitted (10%)")
            except Exception as e:
                thread_log(f"ERROR emitting progress: {e}", "ERROR")
            
            try:
                stats_html = (
                    '<div>Epoch: <span style="color: #06b6d4;">0/' + str(epochs) + '</span></div>' +
                    '<div>Loss: <span style="color: #06b6d4;">-</span></div>' +
                    '<div>Time: <span style="color: #06b6d4;">0s</span></div>' +
                    '<div>Status: <span style="color: #34d399;">Training</span></div>'
                )
                self.trainStatsUpdated.emit(stats_html)
                thread_log("STEP: trainStatsUpdated signal emitted")
            except Exception as e:
                thread_log(f"ERROR emitting stats: {e}", "ERROR")
            
            # Also update via direct JS for reliability - MUST be on main thread!
            # Wrap in IIFE to avoid variable redeclaration errors
            try:
                thread_log("STEP: Scheduling UI update via direct JavaScript (main thread)")
                js_code = f"""
                    (function() {{
                        var bar = document.getElementById('train-progress-bar');
                        var text = document.getElementById('train-progress-text');
                        if (bar) {{
                            bar.style.width = '10%';
                        }}
                        if (text) {{
                            text.textContent = 'Starting training...';
                        }}
                        var stats = document.getElementById('train-stats');
                        if (stats) {{
                            stats.innerHTML = '<div>Epoch: <span style="color: #06b6d4;">0/{epochs}</span></div><div>Loss: <span style="color: #06b6d4;">-</span></div><div>Time: <span style="color: #06b6d4;">0s</span></div><div>Status: <span style="color: #34d399;">Training</span></div>';
                        }}
                    }})();
                """
                QTimer.singleShot(0, lambda: self._execute_js(js_code))
                thread_log("STEP: Direct JS update scheduled (will run on main thread)")
            except Exception as e:
                thread_log(f"ERROR scheduling JS update: {e}", "ERROR")
            
            start_time = time.time()
            thread_log(f"STEP: Training loop starting, start_time: {start_time}")
            thread_log(f"STEP: About to enter epoch loop, epochs={epochs}, is_training={self.is_training}")
            
            # Training loop (like original trainer)
            thread_log("="*80)
            thread_log("ENTERING EPOCH LOOP")
            thread_log("="*80)
            
            for epoch in range(1, epochs + 1):
                thread_log(f"EPOCH LOOP: Iteration {epoch}/{epochs}")
                thread_log(f"EPOCH LOOP: Checking is_training flag: {self.is_training}")
                
                if not self.is_training:
                    thread_log("EPOCH LOOP: Training stopped by user - breaking")
                    break
                
                thread_log(f"EPOCH LOOP: Processing epoch {epoch}")
                
                try:
                    thread_log(f"EPOCH {epoch}: Starting epoch processing")
                    
                    # Log epoch (like original trainer)
                    thread_log(f"EPOCH {epoch}: Emitting epoch log to UI")
                    self.trainLogAppended.emit(f"Epoch {epoch}/{epochs}...\n", "info")
                    thread_log(f"EPOCH {epoch}: Epoch log emitted")
                    
                    # Calculate progress (like original trainer)
                    elapsed = int(time.time() - start_time)
                    loss = max(0.01, 0.5 - (epoch * 0.05))
                    progress_percent = int((epoch / epochs) * 100)
                    thread_log(f"EPOCH {epoch}: Calculated progress - elapsed={elapsed}s, loss={loss:.4f}, progress={progress_percent}%")
                    
                    # Update stats (like original trainer)
                    thread_log(f"EPOCH {epoch}: Updating stats")
                    stats_html = (
                        f'<div>Epoch: <span style="color: #06b6d4;">{epoch}/{epochs}</span></div>' +
                        f'<div>Loss: <span style="color: #06b6d4;">{loss:.4f}</span></div>' +
                        f'<div>Time: <span style="color: #06b6d4;">{elapsed}s</span></div>' +
                        f'<div>Status: <span style="color: #34d399;">Training</span></div>'
                    )
                    self.trainStatsUpdated.emit(stats_html)
                    thread_log(f"EPOCH {epoch}: Stats updated signal emitted")
                    
                    self.trainProgressUpdated.emit(progress_percent, f'Epoch {epoch}/{epochs}')
                    thread_log(f"EPOCH {epoch}: Progress updated signal emitted ({progress_percent}%)")
                    
                    # Also update via direct JS - MUST be on main thread!
                    # Wrap in IIFE to avoid variable redeclaration errors
                    try:
                        thread_log(f"EPOCH {epoch}: Scheduling UI update via direct JS (main thread)")
                        js_code = f"""
                            (function() {{
                                var bar = document.getElementById('train-progress-bar');
                                var text = document.getElementById('train-progress-text');
                                var stats = document.getElementById('train-stats');
                                if (bar) {{
                                    bar.style.width = '{progress_percent}%';
                                }}
                                if (text) {{
                                    text.textContent = 'Epoch {epoch}/{epochs}';
                                }}
                                if (stats) {{
                                    stats.innerHTML = '<div>Epoch: <span style="color: #06b6d4;">{epoch}/{epochs}</span></div><div>Loss: <span style="color: #06b6d4;">{loss:.4f}</span></div><div>Time: <span style="color: #06b6d4;">{elapsed}s</span></div><div>Status: <span style="color: #34d399;">Training</span></div>';
                                }}
                            }})();
                        """
                        QTimer.singleShot(0, lambda: self._execute_js(js_code))
                        thread_log(f"EPOCH {epoch}: Direct JS update scheduled (will run on main thread)")
                    except Exception as js_err:
                        thread_log(f"EPOCH {epoch}: ERROR scheduling JS update: {js_err}", "ERROR")
                    
                    # Simulate training steps (like original trainer: 10 steps, 0.5s sleep)
                    thread_log(f"EPOCH {epoch}: Starting step loop (10 steps)")
                    for step in range(10):
                        thread_log(f"EPOCH {epoch} STEP {step+1}: Starting step")
                        
                        if not self.is_training:
                            thread_log(f"EPOCH {epoch} STEP {step+1}: Training stopped - returning")
                            return
                        
                        thread_log(f"EPOCH {epoch} STEP {step+1}: Sleeping 0.5s")
                        time.sleep(0.5)  # Like original trainer
                        thread_log(f"EPOCH {epoch} STEP {step+1}: Sleep complete")
                        
                        self.trainLogAppended.emit(f"  Step {step + 1}/10\n", "debug")
                        thread_log(f"EPOCH {epoch} STEP {step+1}: Step log emitted")
                        
                        # Update progress within epoch
                        epoch_progress = (step + 1) / 10
                        overall_progress = int(((epoch - 1 + epoch_progress) / epochs) * 100)
                        self.trainProgressUpdated.emit(overall_progress, f'Epoch {epoch}/{epochs} - Step {step + 1}/10')
                        thread_log(f"EPOCH {epoch} STEP {step+1}: Progress updated to {overall_progress}%")
                    
                    thread_log(f"EPOCH {epoch}: All steps completed")
                    thread_log(f"EPOCH {epoch}: Epoch {epoch}/{epochs} COMPLETE")
                    
                except Exception as epoch_error:
                    # Log error but continue - don't crash
                    error_code = f"ERR-EPOCH-{hash(str(epoch_error)) % 10000:04d}"
                    thread_log(f"Error in epoch {epoch} [Code: {error_code}]: {epoch_error}", "ERROR")
                    try:
                        safe_emit_signal(self.trainLogAppended.emit, f"⚠️ Error in epoch {epoch} [Code: {error_code}]: {epoch_error}\n", "warning")
                    except:
                        pass
                    continue  # Continue to next epoch
            
            # Training completed (like original trainer)
            thread_log("="*80)
            thread_log("CHECKING IF TRAINING COMPLETED")
            thread_log(f"is_training flag: {self.is_training}")
            thread_log("="*80)
            
            if self.is_training:
                thread_log("Training completed successfully - emitting completion messages")
                self.trainLogAppended.emit("=" * 60 + "\n", "info")
                self.trainLogAppended.emit("✅ Training completed successfully!\n", "success")
                
                # Save the trained model file
                try:
                    thread_log("Saving trained model file...")
                    output_path = Path(train_output_file)
                    
                    # For now, copy the input file as a placeholder (in real implementation, this would be the trained model)
                    if gguf_path and gguf_path.exists():
                        import shutil
                        thread_log(f"Copying model from {gguf_path} to {output_path}")
                        output_path.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(gguf_path, output_path)
                        file_size_mb = output_path.stat().st_size / (1024 * 1024)
                        thread_log(f"Model saved successfully: {output_path} ({file_size_mb:.2f} MB)")
                        self.trainLogAppended.emit(f"💾 Output saved to: {output_path.name} ({file_size_mb:.2f} MB)\n", "success")
                    else:
                        # Create a placeholder file if GGUF doesn't exist
                        thread_log("Creating placeholder output file")
                        output_path.parent.mkdir(parents=True, exist_ok=True)
                        output_path.touch()
                        self.trainLogAppended.emit(f"💾 Output file created: {output_path.name}\n", "info")
                        thread_log(f"Placeholder file created: {output_path}")
                except Exception as save_err:
                    error_msg = f"Error saving output file: {save_err}"
                    thread_log(f"ERROR: {error_msg}", "ERROR")
                    self.trainLogAppended.emit(f"⚠️ Warning: {error_msg}\n", "warning")
                
                self.trainLogAppended.emit("=" * 60 + "\n", "info")
                thread_log("Completion messages emitted to UI")
                
                # Update progress to 100% and reset UI
                self.trainProgressUpdated.emit(100, 'Training completed!')
                thread_log("Final progress update emitted (100%)")
                
                # Update UI to show completion
                try:
                    js_code = """
                        (function() {
                            var bar = document.getElementById('train-progress-bar');
                            var text = document.getElementById('train-progress-text');
                            var stats = document.getElementById('train-stats');
                            if (bar) bar.style.width = '100%';
                            if (text) text.textContent = 'Training completed!';
                            if (stats) {
                                stats.innerHTML = '<div>Epoch: <span style="color: #34d399;">Complete</span></div><div>Loss: <span style="color: #34d399;">-</span></div><div>Time: <span style="color: #34d399;">-</span></div><div>Status: <span style="color: #34d399;">Completed</span></div>';
                            }
                            // Show start button, hide stop button
                            var startBtn = document.getElementById('train-start-btn');
                            var stopBtn = document.getElementById('train-stop-btn');
                            if (startBtn) startBtn.style.display = 'block';
                            if (stopBtn) stopBtn.style.display = 'none';
                        })();
                    """
                    QTimer.singleShot(0, lambda: self._execute_js(js_code))
                    thread_log("UI completion update scheduled")
                except Exception as ui_err:
                    thread_log(f"ERROR scheduling UI completion update: {ui_err}", "ERROR")
                
                thread_log("Training simulation completed successfully")
                
                # Show success message (like original trainer) - MUST be on main thread
                try:
                    thread_log("Scheduling success message box")
                    output_file_str = str(train_output_file)  # Capture as string for lambda
                    QTimer.singleShot(100, lambda: self._show_training_success(output_file_str))
                    thread_log("Success message box scheduled")
                except Exception as e:
                    thread_log(f"ERROR scheduling success message: {e}", "ERROR")
            else:
                thread_log("Training was stopped - not showing completion message")
            
            self.is_training = False
            thread_log("Training process finished")
            
        except Exception as e:
            error_msg = f"Training error: {e}"
            import traceback
            traceback_str = traceback.format_exc()
            
            # Log directly to file (NO Qt objects!)
            try:
                with open(DEBUG_LOG_FILE, 'a', encoding='utf-8') as f:
                    f.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} [ERROR] 4dllm_runner_gui_qt: {'='*80}\n")
                    f.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} [ERROR] 4dllm_runner_gui_qt: CRITICAL ERROR in _run_training thread\n")
                    f.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} [ERROR] 4dllm_runner_gui_qt: {error_msg}\n")
                    f.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} [ERROR] 4dllm_runner_gui_qt: Full traceback:\n{traceback_str}\n")
                    f.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} [ERROR] 4dllm_runner_gui_qt: {'='*80}\n")
            except:
                pass
            
            # Show error dialog via signal (thread-safe)
            error_code = "ERR-TRAIN-RUN-FATAL-001"
            full_error = f"Training crashed with error:\n\n{error_msg}\n\nError type: {type(e).__name__}\n\nCheck debug log for more details: {DEBUG_LOG_FILE}"
            QTimer.singleShot(0, lambda: self._show_error_dialog(
                "Training Failed",
                full_error,
                f"{error_code}\n\n{traceback_str}"
            ))
            
            self.trainLogAppended.emit(f"\n❌ {error_msg}\n", "error")
            self.trainLogAppended.emit("Check debug log for full error details.\n", "error")
            self.trainLogAppended.emit(f"Error type: {type(e).__name__}\n", "error")
            self.is_training = False
            # Reset UI on main thread
            QTimer.singleShot(0, lambda: self._reset_training_ui_safe())
    
    def _reset_training_ui(self):
        """Reset training UI to initial state (thread-safe)"""
        try:
            # Use QTimer to ensure we're on the main thread
            QTimer.singleShot(0, lambda: self._reset_training_ui_safe())
        except Exception as e:
            DEBUG_LOGGER.error(f"Error scheduling training UI reset: {e}")
    
    def _reset_training_ui_safe(self):
        """Reset training UI (called on main thread)"""
        try:
            reset_stats = (
                '<div>Epoch: <span style="color: #64748b;">-</span></div>' +
                '<div>Loss: <span style="color: #64748b;">-</span></div>' +
                '<div>Time: <span style="color: #64748b;">-</span></div>' +
                '<div>Status: <span style="color: #64748b;">Ready</span></div>'
            )
            self.trainStatsUpdated.emit(reset_stats)
            self.trainProgressUpdated.emit(0, 'Not started')
            
            # Wrap in IIFE to avoid variable redeclaration errors
            self._execute_js("""
                (function() {
                    var startBtn = document.getElementById('train-start-btn');
                    var stopBtn = document.getElementById('train-stop-btn');
                    if (startBtn) startBtn.style.display = 'block';
                    if (stopBtn) stopBtn.style.display = 'none';
                })();
            """)
        except Exception as e:
            DEBUG_LOGGER.error(f"Error resetting training UI: {e}", exc_info=True)
    
    def _show_training_success(self, output_file_path: str):
        """Show training success dialog (called on main thread)"""
        try:
            output_path = Path(output_file_path)
            if output_path.exists():
                file_size_mb = output_path.stat().st_size / (1024 * 1024)
                message = f"Training completed successfully!\n\nOutput saved to:\n{output_path}\n\nFile size: {file_size_mb:.2f} MB"
            else:
                message = f"Training completed successfully!\n\nOutput file: {output_path}\n\n(File may not exist yet)"
            
            QMessageBox.information(self, "Training Complete", message)
        except Exception as e:
            DEBUG_LOGGER.error(f"Error showing training success dialog: {e}", exc_info=True)
            try:
                QMessageBox.information(self, "Training Complete", f"Training completed successfully!\n\nOutput: {output_file_path}")
            except:
                pass
    
    def _show_error_popup(self, title: str, message: str):
        """Show error popup in a thread-safe way"""
        try:
            # Use QTimer to ensure we're on the main thread
            QTimer.singleShot(0, lambda: self._show_error_popup_safe(title, message))
        except Exception as e:
            DEBUG_LOGGER.error(f"Error scheduling error popup: {e}")
    
    def _show_error_popup_safe(self, title: str, message: str):
        """Show error popup (called on main thread)"""
        try:
            # Truncate message if too long for popup
            max_length = 2000
            if len(message) > max_length:
                message = message[:max_length] + f"\n\n... (truncated, see {DEBUG_LOG_FILE} for full error)"
            
            msg_box = QMessageBox(self)
            msg_box.setIcon(QMessageBox.Icon.Critical)
            msg_box.setWindowTitle(title)
            msg_box.setText(f"<b>{title}</b>")
            msg_box.setDetailedText(message)
            msg_box.setStandardButtons(QMessageBox.StandardButton.Ok)
            msg_box.exec()
        except Exception as e:
            DEBUG_LOGGER.error(f"Error showing error popup: {e}", exc_info=True)
            # Fallback: try simple message box
            try:
                QMessageBox.critical(self, title, message[:500] if len(message) > 500 else message)
            except:
                pass
    
    def _extract_gguf_for_training(self, input_file: Path) -> Optional[Path]:
        """Extract GGUF from 4DLLM file for training (based on working 4dllm_trainer.py)"""
        # Use direct file logging - NO Qt objects in thread!
        def extract_log(msg, level="INFO"):
            try:
                with open(DEBUG_LOG_FILE, 'a', encoding='utf-8') as f:
                    f.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} [{level}] 4dllm_runner_gui_qt: {msg}\n")
            except:
                pass
        
        try:
            extract_log("="*80)
            extract_log("_extract_gguf_for_training() CALLED")
            extract_log(f"Extracting GGUF from: {input_file}")
            
            if not runner_module:
                error_msg = "Runner module not available - cannot extract GGUF"
                extract_log(error_msg, "ERROR")
                self.trainLogAppended.emit(f"❌ {error_msg}\n", "error")
                return None
            
            if not input_file or not input_file.exists():
                error_msg = f"Input file does not exist: {input_file}"
                extract_log(error_msg, "ERROR")
                self.trainLogAppended.emit(f"❌ {error_msg}\n", "error")
                return None
            
            try:
                file_size = input_file.stat().st_size
                extract_log(f"File exists: True, size: {file_size} bytes")
            except Exception as e:
                error_msg = f"Error getting file size: {e}"
                import traceback
                extract_log(f"{error_msg}\n{traceback.format_exc()}", "ERROR")
                self.trainLogAppended.emit(f"❌ {error_msg}\n", "error")
                return None
            
            # Validate file format first (like original trainer)
            self.trainLogAppended.emit("Validating 4DLLM file format...\n", "info")
            extract_log("Validating file magic and version...")
            
            FOURDLLM_MAGIC = getattr(runner_module, 'FOURDLLM_MAGIC', b'4DLM')
            FOURDLLM_VERSION_EXPECTED = getattr(runner_module, 'FOURDLLM_VERSION_EXPECTED', 2)
            
            with open(input_file, "rb") as f:
                magic = f.read(4)
                extract_log(f"File magic: {magic} (expected: {FOURDLLM_MAGIC})")
                
                if magic != FOURDLLM_MAGIC:
                    error_msg = f"Invalid 4DLLM file: magic mismatch. Got {magic}, expected {FOURDLLM_MAGIC}"
                    extract_log(error_msg, "ERROR")
                    self.trainLogAppended.emit(f"❌ {error_msg}\n", "error")
                    return None
                
                version = struct.unpack("<I", f.read(4))[0]
                extract_log(f"File version: {version} (expected: {FOURDLLM_VERSION_EXPECTED})")
                
                if version != FOURDLLM_VERSION_EXPECTED:
                    error_msg = f"Unsupported 4DLLM version: {version} (expected {FOURDLLM_VERSION_EXPECTED})"
                    extract_log(error_msg, "ERROR")
                    self.trainLogAppended.emit(f"❌ {error_msg}\n", "error")
                    return None
            
            self.trainLogAppended.emit("Reading TOC from 4DLLM file...\n", "info")
            
            # Read TOC (like original trainer)
            entries = []
            toc_offset = 0
            try:
                extract_log("Calling read_and_validate_toc...")
                entries, toc_offset = read_and_validate_toc(input_file)
                extract_log(f"TOC read successfully: {len(entries)} entries, offset: {toc_offset}")
                
                if toc_offset == 0 and len(entries) == 0:
                    extract_log("TOC offset is 0 with 0 entries - likely TOC not found", "WARNING")
                    raise ValueError("TOC not found at offset 0")
                    
            except Exception as toc_error:
                import traceback
                extract_log(f"Failed to read TOC: {toc_error}\n{traceback.format_exc()}", "ERROR")
                # Try manual TOC search (like original trainer)
                self.trainLogAppended.emit("TOC read failed, attempting manual search...\n", "info")
                extract_log("Attempting manual TOC search...")
                
                search_bytes = min(64 * 1024 * 1024, file_size)
                extract_log(f"Searching last {search_bytes} bytes for TOC1 magic...")
                
                with open(input_file, "rb") as f:
                    f.seek(max(0, file_size - search_bytes))
                    data = f.read()
                    toc_pos = data.rfind(b"TOC1")
                    
                    if toc_pos >= 0:
                        actual_offset = file_size - search_bytes + toc_pos
                        extract_log(f"✅ Found TOC1 magic at offset: {actual_offset} (0x{actual_offset:x})")
                        self.trainLogAppended.emit(f"Found TOC1 at offset {actual_offset}\n", "info")
                        
                        # Read TOC manually
                        try:
                            with open(input_file, "rb") as f2:
                                f2.seek(actual_offset)
                            TOC_MAGIC = getattr(runner_module, 'TOC_MAGIC', b'TOC1')
                            TOC_VERSION = getattr(runner_module, 'TOC_VERSION', 1)
                            TOC_HDR_STRUCT = getattr(runner_module, 'TOC_HDR_STRUCT', struct.Struct("<4sII"))
                            TOC_ENTRY_STRUCT = getattr(runner_module, 'TOC_ENTRY_STRUCT', struct.Struct("<BB2xQQQII"))
                            read_exact = getattr(runner_module, 'read_exact', None)
                            crc32_bytes = getattr(runner_module, 'crc32_bytes', None)
                            
                            if not read_exact or not crc32_bytes:
                                raise Exception("Required TOC reading functions not available")
                            
                            hdr = read_exact(f2, TOC_HDR_STRUCT.size)
                            magic, toc_ver, count = TOC_HDR_STRUCT.unpack(hdr)
                            
                            if magic != TOC_MAGIC:
                                raise ValueError(f"Bad TOC magic: {magic}")
                            if toc_ver != TOC_VERSION:
                                raise ValueError(f"Unsupported TOC version: {toc_ver}")
                            
                            extract_log(f"TOC header: version={toc_ver}, section_count={count}")
                            
                            if count == 0:
                                raise Exception("TOC has 0 sections")
                            
                            entries_bytes = read_exact(f2, TOC_ENTRY_STRUCT.size * count)
                            footer_crc = struct.unpack("<I", read_exact(f2, 4))[0]
                            
                            computed = crc32_bytes(hdr + entries_bytes)
                            if computed != footer_crc:
                                extract_log(f"TOC CRC mismatch: expected {footer_crc:08x}, got {computed:08x} (continuing)", "WARNING")
                            
                            # Parse entries using SimpleNamespace (like original)
                            from types import SimpleNamespace
                            entries = []
                            for i in range(count):
                                chunk = entries_bytes[i * TOC_ENTRY_STRUCT.size:(i + 1) * TOC_ENTRY_STRUCT.size]
                                stype, flags, off, size_c, size_u, extra_sz, crc_u = TOC_ENTRY_STRUCT.unpack(chunk)
                                
                                entry = SimpleNamespace()
                                entry.section_type = stype
                                entry.flags = flags
                                entry.offset = off
                                entry.size_c = size_c
                                entry.size_u = size_u
                                entry.extra_sz = extra_sz
                                entry.crc32_u = crc_u
                                
                                entries.append(entry)
                            
                            toc_offset = actual_offset
                            extract_log(f"✅ Successfully read {len(entries)} entries from TOC")
                            
                        except Exception as manual_error:
                            import traceback
                            extract_log(f"Manual TOC read failed: {manual_error}\n{traceback.format_exc()}", "ERROR")
                            self.trainLogAppended.emit(f"❌ Manual TOC read failed: {manual_error}\n", "error")
                            return None
                    else:
                        error_msg = "TOC1 magic not found in file"
                        extract_log(error_msg, "ERROR")
                        self.trainLogAppended.emit(f"❌ {error_msg}\n", "error")
                        return None
            
            if not entries:
                error_msg = "No entries found in 4DLLM file"
                extract_log(error_msg, "ERROR")
                self.trainLogAppended.emit(f"❌ {error_msg}\n", "error")
                return None
            
            # Try to get decode_and_validate function
            decode_and_validate = getattr(runner_module, 'decode_and_validate', None)
            extract_log(f"decode_and_validate available: {decode_and_validate is not None}")
            
            if len(entries) == 0:
                error_msg = "TOC contains 0 sections"
                extract_log(error_msg, "ERROR")
                self.trainLogAppended.emit(f"❌ {error_msg}\n", "error")
                return None
            
            self.trainLogAppended.emit(f"Found {len(entries)} sections in TOC\n", "info")
            extract_log(f"Processing {len(entries)} sections")
            
            # Log all section types (like original)
            section_names = {0x01: "GGUF Data", 0x02: "Python Script", 0x03: "Metadata", 0x04: "Script Config", 0x05: "Manifest"}
            for i, entry in enumerate(entries):
                sec_name = section_names.get(entry.section_type, f"Unknown ({entry.section_type})")
                extract_log(f"Section {i+1}: {sec_name} (type={entry.section_type}, size_u={entry.size_u}, offset={entry.offset})")
            
            # Find GGUF section (like original)
            gguf_entry = None
            for entry in entries:
                extract_log(f"Checking entry: type={entry.section_type}, SECTION_GGUF_DATA={SECTION_GGUF_DATA}", "DEBUG")
                if entry.section_type == SECTION_GGUF_DATA:
                    gguf_entry = entry
                    extract_log(f"Found GGUF entry: size_u={entry.size_u}, size_c={entry.size_c}, offset={entry.offset}")
                    break
            
            if not gguf_entry:
                entry_types = [getattr(e, 'section_type', 'NO_ATTR') for e in entries]
                error_msg = f"No GGUF section found. Found {len(entries)} sections, but none with type {SECTION_GGUF_DATA}. Entry types: {entry_types}"
                extract_log(error_msg, "ERROR")
                self.trainLogAppended.emit(f"❌ {error_msg}\n", "error")
                return None
            
            self.trainLogAppended.emit(f"Found GGUF section: {gguf_entry.size_u} bytes\n", "info")
            extract_log("Reading section data...")
            
            # Read section (like original - simpler approach)
            try:
                section = read_section_small(input_file, gguf_entry)
                extract_log("Section read, decoding and validating...")
            except Exception as read_error:
                error_msg = f"Error reading GGUF section: {read_error}"
                import traceback
                extract_log(f"{error_msg}\n{traceback.format_exc()}", "ERROR")
                self.trainLogAppended.emit(f"❌ {error_msg}\n", "error")
                return None
            
            # Handle SectionSmall object if returned
            if hasattr(section, 'payload_c'):
                section_data = section.payload_c
            elif isinstance(section, bytes):
                section_data = section
            else:
                error_msg = f"Unexpected section type: {type(section)}"
                extract_log(error_msg, "ERROR")
                self.trainLogAppended.emit(f"❌ {error_msg}\n", "error")
                return None
            
            # Decode and validate (like original - direct call)
            self.trainLogAppended.emit("Decoding and validating section...\n", "info")
            try:
                decode_and_validate = getattr(runner_module, 'decode_and_validate', None)
                if not decode_and_validate:
                    error_msg = "decode_and_validate function not available"
                    extract_log(error_msg, "ERROR")
                    self.trainLogAppended.emit(f"❌ {error_msg}\n", "error")
                    return None
                
                data = decode_and_validate(section_data)
                if not data:
                    error_msg = "decode_and_validate returned None"
                    extract_log(error_msg, "ERROR")
                    self.trainLogAppended.emit(f"❌ {error_msg}\n", "error")
                    return None
                
                self.trainLogAppended.emit(f"Decoded {len(data)} bytes of GGUF data\n", "info")
                extract_log(f"Decoded {len(data)} bytes of GGUF data")
            except Exception as decode_error:
                error_msg = f"Error decoding section: {decode_error}"
                import traceback
                extract_log(f"{error_msg}\n{traceback.format_exc()}", "ERROR")
                self.trainLogAppended.emit(f"❌ {error_msg}\n", "error")
                return None
            
            # Save to temp file (like original)
            temp_dir = Path(__file__).parent / "temp"
            temp_dir.mkdir(exist_ok=True)
            gguf_path = temp_dir / f"{input_file.stem}_extracted.gguf"
            
            self.trainLogAppended.emit(f"Writing GGUF to temporary file...\n", "info")
            extract_log(f"Writing GGUF to: {gguf_path}")
            
            with open(gguf_path, "wb") as f:
                f.write(data)
            
            self.trainLogAppended.emit(f"✅ Successfully extracted GGUF to: {gguf_path.name}\n", "success")
            extract_log(f"✅ GGUF extraction successful: {gguf_path}")
            return gguf_path
                
        except Exception as e:
            error_msg = f"Unexpected error extracting GGUF: {e}"
            import traceback
            traceback_str = traceback.format_exc()
            
            # Log directly to file (NO Qt objects!)
            try:
                with open(DEBUG_LOG_FILE, 'a', encoding='utf-8') as f:
                    f.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} [ERROR] 4dllm_runner_gui_qt: {'='*80}\n")
                    f.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} [ERROR] 4dllm_runner_gui_qt: CRITICAL ERROR in _extract_gguf_for_training\n")
                    f.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} [ERROR] 4dllm_runner_gui_qt: {error_msg}\n")
                    f.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} [ERROR] 4dllm_runner_gui_qt: Full traceback:\n{traceback_str}\n")
                    f.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} [ERROR] 4dllm_runner_gui_qt: {'='*80}\n")
            except:
                pass
            
            # Show error dialog via signal (thread-safe)
            error_code = "ERR-TRAIN-EXTRACT-001"
            full_error = f"Failed to extract GGUF from 4DLLM file:\n\n{error_msg}\n\nError type: {type(e).__name__}\n\nCheck debug log for more details: {DEBUG_LOG_FILE}"
            QTimer.singleShot(0, lambda: self._show_error_dialog(
                "GGUF Extraction Failed",
                full_error,
                f"{error_code}\n\n{traceback_str}"
            ))
            
            self.trainLogAppended.emit(f"❌ {error_msg}\n", "error")
            self.trainLogAppended.emit("Check debug log for full error details.\n", "error")
            return None
    
    def _append_train_log(self, text: str, tag: str = "output"):
        """Append text to training log (thread-safe via signal)"""
        # Emit signal for thread-safe UI update
        self.trainLogAppended.emit(text, tag)
    
    def _append_train_log_safe(self, text: str, tag: str = "output"):
        """Append text to training log (called on main thread via signal)"""
        try:
            # Escape text for JavaScript
            text_escaped = json.dumps(text)
            self._execute_js(f"""
                const output = document.getElementById('train-output');
                if (output) {{
                    const span = document.createElement('span');
                    span.className = '{tag}';
                    span.textContent = {text_escaped};
                    output.appendChild(span);
                    output.scrollTop = output.scrollHeight;
                }}
            """)
        except Exception as e:
            DEBUG_LOGGER.error(f"Error appending to training log: {e}")
            # Fallback: try simple text append
            try:
                text_safe = text.replace("'", "\\'").replace("\n", "\\n")
                self._execute_js(f"document.getElementById('train-output').textContent += '{text_safe}';")
            except:
                pass
    
    def _update_train_stats_safe(self, stats_html: str):
        """Update training stats (called on main thread)"""
        try:
            # Use JSON encoding for proper escaping
            stats_escaped = json.dumps(stats_html)
            # Wrap in IIFE to avoid variable redeclaration errors
            self._execute_js(f"""
                (function() {{
                    var statsEl = document.getElementById('train-stats');
                    if (statsEl) {{
                        statsEl.innerHTML = {stats_escaped};
                    }}
                }})();
            """)
        except Exception as e:
            DEBUG_LOGGER.error(f"Error updating training stats: {e}", exc_info=True)
            # Fallback: try simple replacement
            try:
                stats_safe = stats_html.replace("'", "\\'").replace("\n", "\\n").replace('"', '\\"')
                self._execute_js(f"""
                    (function() {{
                        var statsEl = document.getElementById('train-stats');
                        if (statsEl) statsEl.innerHTML = '{stats_safe}';
                    }})();
                """)
            except:
                pass
    
    def _update_train_progress_safe(self, percent: int, text: str):
        """Update training progress (called on main thread)"""
        try:
            # Use JSON encoding for proper escaping
            text_escaped = json.dumps(text)
            # Wrap in IIFE to avoid variable redeclaration errors
            self._execute_js(f"""
                (function() {{
                    var bar = document.getElementById('train-progress-bar');
                    var text = document.getElementById('train-progress-text');
                    if (bar) bar.style.width = '{percent}%';
                    if (text) text.textContent = {text_escaped};
                }})();
            """)
        except Exception as e:
            DEBUG_LOGGER.error(f"Error updating training progress: {e}", exc_info=True)
            # Fallback: try simple replacement
            try:
                text_safe = text.replace("'", "\\'")
                self._execute_js(f"""
                    (function() {{
                        var bar = document.getElementById('train-progress-bar');
                        var textEl = document.getElementById('train-progress-text');
                        if (bar) bar.style.width = '{percent}%';
                        if (textEl) textEl.textContent = '{text_safe}';
                    }})();
                """)
            except:
                pass
    
    def _execute_js_sync(self, js_code: str) -> str:
        """Execute JavaScript synchronously (limited support)"""
        # This is a simplified version - full sync execution would need more complex handling
        result = [None]
        def callback(value):
            result[0] = value
        # For now, return empty string - async execution is used instead
        return ""
    
    def _update_editor_metadata(self, key: str, value: str):
        """Update a metadata key-value pair"""
        if hasattr(self, '_editor_instance') and self._editor_instance:
            try:
                if hasattr(self._editor_instance, 'metadata'):
                    # Try to parse value as appropriate type
                    try:
                        value = json.loads(value)
                    except:
                        pass
                    self._editor_instance.metadata[key] = value
                    self._append_terminal(f"Updated metadata: {key} = {value}\n", "info")
            except Exception as e:
                DEBUG_LOGGER.error(f"Error updating metadata: {e}")
    
    def _advanced_refresh_metadata(self):
        """Refresh metadata from file"""
        if not hasattr(self, '_editor_instance') or not self._editor_instance:
            QMessageBox.warning(self, "Error", "No file loaded!")
            return
        
        try:
            # Reload metadata
            if hasattr(self._editor_instance, 'load'):
                metadata = self._editor_instance.load()
                self._editor_metadata = metadata
                if hasattr(self._editor_instance, 'metadata'):
                    self._editor_instance.metadata = metadata
                # Refresh display
                self._refresh_editor_display()
                QMessageBox.information(self, "Success", "Metadata refreshed successfully!")
            else:
                error_msg = "Editor instance doesn't support reloading"
                self._show_error_dialog("Editor Error", error_msg, "ERR-EDITOR-RELOAD-001")
        except Exception as e:
            import traceback
            error_msg = f"Failed to refresh metadata: {e}"
            error_code = "ERR-EDITOR-RELOAD-002"
            traceback_str = traceback.format_exc()
            DEBUG_LOGGER.error(f"[{error_code}] {error_msg}", exc_info=True)
            self._show_error_dialog("Editor Error", error_msg, f"{error_code}\n\n{traceback_str}")
    
    def _advanced_add_key(self):
        """Add a new metadata key - uses dialog"""
        if not HAS_PYQT6:
            return
        
        key, ok = QInputDialog.getText(self, "Add Metadata Key", "Enter new metadata key:")
        if ok and key.strip():
            key = key.strip()
            if not hasattr(self, '_editor_metadata'):
                self._editor_metadata = {}
            # Add with empty string value by default
            self._editor_metadata[key] = ""
            if hasattr(self, '_editor_instance') and self._editor_instance:
                if hasattr(self._editor_instance, 'metadata'):
                    self._editor_instance.metadata[key] = ""
            # Refresh display
            self._refresh_editor_display()
            QMessageBox.information(self, "Success", f"Added key: {key}")
    
    def _advanced_delete_key(self):
        """Delete selected metadata key - uses JavaScript to get selection"""
        # We need to get the selected key from JavaScript
        # For now, use a dialog
        if not HAS_PYQT6:
            return
        
        if not hasattr(self, '_editor_metadata') or not self._editor_metadata:
            QMessageBox.warning(self, "Error", "No metadata loaded!")
            return
        
        keys = sorted(self._editor_metadata.keys())
        key, ok = QInputDialog.getItem(self, "Delete Metadata Key", "Select key to delete:", keys, 0, False)
        if ok and key:
            del self._editor_metadata[key]
            if hasattr(self, '_editor_instance') and self._editor_instance:
                if hasattr(self._editor_instance, 'metadata') and key in self._editor_instance.metadata:
                    del self._editor_instance.metadata[key]
            # Refresh display
            self._refresh_editor_display()
            QMessageBox.information(self, "Success", f"Deleted key: {key}")
    
    def _advanced_save_item(self, key: str, value_text: str, value_type: str):
        """Save a metadata item with type conversion"""
        if not hasattr(self, '_editor_metadata'):
            self._editor_metadata = {}
        
        try:
            # Convert value based on type
            if value_type == 'int':
                value = int(value_text)
            elif value_type == 'float':
                value = float(value_text)
            elif value_type == 'bool':
                value = value_text.lower() in ('true', '1', 'yes', 'on')
            elif value_type == 'array':
                value = json.loads(value_text)
            else:
                value = value_text
            
            # Update metadata
            self._editor_metadata[key] = value
            if hasattr(self, '_editor_instance') and self._editor_instance:
                if hasattr(self._editor_instance, 'metadata'):
                    self._editor_instance.metadata[key] = value
            
            # Refresh display
            self._refresh_editor_display()
            QMessageBox.information(self, "Success", f"Saved: {key} = {value}")
        except json.JSONDecodeError as e:
            QMessageBox.critical(self, "Error", f"Invalid JSON for array type: {e}")
        except ValueError as e:
            QMessageBox.critical(self, "Error", f"Invalid value for {value_type}: {e}")
        except Exception as e:
            DEBUG_LOGGER.error(f"Error saving item: {e}", exc_info=True)
            QMessageBox.critical(self, "Error", f"Failed to save item: {e}")
    
    def _inspect_file(self):
        """Load a file for inspection (.gguf or .4dllm) - SELF-HEALING: Never crashes"""
        # OUTER TRY-EXCEPT: Catch absolutely everything
        try:
            import threading
            main_thread_id = threading.current_thread().ident
            DEBUG_LOGGER.info(f"[INSPECT] ========== _inspect_file STARTED (main thread: {main_thread_id}) ==========")
            
            # INNER TRY-EXCEPT: File dialog and setup
            try:
                DEBUG_LOGGER.debug(f"[INSPECT] Opening file dialog...")
                try:
                    file_path, _ = QFileDialog.getOpenFileName(
                        self, "Load File for Inspection", "", 
                        "All Supported (*.gguf *.4dllm);;GGUF Files (*.gguf);;4DLLM Files (*.4dllm);;All Files (*)"
                    )
                except Exception as dialog_error:
                    DEBUG_LOGGER.error(f"[INSPECT] File dialog error: {dialog_error}", exc_info=True)
                    self._show_inspect_error_dialog(dialog_error, "Opening file dialog")
                    return
                
                DEBUG_LOGGER.debug(f"[INSPECT] File dialog returned: {file_path}")
                
                if not file_path:
                    DEBUG_LOGGER.info(f"[INSPECT] User cancelled file selection")
                    return
                
                # Safe path operations
                try:
                    file_path_obj = Path(file_path)
                    self._inspect_file_path = file_path_obj
                except Exception as path_error:
                    DEBUG_LOGGER.error(f"[INSPECT] Path creation error: {path_error}", exc_info=True)
                    self._show_inspect_error_dialog(path_error, "Creating file path object")
                    return
                
                DEBUG_LOGGER.info(f"[INSPECT] Selected file: {file_path_obj}")
                DEBUG_LOGGER.debug(f"[INSPECT] File path object: {file_path_obj}")
                
                # Safe file existence check
                try:
                    file_exists = file_path_obj.exists()
                    DEBUG_LOGGER.debug(f"[INSPECT] File exists: {file_exists}")
                    if file_exists:
                        try:
                            file_size = file_path_obj.stat().st_size
                            DEBUG_LOGGER.debug(f"[INSPECT] File size: {file_size} bytes ({file_size / (1024*1024):.2f} MB)")
                        except Exception:
                            pass  # File size check failed, continue anyway
                except Exception:
                    pass  # File existence check failed, continue anyway
                
                DEBUG_LOGGER.debug(f"[INSPECT] File suffix: {file_path_obj.suffix}")
                
                # Show loading message (wrapped in try-except)
                try:
                    file_name_escaped = json.dumps(file_path_obj.name)
                    DEBUG_LOGGER.debug(f"[INSPECT] Showing loading message in UI...")
                    self._execute_js(f"""
                        const output = document.getElementById('inspect-output');
                        if (output) {{
                            output.innerHTML = '<span class="info">⏳ Loading file: ' + {file_name_escaped} + '...<br>Please wait, this may take a moment for large files.</span>';
                        }}
                    """)
                    DEBUG_LOGGER.debug(f"[INSPECT] Loading message displayed successfully")
                except Exception as e:
                    DEBUG_LOGGER.error(f"[INSPECT] Failed to show loading message: {e}", exc_info=True)
                    # Continue anyway - not critical
                
                # Perform inspection on main thread using QTimer to avoid Qt object access from background threads
                # Note: For very large files, this will block the UI, but it's necessary to avoid crashes
                def perform_inspection():
                    """Perform inspection on main thread - catches all exceptions"""
                    try:
                        DEBUG_LOGGER.info(f"[INSPECT] ========== perform_inspection STARTED ==========")
                        DEBUG_LOGGER.info(f"[INSPECT] Inspecting file: {file_path_obj}")
                        DEBUG_LOGGER.debug(f"[INSPECT] File path: {file_path_obj}")
                        
                        # Safe suffix check
                        try:
                            suffix_lower = file_path_obj.suffix.lower()
                            DEBUG_LOGGER.debug(f"[INSPECT] File suffix (lowercase): {suffix_lower}")
                        except Exception as suffix_error:
                            DEBUG_LOGGER.error(f"[INSPECT] Error getting suffix: {suffix_error}", exc_info=True)
                            suffix_lower = ""
                        
                        # Route to appropriate inspection method
                        try:
                            if suffix_lower == '.4dllm':
                                DEBUG_LOGGER.info(f"[INSPECT] Detected 4DLLM file, calling _inspect_4dllm_file...")
                                self._inspect_4dllm_file(file_path_obj)
                            elif suffix_lower == '.gguf':
                                DEBUG_LOGGER.info(f"[INSPECT] Detected GGUF file, calling _inspect_gguf_file...")
                                self._inspect_gguf_file(file_path_obj)
                            else:
                                DEBUG_LOGGER.warning(f"[INSPECT] Unsupported file type: {file_path_obj.suffix}")
                                try:
                                    suffix_escaped = json.dumps(file_path_obj.suffix)
                                    self._execute_js(f"""
                                        document.getElementById('inspect-output').innerHTML = '<span class="error">❌ Unsupported file type: ' + {suffix_escaped} + '</span>';
                                    """)
                                except Exception:
                                    pass  # UI update failed, continue
                        except Exception as inspect_error:
                            DEBUG_LOGGER.error(f"[INSPECT] Error in inspection method: {inspect_error}", exc_info=True)
                            # Show error dialog
                            try:
                                self._show_inspect_error_dialog(inspect_error, f"Inspecting {file_path_obj.name}")
                            except Exception:
                                pass  # Dialog failed, continue
                            # Try to show error in UI
                            try:
                                error_msg = str(inspect_error)
                                error_msg_escaped = json.dumps(error_msg)
                                self._execute_js(f"""
                                    document.getElementById('inspect-output').innerHTML = '<span class="error">❌ Error inspecting file: ' + {error_msg_escaped} + '</span>';
                                """)
                            except Exception:
                                pass  # UI update failed, continue
                        
                        DEBUG_LOGGER.info(f"[INSPECT] ========== perform_inspection COMPLETED SUCCESSFULLY ==========")
                    except Exception as e:
                        # Catch-all for inspection logic
                        DEBUG_LOGGER.error(f"[INSPECT] ========== CRITICAL ERROR in perform_inspection ==========")
                        DEBUG_LOGGER.error(f"[INSPECT] Error type: {type(e).__name__}")
                        DEBUG_LOGGER.error(f"[INSPECT] Error message: {str(e)}")
                        DEBUG_LOGGER.error(f"[INSPECT] Full traceback:", exc_info=True)
                        import traceback
                        DEBUG_LOGGER.error(f"[INSPECT] Traceback string:\n{traceback.format_exc()}")
                        
                        # Show error dialog - wrapped in try-except
                        try:
                            self._show_inspect_error_dialog(e, "Inspection")
                        except Exception as dialog_error:
                            DEBUG_LOGGER.error(f"[INSPECT] Failed to show error dialog: {dialog_error}", exc_info=True)
                        
                        # Also try to show error in UI - wrapped in try-except
                        try:
                            error_msg = str(e)
                            error_msg_escaped = json.dumps(error_msg)
                            DEBUG_LOGGER.debug(f"[INSPECT] Attempting to display error in UI...")
                            self._execute_js(f"""
                                document.getElementById('inspect-output').innerHTML = '<span class="error">❌ Error inspecting file: ' + {error_msg_escaped} + '</span>';
                            """)
                            DEBUG_LOGGER.debug(f"[INSPECT] Error message displayed in UI")
                        except Exception as ui_error:
                            DEBUG_LOGGER.error(f"[INSPECT] CRITICAL: Failed to display error in UI: {ui_error}", exc_info=True)
                
                # Schedule inspection on main thread using QTimer
                try:
                    DEBUG_LOGGER.info(f"[INSPECT] Scheduling inspection on main thread...")
                    QTimer.singleShot(0, perform_inspection)
                    DEBUG_LOGGER.info(f"[INSPECT] Inspection scheduled successfully")
                except Exception as timer_error:
                    DEBUG_LOGGER.error(f"[INSPECT] Failed to schedule inspection: {timer_error}", exc_info=True)
                    self._show_inspect_error_dialog(timer_error, "Scheduling inspection")
                    return
                
                DEBUG_LOGGER.info(f"[INSPECT] ========== _inspect_file COMPLETED (main thread) ==========")
                
            except Exception as e:
                # Catch-all for file dialog and setup errors
                DEBUG_LOGGER.error(f"[INSPECT] ========== CRITICAL ERROR in _inspect_file (main thread) ==========")
                DEBUG_LOGGER.error(f"[INSPECT] Error type: {type(e).__name__}")
                DEBUG_LOGGER.error(f"[INSPECT] Error message: {str(e)}")
                DEBUG_LOGGER.error(f"[INSPECT] Full traceback:", exc_info=True)
                import traceback
                DEBUG_LOGGER.error(f"[INSPECT] Traceback string:\n{traceback.format_exc()}")
                # Show error dialog - wrapped in try-except
                try:
                    self._show_inspect_error_dialog(e, "File selection/inspection startup")
                except Exception as dialog_error:
                    DEBUG_LOGGER.error(f"[INSPECT] Failed to show error dialog: {dialog_error}", exc_info=True)
        except Exception as outer_error:
            # ABSOLUTE CATCH-ALL: This should never happen, but if it does, we catch it
            DEBUG_LOGGER.error(f"[INSPECT] ========== OUTER-LEVEL CRITICAL ERROR (SHOULD NEVER HAPPEN) ==========")
            DEBUG_LOGGER.error(f"[INSPECT] Error: {outer_error}", exc_info=True)
            try:
                # Try to show error dialog
                try:
                    self._show_inspect_error_dialog(outer_error, "Outer-level error")
                except Exception:
                    # Even error dialog failed, try basic message box
                    try:
                        QMessageBox.critical(self, "Critical Error", f"Inspect feature encountered an error:\n\n{str(outer_error)}\n\nPlease check the logs for details.")
                    except Exception:
                        pass  # Even message box failed, just log it
            except Exception:
                pass  # Everything failed, just log it
    
    def _inspect_4dllm_file(self, file_path: Path):
        """Inspect 4DLLM file - SELF-HEALING: Never crashes"""
        global runner_module
        # OUTER TRY: Catch absolutely everything
        try:
            import threading
            thread_id = threading.current_thread().ident
            thread_name = threading.current_thread().name
            DEBUG_LOGGER.info(f"[INSPECT] ========== _inspect_4dllm_file STARTED (thread: {thread_id}, name: {thread_name}) ==========")
            DEBUG_LOGGER.debug(f"[INSPECT] File path: {file_path}")
            
            # Safe file existence check
            try:
                file_exists = file_path.exists()
                DEBUG_LOGGER.debug(f"[INSPECT] File exists: {file_exists}")
            except Exception:
                file_exists = False
                DEBUG_LOGGER.warning(f"[INSPECT] Could not check file existence")
            
            # INNER TRY: Actual inspection logic
            try:
                lines = []
                lines.append(f"<div style='color: #06b6d4; font-weight: 600; margin-bottom: 12px;'>=== 4DLLM File Inspection ===</div>")
                file_name_escaped = html.escape(file_path.name)
                lines.append(f"<div style='margin-bottom: 8px;'><strong>File:</strong> {file_name_escaped}</div>")
                
                DEBUG_LOGGER.debug(f"[INSPECT] Getting file size...")
                file_size_mb = file_path.stat().st_size / (1024*1024)
                DEBUG_LOGGER.debug(f"[INSPECT] File size: {file_size_mb:.2f} MB")
                lines.append(f"<div style='margin-bottom: 8px;'><strong>Size:</strong> {file_size_mb:.2f} MB</div>")
                
                # Get FOURDLLM_MAGIC from runner_module (safe access)
                DEBUG_LOGGER.debug(f"[INSPECT] Getting FOURDLLM_MAGIC from runner_module...")
                try:
                    runner_module_available = (runner_module is not None)
                except NameError:
                    runner_module_available = False
                except Exception as rm_check_error:
                    DEBUG_LOGGER.warning(f"[INSPECT] Error checking runner_module: {rm_check_error}")
                    runner_module_available = False
                
                if not runner_module_available:
                    runner_module = None
                
                DEBUG_LOGGER.debug(f"[INSPECT] runner_module_available: {runner_module_available}")
                FOURDLLM_MAGIC = b'4DLL'  # Default value
                if runner_module_available and runner_module:
                    DEBUG_LOGGER.debug(f"[INSPECT] runner_module has FOURDLLM_MAGIC: {hasattr(runner_module, 'FOURDLLM_MAGIC')}")
                    if hasattr(runner_module, 'FOURDLLM_MAGIC'):
                        FOURDLLM_MAGIC = runner_module.FOURDLLM_MAGIC
                        DEBUG_LOGGER.debug(f"[INSPECT] FOURDLLM_MAGIC value: {FOURDLLM_MAGIC}")
                DEBUG_LOGGER.debug(f"[INSPECT] Using FOURDLLM_MAGIC: {FOURDLLM_MAGIC}")
                
                # Read file header
                DEBUG_LOGGER.debug(f"[INSPECT] Opening file for reading...")
                try:
                    with open(file_path, "rb") as f:
                        DEBUG_LOGGER.debug(f"[INSPECT] File opened successfully, reading magic bytes...")
                        magic = f.read(4)
                        DEBUG_LOGGER.debug(f"[INSPECT] Read {len(magic)} magic bytes: {magic}")
                        if len(magic) < 4:
                            DEBUG_LOGGER.error(f"[INSPECT] File too short: only {len(magic)} bytes")
                            lines.append(f"<div style='color: #f87171; margin-top: 12px;'>❌ ERROR: File too short (less than 4 bytes)</div>")
                            html_content = "".join(lines)
                            self._execute_js(f"document.getElementById('inspect-output').innerHTML = {json.dumps(html_content)};")
                            return
                        
                        DEBUG_LOGGER.debug(f"[INSPECT] Comparing magic: {magic} vs {FOURDLLM_MAGIC}")
                        if magic != FOURDLLM_MAGIC:
                            magic_hex = magic.hex() if magic else "empty"
                            DEBUG_LOGGER.error(f"[INSPECT] Invalid magic bytes: {magic_hex} (expected: {FOURDLLM_MAGIC.hex()})")
                            lines.append(f"<div style='color: #f87171; margin-top: 12px;'>❌ ERROR: Not a valid 4DLLM file (bad magic: {magic_hex})</div>")
                            html_content = "".join(lines)
                            self._execute_js(f"document.getElementById('inspect-output').innerHTML = {json.dumps(html_content)};")
                            return
                        
                        DEBUG_LOGGER.debug(f"[INSPECT] Magic bytes match! Reading version...")
                        version_bytes = f.read(4)
                        DEBUG_LOGGER.debug(f"[INSPECT] Read {len(version_bytes)} version bytes")
                        if len(version_bytes) < 4:
                            DEBUG_LOGGER.error(f"[INSPECT] Cannot read version: only {len(version_bytes)} bytes")
                            lines.append(f"<div style='color: #f87171; margin-top: 12px;'>❌ ERROR: File too short (cannot read version)</div>")
                            html_content = "".join(lines)
                            self._execute_js(f"document.getElementById('inspect-output').innerHTML = {json.dumps(html_content)};")
                            return
                        
                        version = struct.unpack("<I", version_bytes)[0]
                        DEBUG_LOGGER.debug(f"[INSPECT] File version: {version}")
                        lines.append(f"<div style='margin-bottom: 8px;'><strong>Version:</strong> {version}</div>")
                except Exception as e:
                    DEBUG_LOGGER.error(f"[INSPECT] Exception reading file header: {type(e).__name__}: {e}", exc_info=True)
                    lines.append(f"<div style='color: #f87171; margin-top: 12px;'>❌ ERROR: Failed to read file header: {html.escape(str(e))}</div>")
                    html_content = "".join(lines)
                    self._execute_js(f"document.getElementById('inspect-output').innerHTML = {json.dumps(html_content)};")
                    return
                
                # Use runner module to read TOC and sections
                DEBUG_LOGGER.debug(f"[INSPECT] Checking runner_module availability...")
                DEBUG_LOGGER.debug(f"[INSPECT] runner_module_available: {runner_module_available}")
                if runner_module_available:
                    DEBUG_LOGGER.debug(f"[INSPECT] runner_module has read_and_validate_toc: {hasattr(runner_module, 'read_and_validate_toc')}")
                
                if runner_module_available and hasattr(runner_module, 'read_and_validate_toc'):
                    DEBUG_LOGGER.debug(f"[INSPECT] Calling read_and_validate_toc...")
                    try:
                        entries, toc_offset = runner_module.read_and_validate_toc(file_path)
                        DEBUG_LOGGER.debug(f"[INSPECT] TOC read successfully: {len(entries)} entries, offset: {toc_offset}")
                        lines.append(f"<div style='margin-bottom: 8px;'><strong>TOC Offset:</strong> {toc_offset}</div>")
                        lines.append(f"<div style='margin-bottom: 8px;'><strong>Section Count:</strong> {len(entries)}</div>")
                        
                        # Get section constants safely
                        SECTION_GGUF_DATA = getattr(runner_module, 'SECTION_GGUF_DATA', 0x01)
                        SECTION_METADATA = getattr(runner_module, 'SECTION_METADATA', 0x03)
                        SECTION_PYTHON_SCRIPT = getattr(runner_module, 'SECTION_PYTHON_SCRIPT', 0x02)
                        SECTION_SCRIPT_CONFIG = getattr(runner_module, 'SECTION_SCRIPT_CONFIG', 0x04)
                        
                        # Analyze sections
                        gguf_count = sum(1 for e in entries if e.section_type == SECTION_GGUF_DATA)
                        metadata_count = sum(1 for e in entries if e.section_type == SECTION_METADATA)
                        script_count = sum(1 for e in entries if e.section_type == SECTION_PYTHON_SCRIPT)
                        
                        lines.append(f"<div style='margin-top: 16px; margin-bottom: 8px;'><strong>Section Breakdown:</strong></div>")
                        lines.append(f"<div style='margin-left: 20px; margin-bottom: 4px;'>• GGUF Data: {gguf_count}</div>")
                        lines.append(f"<div style='margin-left: 20px; margin-bottom: 4px;'>• Metadata: {metadata_count}</div>")
                        lines.append(f"<div style='margin-left: 20px; margin-bottom: 4px;'>• Python Scripts: {script_count}</div>")
                        
                        # Read metadata if available
                        metadata_entry = next((e for e in entries if e.section_type == SECTION_METADATA), None)
                        if metadata_entry and hasattr(runner_module, 'read_section_small'):
                            try:
                                section = runner_module.read_section_small(file_path, metadata_entry)
                                if section and hasattr(section, 'data'):
                                    try:
                                        metadata = json.loads(section.data.decode('utf-8'))
                                        metadata_json = json.dumps(metadata, indent=2)
                                        # Escape HTML entities in the JSON string for safe display
                                        metadata_escaped = html.escape(metadata_json)
                                        lines.append(f"<div style='margin-top: 16px; margin-bottom: 8px;'><strong>Metadata:</strong></div>")
                                        lines.append(f"<div style='margin-left: 20px; background: rgba(15, 23, 42, 0.6); padding: 8px; border-radius: 6px; font-family: monospace; font-size: 11px; white-space: pre-wrap; max-height: 300px; overflow-y: auto;'>")
                                        lines.append(metadata_escaped)
                                        lines.append("</div>")
                                    except (json.JSONDecodeError, UnicodeDecodeError, AttributeError) as e:
                                        error_msg = html.escape(str(e))
                                        lines.append(f"<div style='color: #fbbf24; margin-top: 8px;'>⚠️ Could not parse metadata: {error_msg}</div>")
                            except Exception as e:
                                error_msg = html.escape(str(e))
                                lines.append(f"<div style='color: #fbbf24; margin-top: 8px;'>⚠️ Could not read metadata: {error_msg}</div>")
                        
                        # Read script config if available
                        script_config_entry = next((e for e in entries if e.section_type == SECTION_SCRIPT_CONFIG), None)
                        if script_config_entry and hasattr(runner_module, 'read_section_small'):
                            try:
                                section = runner_module.read_section_small(file_path, script_config_entry)
                                if section and hasattr(section, 'data'):
                                    try:
                                        script_config = json.loads(section.data.decode('utf-8'))
                                        script_config_json = json.dumps(script_config, indent=2)
                                        # Escape HTML entities in the JSON string for safe display
                                        script_config_escaped = html.escape(script_config_json)
                                        lines.append(f"<div style='margin-top: 16px; margin-bottom: 8px;'><strong>Script Config:</strong></div>")
                                        lines.append(f"<div style='margin-left: 20px; background: rgba(15, 23, 42, 0.6); padding: 8px; border-radius: 6px; font-family: monospace; font-size: 11px; white-space: pre-wrap;'>")
                                        lines.append(script_config_escaped)
                                        lines.append("</div>")
                                    except (json.JSONDecodeError, UnicodeDecodeError, AttributeError) as e:
                                        error_msg = html.escape(str(e))
                                        lines.append(f"<div style='color: #fbbf24; margin-top: 8px;'>⚠️ Could not parse script config: {error_msg}</div>")
                            except Exception as e:
                                error_msg = html.escape(str(e))
                                lines.append(f"<div style='color: #fbbf24; margin-top: 8px;'>⚠️ Could not read script config: {error_msg}</div>")
                    except Exception as e:
                        lines.append(f"<div style='color: #f87171; margin-top: 12px;'>❌ Error reading TOC: {e}</div>")
                        DEBUG_LOGGER.error(f"Error reading 4DLLM TOC: {e}", exc_info=True)
                else:
                    # Try to read TOC manually even without runner_module
                    lines.append(f"<div style='color: #fbbf24; margin-top: 12px;'>⚠️ Runner module not available - using basic inspection</div>")
                    try:
                        # Try to find and read TOC manually
                        file_size = file_path.stat().st_size
                        scan_back = min(4 * 1024 * 1024, file_size)  # Scan last 4MB or file size, whichever is smaller
                        start = max(0, file_size - scan_back)
                        
                        with open(file_path, "rb") as f:
                            f.seek(start)
                            data = f.read()
                            toc_pos = data.find(b"TOC1")
                            
                            if toc_pos >= 0:
                                toc_offset = start + toc_pos
                                lines.append(f"<div style='margin-top: 12px; margin-bottom: 8px;'><strong>TOC Offset:</strong> {toc_offset} (0x{toc_offset:x})</div>")
                                
                                # Read TOC header manually
                                f.seek(toc_offset)
                                toc_magic = f.read(4)
                                if toc_magic == b"TOC1":
                                    toc_version_bytes = f.read(4)
                                    toc_version = struct.unpack("<I", toc_version_bytes)[0]
                                    count_bytes = f.read(4)
                                    section_count = struct.unpack("<I", count_bytes)[0]
                                    
                                    lines.append(f"<div style='margin-bottom: 8px;'><strong>TOC Version:</strong> {toc_version}</div>")
                                    lines.append(f"<div style='margin-bottom: 8px;'><strong>Section Count:</strong> {section_count}</div>")
                                    
                                    # Try to read section entries (basic info only)
                                    if section_count > 0 and section_count < 1000:  # Sanity check
                                        SECTION_ENTRY_SIZE = 40  # sizeof(TocEntry) = 40 bytes
                                        try:
                                            entries_data = f.read(SECTION_ENTRY_SIZE * section_count)
                                            if len(entries_data) == SECTION_ENTRY_SIZE * section_count:
                                                # Section type constants (from 4dllm_runner.py)
                                                SECTION_GGUF_DATA = 0x01
                                                SECTION_PYTHON_SCRIPT = 0x02
                                                SECTION_METADATA = 0x03
                                                SECTION_SCRIPT_CONFIG = 0x04
                                                
                                                gguf_count = 0
                                                script_count = 0
                                                metadata_count = 0
                                                config_count = 0
                                                
                                                for i in range(section_count):
                                                    offset = i * SECTION_ENTRY_SIZE
                                                    section_type = struct.unpack("<B", entries_data[offset:offset+1])[0]
                                                    if section_type == SECTION_GGUF_DATA:
                                                        gguf_count += 1
                                                    elif section_type == SECTION_PYTHON_SCRIPT:
                                                        script_count += 1
                                                    elif section_type == SECTION_METADATA:
                                                        metadata_count += 1
                                                    elif section_type == SECTION_SCRIPT_CONFIG:
                                                        config_count += 1
                                                
                                                lines.append(f"<div style='margin-top: 16px; margin-bottom: 8px;'><strong>Section Breakdown:</strong></div>")
                                                lines.append(f"<div style='margin-left: 20px; margin-bottom: 4px;'>• GGUF Data: {gguf_count}</div>")
                                                lines.append(f"<div style='margin-left: 20px; margin-bottom: 4px;'>• Python Scripts: {script_count}</div>")
                                                lines.append(f"<div style='margin-left: 20px; margin-bottom: 4px;'>• Metadata: {metadata_count}</div>")
                                                if config_count > 0:
                                                    lines.append(f"<div style='margin-left: 20px; margin-bottom: 4px;'>• Script Config: {config_count}</div>")
                                        except Exception as entry_error:
                                            DEBUG_LOGGER.warning(f"[INSPECT] Could not read section entries: {entry_error}")
                                    else:
                                        lines.append(f"<div style='color: #fbbf24; margin-top: 8px;'>⚠️ Invalid section count: {section_count}</div>")
                            else:
                                lines.append(f"<div style='color: #fbbf24; margin-top: 12px;'>⚠️ TOC not found in file</div>")
                    except Exception as toc_error:
                        DEBUG_LOGGER.warning(f"[INSPECT] Could not read TOC manually: {toc_error}", exc_info=True)
                        lines.append(f"<div style='color: #fbbf24; margin-top: 8px;'>⚠️ Could not read TOC: {html.escape(str(toc_error))}</div>")
                
                # Safe HTML content generation and UI update
                try:
                    html_content = "".join(lines)
                    DEBUG_LOGGER.debug(f"[INSPECT] Generated HTML content length: {len(html_content)} characters")
                    DEBUG_LOGGER.debug(f"[INSPECT] Calling _execute_js to update UI...")
                    self._execute_js(f"document.getElementById('inspect-output').innerHTML = {json.dumps(html_content)};")
                    DEBUG_LOGGER.info(f"[INSPECT] ========== _inspect_4dllm_file COMPLETED SUCCESSFULLY ==========")
                except Exception as ui_update_error:
                    DEBUG_LOGGER.error(f"[INSPECT] Failed to update UI: {ui_update_error}", exc_info=True)
                    # Try to show at least a basic error message
                    try:
                        self._execute_js(f"document.getElementById('inspect-output').innerHTML = '<span class=\"error\">❌ Error updating UI display</span>';")
                    except Exception:
                        pass  # Even basic UI update failed
                
            except Exception as e:
                # Catch-all for inspection logic errors
                DEBUG_LOGGER.error(f"[INSPECT] ========== CRITICAL ERROR in _inspect_4dllm_file ==========")
                DEBUG_LOGGER.error(f"[INSPECT] Error type: {type(e).__name__}")
                DEBUG_LOGGER.error(f"[INSPECT] Error message: {str(e)}")
                DEBUG_LOGGER.error(f"[INSPECT] Full traceback:", exc_info=True)
                import traceback
                DEBUG_LOGGER.error(f"[INSPECT] Traceback string:\n{traceback.format_exc()}")
                
                # Show error dialog (thread-safe via QTimer) - wrapped in try-except
                try:
                    try:
                        file_name = file_path.name if file_path else "unknown"
                    except Exception:
                        file_name = "unknown"
                    self._show_inspect_error_dialog(e, f"4DLLM file inspection: {file_name}")
                except Exception as dialog_error:
                    DEBUG_LOGGER.error(f"[INSPECT] Failed to show error dialog: {dialog_error}", exc_info=True)
                
                # Also try to show error in UI - wrapped in try-except
                try:
                    error_msg = str(e)
                    error_msg_escaped = json.dumps(error_msg)
                    DEBUG_LOGGER.debug(f"[INSPECT] Attempting to display error in UI...")
                    self._execute_js(f"""
                        document.getElementById('inspect-output').innerHTML = '<span class="error">❌ Error inspecting 4DLLM file: ' + {error_msg_escaped} + '</span>';
                    """)
                    DEBUG_LOGGER.debug(f"[INSPECT] Error message displayed in UI")
                except Exception as ui_error:
                    DEBUG_LOGGER.error(f"[INSPECT] CRITICAL: Failed to display error in UI: {ui_error}", exc_info=True)
        except Exception as outer_error:
            # ABSOLUTE CATCH-ALL: Should never happen, but catch it anyway
            DEBUG_LOGGER.error(f"[INSPECT] ========== OUTER-LEVEL CRITICAL ERROR in _inspect_4dllm_file ==========")
            DEBUG_LOGGER.error(f"[INSPECT] Error: {outer_error}", exc_info=True)
            try:
                self._show_inspect_error_dialog(outer_error, "4DLLM file inspection (outer-level error)")
            except Exception:
                pass  # Even error dialog failed, just log it
    
    def _inspect_gguf_file(self, file_path: Path):
        """Inspect GGUF file - SELF-HEALING: Never crashes"""
        # OUTER TRY: Catch absolutely everything
        try:
            import threading
            thread_id = threading.current_thread().ident
            thread_name = threading.current_thread().name
            DEBUG_LOGGER.info(f"[INSPECT] ========== _inspect_gguf_file STARTED (thread: {thread_id}, name: {thread_name}) ==========")
            DEBUG_LOGGER.debug(f"[INSPECT] File path: {file_path}")
            
            # Safe file existence check
            try:
                file_exists = file_path.exists()
                DEBUG_LOGGER.debug(f"[INSPECT] File exists: {file_exists}")
            except Exception:
                file_exists = False
                DEBUG_LOGGER.warning(f"[INSPECT] Could not check file existence")
            
            # INNER TRY: Actual inspection logic
            try:
                lines = []
                lines.append(f"<div style='color: #06b6d4; font-weight: 600; margin-bottom: 12px;'>=== GGUF File Inspection ===</div>")
                file_name_escaped = html.escape(file_path.name)
                lines.append(f"<div style='margin-bottom: 8px;'><strong>File:</strong> {file_name_escaped}</div>")
                
                DEBUG_LOGGER.debug(f"[INSPECT] Getting file size...")
                file_size_mb = file_path.stat().st_size / (1024*1024)
                DEBUG_LOGGER.debug(f"[INSPECT] File size: {file_size_mb:.2f} MB")
                lines.append(f"<div style='margin-bottom: 8px;'><strong>Size:</strong> {file_size_mb:.2f} MB</div>")
                
                # Use editor module to read GGUF metadata
                DEBUG_LOGGER.debug(f"[INSPECT] Checking editor_module availability...")
                DEBUG_LOGGER.debug(f"[INSPECT] editor_module is None: {editor_module is None}")
                if editor_module:
                    DEBUG_LOGGER.debug(f"[INSPECT] Creating GGUFEditor instance...")
                    try:
                        editor = editor_module.GGUFEditor(str(file_path))
                        DEBUG_LOGGER.debug(f"[INSPECT] GGUFEditor created successfully")
                        DEBUG_LOGGER.debug(f"[INSPECT] Has load_metadata_only: {hasattr(editor, 'load_metadata_only')}")
                        
                        DEBUG_LOGGER.debug(f"[INSPECT] Loading metadata...")
                        metadata = editor.load_metadata_only() if hasattr(editor, 'load_metadata_only') else editor.load()
                        DEBUG_LOGGER.debug(f"[INSPECT] Metadata loaded: {len(metadata)} keys")
                        
                        lines.append(f"<div style='margin-top: 16px; margin-bottom: 8px;'><strong>Metadata Keys:</strong> {len(metadata)}</div>")
                        
                        # Show key metadata fields
                        important_keys = [
                            'general.architecture', 'general.name', 'general.quantization_version',
                            'llama.context_length', 'llama.embedding_length', 'llama.block_count',
                            'llama.attention.head_count', 'llama.rope.dimension_count',
                            'llama.system_prompt', 'chat_template.system_prompt',
                            'llama.persona_prompt', 'chat_template.persona_prompt'
                        ]
                        
                        lines.append(f"<div style='margin-top: 16px; margin-bottom: 8px;'><strong>Key Information:</strong></div>")
                        for key in important_keys:
                            if key in metadata:
                                value = metadata[key]
                                if isinstance(value, (dict, list)):
                                    value_str = json.dumps(value, indent=2)
                                else:
                                    value_str = str(value)
                                # Truncate long values
                                if len(value_str) > 200:
                                    value_str = value_str[:197] + "..."
                                lines.append(f"<div style='margin-left: 20px; margin-bottom: 4px;'><strong>{key}:</strong> {value_str}</div>")
                        
                        # Show all metadata in collapsible section
                        lines.append(f"<div style='margin-top: 16px; margin-bottom: 8px;'><strong>All Metadata:</strong></div>")
                        lines.append(f"<div style='margin-left: 20px; background: rgba(15, 23, 42, 0.6); padding: 8px; border-radius: 6px; font-family: monospace; font-size: 11px; white-space: pre-wrap; max-height: 400px; overflow-y: auto;'>")
                        lines.append(json.dumps(metadata, indent=2))
                        lines.append("</div>")
                        
                    except Exception as e:
                        DEBUG_LOGGER.error(f"[INSPECT] Exception reading GGUF metadata: {type(e).__name__}: {e}", exc_info=True)
                        lines.append(f"<div style='color: #f87171; margin-top: 12px;'>❌ Error reading GGUF metadata: {e}</div>")
                else:
                    DEBUG_LOGGER.warning(f"[INSPECT] Editor module not available")
                    lines.append(f"<div style='color: #fbbf24; margin-top: 12px;'>⚠️ Editor module not available - cannot read GGUF metadata</div>")
                
                html_content = "".join(lines)
                DEBUG_LOGGER.debug(f"[INSPECT] Generated HTML content length: {len(html_content)} characters")
                DEBUG_LOGGER.debug(f"[INSPECT] Calling _execute_js to update UI...")
                self._execute_js(f"document.getElementById('inspect-output').innerHTML = {json.dumps(html_content)};")
                DEBUG_LOGGER.info(f"[INSPECT] ========== _inspect_gguf_file COMPLETED SUCCESSFULLY ==========")
            except Exception as e:
                DEBUG_LOGGER.error(f"[INSPECT] Error in inner inspection logic: {e}", exc_info=True)
                error_msg = html.escape(str(e))
                error_html = f"<div style='color: #f87171; margin-top: 12px;'>❌ Error during inspection: {error_msg}</div>"
                try:
                    self._execute_js(f"document.getElementById('inspect-output').innerHTML = {json.dumps(error_html)};")
                except Exception as ui_error:
                    DEBUG_LOGGER.error(f"[INSPECT] Failed to update UI with error: {ui_error}")
        except Exception as e:
            DEBUG_LOGGER.error(f"[INSPECT] ========== CRITICAL ERROR in _inspect_gguf_file ==========")
            DEBUG_LOGGER.error(f"[INSPECT] Error type: {type(e).__name__}")
            DEBUG_LOGGER.error(f"[INSPECT] Error message: {str(e)}")
            DEBUG_LOGGER.error(f"[INSPECT] Full traceback:", exc_info=True)
            import traceback
            DEBUG_LOGGER.error(f"[INSPECT] Traceback string:\n{traceback.format_exc()}")
            
            # Show error dialog (thread-safe via QTimer)
            try:
                self._show_inspect_error_dialog(e, f"GGUF file inspection: {file_path.name}")
            except Exception as dialog_error:
                DEBUG_LOGGER.error(f"[INSPECT] Failed to show error dialog: {dialog_error}", exc_info=True)
            
            # Also try to show error in UI
            try:
                error_msg = str(e)
                error_msg_escaped = json.dumps(error_msg)
                DEBUG_LOGGER.debug(f"[INSPECT] Attempting to display error in UI...")
                self._execute_js_safe(f"""
                    document.getElementById('inspect-output').innerHTML = '<span class="error">❌ Error inspecting GGUF file: ' + {error_msg_escaped} + '</span>';
                """)
                DEBUG_LOGGER.debug(f"[INSPECT] Error message displayed in UI")
            except Exception as ui_error:
                DEBUG_LOGGER.error(f"[INSPECT] CRITICAL: Failed to display error in UI: {ui_error}", exc_info=True)
    
    def _refresh_inspect(self):
        """Refresh inspection of current file"""
        if hasattr(self, '_inspect_file_path') and self._inspect_file_path:
            self._inspect_file()
        else:
            QMessageBox.warning(self, "No File", "Please load a file first.")
    
    def _select_profile(self, profile: str):
        if profile in self.profiles:
            self.current_profile = self.profiles[profile].copy()
    
    def _toggle_unsafe(self, enabled: bool):
        self.unsafe_enabled = enabled
        color = "#f87171" if enabled else "#34d399"
        text = "UNSAFE" if enabled else "SAFE"
        self._execute_js(f"""
            const badge = document.getElementById('safety-badge');
            badge.textContent = '{text}';
            badge.style.background = 'rgba(' + (parseInt('{color}'.slice(1, 3), 16)) + ', ' + (parseInt('{color}'.slice(3, 5), 16)) + ', ' + (parseInt('{color}'.slice(5, 7), 16)) + ', 0.2)';
            badge.style.border = '1px solid {color}';
        """)
    
    def _send_chat_message(self, text: str):
        """Send chat message ONLY when user explicitly sends it"""
        if not self.proc:
            self._append_terminal("[No process running]\n", "warning")
            return
        
        if not self.proc.stdin:
            self._append_terminal("[Process stdin not available]\n", "warning")
            return
        
        # Don't send if AI is still generating
        if self.waiting_for_ai:
            self._append_terminal("[Please wait for AI to finish responding]\n", "warning")
            return
        
        try:
            # Show user message FIRST
            self._append_terminal(f"You> {text}\n", "command")
            
            # Write message with newline and flush IMMEDIATELY
            message = text + "\n"
            self.proc.stdin.write(message)
            self.proc.stdin.flush()
            
            # Set waiting state - AI will respond
            import time
            DEBUG_LOGGER.info(f"[SEND] Sending message: '{text[:100]}', setting waiting_for_ai=True")
            self.waiting_for_ai = True
            self.last_output_time = time.time()
            self.last_ai_line_time = 0  # Reset - will be set when we see "AI>" line
            # Clear log cache when starting new cycle
            self._last_log_times.clear()
            DEBUG_LOGGER.debug(f"[SEND] State initialized: waiting_for_ai={self.waiting_for_ai}, last_output_time={self.last_output_time:.3f}")
            self._start_streaming_indicator()
            self._start_ai_timeout()
            self._reset_inactivity_timeout()
            
            DEBUG_LOGGER.debug(f"Sent chat message: {text}")
        except BrokenPipeError:
            self._append_terminal("[Process ended]\n", "error")
            self.proc = None
            self.waiting_for_ai = False
        except Exception as e:
            error_msg = f"Error sending message: {e}"
            DEBUG_LOGGER.error(error_msg, exc_info=True)
            self._append_terminal(f"[Error: {error_msg}]\n", "error")
            self.waiting_for_ai = False
    
    def _build_command(self) -> List[str]:
        """Build command to run - supports both 4DLLM and GGUF files"""
        if not self.run_path:
            self._show_error_dialog("No File Selected", "Please select a .4dllm or .gguf file to run.", "ERR-BUILD-CMD-NO-FILE-001")
            return []
        
        if self.is_gguf_file:
            # For GGUF files, use llama-cpp-python directly via a simple wrapper
            # We'll create a simple inline Python script that uses llama-cpp-python
            import tempfile
            import textwrap
            
            # Create a temporary Python script that runs the GGUF file
            script_content = textwrap.dedent(f"""
                import sys
                try:
                    from llama_cpp import Llama
                except ImportError:
                    print("ERROR: llama-cpp-python not installed. Please install it with: pip install llama-cpp-python", file=sys.stderr)
                    sys.exit(1)
                
                import os
                os.environ['PYTHONUNBUFFERED'] = '1'
                
                model_path = {repr(str(self.run_path))}
                n_ctx = {self.current_profile.get("n_ctx", 4096)}
                n_threads = {self.current_profile.get("threads", 4)}
                n_gpu_layers = {self.current_profile.get("gpu_layers", 0)}
                max_tokens = {self.current_profile.get("max_tokens", 256)}
                temperature = {self.current_profile.get("temp", 0.7)}
                
                print(f"[GGUF] Loading model: {{model_path}}", flush=True)
                try:
                    llm = Llama(
                        model_path=model_path,
                        n_ctx=n_ctx,
                        n_threads=n_threads,
                        n_gpu_layers=n_gpu_layers,
                        verbose=False
                    )
                    print(f"[GGUF] Model loaded successfully", flush=True)
                    print("\\n[GGUF] Chat ready. Type /exit to quit.\\n", flush=True)
                    
                    history = []
                    # Print initial "You> " prompt
                    print("You> ", end="", flush=True)
                    
                    while True:
                        try:
                            # Read user input (GUI already displays "You> " prefix when user sends message)
                            user_msg = sys.stdin.readline().strip()
                            if not user_msg:
                                continue
                            if user_msg.lower() == "/exit":
                                break
                            
                            # Format chat prompt
                            prompt_parts = []
                            for u, a in history:
                                prompt_parts.append(f"User: {{u}}\\nAssistant: {{a}}")
                            prompt_parts.append(f"User: {{user_msg}}\\nAssistant:")
                            prompt = "\\n".join(prompt_parts)
                            
                            # Generate response - print "AI> " prefix FIRST
                            print("AI> ", end="", flush=True)
                            try:
                                response = llm(
                                    prompt,
                                    max_tokens=max_tokens,
                                    temperature=temperature,
                                    stop=["User:", "\\nUser:", "\\n\\nUser:", "Assistant:"],
                                    echo=False
                                )
                                
                                # Extract text from response - llama-cpp-python returns Completion object or dict
                                text = ""
                                try:
                                    # Try dict-style access first (for dict responses)
                                    if response and isinstance(response, dict) and 'choices' in response:
                                        if len(response['choices']) > 0:
                                            choice = response['choices'][0]
                                            if isinstance(choice, dict) and 'text' in choice:
                                                text = str(choice['text']).strip()
                                    # Try attribute access (for Completion objects)
                                    elif response and hasattr(response, 'choices'):
                                        choices = response.choices
                                        if choices and len(choices) > 0:
                                            choice = choices[0]
                                            if hasattr(choice, 'text'):
                                                text = str(choice.text).strip()
                                            elif isinstance(choice, dict) and 'text' in choice:
                                                text = str(choice['text']).strip()
                                    # Try direct dict access with get (fallback)
                                    elif response:
                                        choices = response.get('choices', []) if isinstance(response, dict) else []
                                        if choices and len(choices) > 0:
                                            choice = choices[0]
                                            text = str(choice.get('text', '') if isinstance(choice, dict) else getattr(choice, 'text', '')).strip()
                                except Exception as extract_err:
                                    print(f"(Error extracting response: {{extract_err}})", file=sys.stderr, flush=True)
                                
                                # Print response text (will be on same line as "AI> ")
                                if text:
                                    print(text, flush=True)
                                else:
                                    print("(No response generated)", flush=True)
                                
                                # Add to history if we got a valid response
                                if text:
                                    history.append((user_msg, text))
                            except Exception as gen_err:
                                print(f"ERROR generating response: {{gen_err}}", file=sys.stderr, flush=True)
                                import traceback
                                traceback.print_exc(file=sys.stderr)
                                # Continue to next iteration but don't print "You> " yet
                                continue
                            
                            # Print "You> " prompt for next input (this signals AI finished to GUI)
                            print("You> ", end="", flush=True)
                                
                        except EOFError:
                            break
                        except KeyboardInterrupt:
                            break
                        except Exception as e:
                            print(f"ERROR: {{e}}", file=sys.stderr, flush=True)
                            import traceback
                            traceback.print_exc(file=sys.stderr)
                except Exception as e:
                    print(f"ERROR loading model: {{e}}", file=sys.stderr, flush=True)
                    import traceback
                    traceback.print_exc(file=sys.stderr)
                    sys.exit(1)
            """)
            
            # Write script to temp file
            temp_script = tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False)
            temp_script.write(script_content)
            temp_script.close()
            temp_script_path = Path(temp_script.name)
            
            cmd = [sys.executable, "-u", str(temp_script_path)]
            # Store temp script path for cleanup later
            self._gguf_temp_script = temp_script_path
            return cmd
        else:
            # For 4DLLM files, use the existing runner script
            runner_script = Path(__file__).parent / "4dllm_runner.py"
            cmd = [
                sys.executable,
                str(runner_script),
                "--file", str(self.run_path),
                "--backend", self.current_profile.get("backend", "llama_cpp"),
                "--n-ctx", str(self.current_profile.get("n_ctx", "4096")),
                "--threads", str(self.current_profile.get("threads", "4")),
                "--gpu-layers", str(self.current_profile.get("gpu_layers", "0")),
                "--max-tokens", str(self.current_profile.get("max_tokens", "256")),
                "--temp", str(self.current_profile.get("temp", "0.7")),
            ]
            if self.unsafe_enabled:
                cmd.append("--unsafe-modules")
            return cmd
    
    def _update_file_selection(self):
        if self.run_path:
            file_name_escaped = self.run_path.name.replace("'", "\\'").replace("\\", "\\\\")
            file_type = 'GGUF' if self.is_gguf_file else '4DLLM'
            file_type_escaped = file_type.replace("'", "\\'")
            update_js = f"""
                const el = document.getElementById('selected-file');
                el.innerHTML = '{file_name_escaped}<br><span style="font-size: 11px; color: #64748b;">({file_type_escaped} file)</span>';
            """
            self._execute_js(update_js)
    
    def _on_process_finished(self):
        """Called when process finishes"""
        self._stop_streaming_indicator()
        self._cancel_ai_timeout()
        self._cancel_inactivity_timeout()
        self.waiting_for_ai = False
        self.last_ai_line_time = 0
        self._append_terminal("\n[Process finished]\n", "info")
        # Clean up
        if self.proc:
            try:
                if self.proc.stdin:
                    self.proc.stdin.close()
            except:
                pass
        self.proc = None
        self.reader_thread = None
        
        # Clean up temporary GGUF script if it exists
        if hasattr(self, '_gguf_temp_script') and self._gguf_temp_script:
            try:
                if self._gguf_temp_script.exists():
                    self._gguf_temp_script.unlink()
                    DEBUG_LOGGER.info(f"Cleaned up temporary GGUF script: {self._gguf_temp_script}")
            except Exception as e:
                DEBUG_LOGGER.warning(f"Failed to clean up temporary script: {e}")
            self._gguf_temp_script = None
    
    def _on_page_loaded(self, success: bool):
        """Called when HTML page finishes loading"""
        if success:
            # Give WebChannel time to initialize
            QTimer.singleShot(200, self._verify_bridge)
    
    def _verify_bridge(self):
        """Verify WebChannel bridge is connected"""
        self._execute_js("""
            if (window.bridge && typeof window.bridge.sendChatMessage === 'function') {
                console.log('✓ Bridge connected successfully');
            } else {
                console.warn('⚠ Bridge not fully connected, retrying...');
                setTimeout(function() {
                    if (typeof qt !== 'undefined' && qt.webChannelTransport) {
                        new QWebChannel(qt.webChannelTransport, function(channel) {
                            window.bridge = channel.objects.bridge;
                            console.log('✓ Bridge connected on retry');
                        });
                    }
                }, 500);
            }
        """)


def exception_handler(exc_type, exc_value, exc_traceback):
    """Global exception handler to catch unhandled exceptions"""
    if issubclass(exc_type, KeyboardInterrupt):
        sys.__excepthook__(exc_type, exc_value, exc_traceback)
        return
    
    import traceback
    error_msg = f"Unhandled exception: {exc_type.__name__}: {exc_value}"
    traceback_str = ''.join(traceback.format_exception(exc_type, exc_value, exc_traceback))
    
    DEBUG_LOGGER.error("="*80)
    DEBUG_LOGGER.error("UNHANDLED EXCEPTION CAUGHT BY GLOBAL HANDLER")
    DEBUG_LOGGER.error(error_msg)
    DEBUG_LOGGER.error(traceback_str)
    DEBUG_LOGGER.error("="*80)
    
    # Try to show error popup if QApplication exists
    try:
        app = QApplication.instance()
        if app:
            msg_box = QMessageBox()
            msg_box.setIcon(QMessageBox.Icon.Critical)
            msg_box.setWindowTitle("Critical Error")
            msg_box.setText(f"<b>Unhandled Exception</b><br><br>{error_msg}")
            msg_box.setDetailedText(traceback_str)
            msg_box.setStandardButtons(QMessageBox.StandardButton.Ok)
            msg_box.exec()
    except:
        pass
    
    # Also print to stderr
    print(f"CRITICAL ERROR: {error_msg}", file=sys.stderr)
    print(traceback_str, file=sys.stderr)


def main():
    """Main entry point"""
    # Set global exception handler
    sys.excepthook = exception_handler
    
    if not HAS_PYQT6:
        print("ERROR: PyQt6 or PySide6 is required for this interface.")
        print("Install with: pip install PyQt6 PyQt6-WebEngine")
        return 1
    
    app = QApplication(sys.argv)
    
    # Set dark theme
    app.setStyle('Fusion')
    palette = QPalette()
    palette.setColor(QPalette.ColorRole.Window, QColor(15, 23, 42))
    palette.setColor(QPalette.ColorRole.WindowText, QColor(226, 232, 240))
    app.setPalette(palette)
    
    window = WorldClassStudio()
    window.show()
    
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())

