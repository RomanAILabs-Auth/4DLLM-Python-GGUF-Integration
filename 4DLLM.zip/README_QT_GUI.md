# 4DLLM Studio — World-Class PyQt6 GUI

A stunning, modern desktop application built with **PyQt6** and **HTML/CSS/JavaScript** for the ultimate visual experience.

## Features

✨ **World-Class Design**
- Modern glass-morphism UI with smooth gradients
- Beautiful animations and transitions
- Professional dark theme with cyan/blue accents
- Fully responsive and keyboard-friendly

🚀 **Performance**
- Lightning-fast terminal output streaming
- Non-blocking UI with background threading
- Optimized subprocess handling

💼 **Full Functionality**
- Run 4DLLM models with profile presets
- Inspect .4dllm files (TOC, sections, CRC)
- Manage embedded scripts
- Real-time chat interface
- Build packages
- Copy commands to clipboard

## Installation

### Required Dependencies

```bash
pip install PyQt6 PyQt6-WebEngine
```

Or with PySide6 (alternative):

```bash
pip install PySide6 PySide6-WebEngine
```

## Usage

Run the new GUI:

```bash
python3 4dllm_runner_gui_qt.py
```

Or use the original CustomTkinter GUI:

```bash
python3 4dllm_runner_gui.py
```

## Design Highlights

- **Gradient Headers**: Smooth blue gradients with cyan accents
- **Glass Morphism**: Backdrop blur effects and translucent panels
- **Smooth Animations**: Hover effects, transitions, and shimmer effects
- **Modern Typography**: Inter font family with perfect spacing
- **Color-Coded Terminal**: Syntax highlighting for different message types
- **Responsive Layout**: Three-panel design (sidebar, workspace, details)

## Keyboard Shortcuts

- `Ctrl+O`: Open .4dllm file
- `Ctrl+Enter`: Run model
- `Ctrl+L`: Clear terminal
- `Enter`: Send chat message
- `Shift+Enter`: New line in chat

## Architecture

- **Frontend**: HTML5 + CSS3 + JavaScript (embedded in PyQt6)
- **Backend**: Python (PyQt6/QWebChannel for communication)
- **Bridge**: QWebChannel for seamless Python ↔ JavaScript communication

## Notes

- The HTML/CSS/JS interface is embedded directly in the Python file
- All styling is self-contained and requires no external files
- The design is optimized for 1600x1000 resolution but scales beautifully
- WebChannel bridge enables real-time bidirectional communication

Enjoy the world-class experience! 🎨✨

