#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Copyright Daniel Harding - RomanAILabs
Credits: Built with assistance from OpenAI (GPT-5.2 Thinking)

4DLLM Runner GUI — Integrated Terminal & Module Manager

A graphical interface with integrated terminal for running 4DLLM files,
managing modules, and monitoring execution in real-time.
"""

from __future__ import annotations

import json
import os
import queue
import re
import select
import struct
import subprocess
import sys
import threading
import time
import argparse
import zlib
import ast
import shlex
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from datetime import datetime

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
try:
    import customtkinter as ctk
    HAS_CTK = True
except Exception:
    HAS_CTK = False

# Optional drag-drop support
try:
    import tkinterdnd2 as dnd2
    HAS_DND = True
except Exception:
    HAS_DND = False

# ---------------- Debug Logger ----------------
DEBUG_LOG_FILE = Path(__file__).parent / "4dllm_runner_debug.log"

def setup_debug_logger():
    """Setup debug logger for error tracking"""
    logger = logging.getLogger("4dllm_runner_gui")
    logger.setLevel(logging.DEBUG)
    
    # Clear old log file (keep last 1000 lines)
    if DEBUG_LOG_FILE.exists():
        try:
            with open(DEBUG_LOG_FILE, 'r') as f:
                lines = f.readlines()
            if len(lines) > 1000:
                with open(DEBUG_LOG_FILE, 'w') as f:
                    f.writelines(lines[-1000:])
        except Exception:
            pass
    
    # File handler
    fh = logging.FileHandler(DEBUG_LOG_FILE, mode='a', encoding='utf-8')
    fh.setLevel(logging.DEBUG)
    
    # Console handler (optional, for stderr)
    ch = logging.StreamHandler(sys.stderr)
    ch.setLevel(logging.WARNING)
    
    # Formatter
    formatter = logging.Formatter(
        '%(asctime)s [%(levelname)s] %(name)s: %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    fh.setFormatter(formatter)
    ch.setFormatter(formatter)
    
    logger.addHandler(fh)
    logger.addHandler(ch)
    
    return logger

DEBUG_LOGGER = setup_debug_logger()

# Import runner constants
import importlib.util

runner_path = Path(__file__).parent / "4dllm_runner.py"
runner_loaded = False

if runner_path.exists():
    try:
        spec = importlib.util.spec_from_file_location("runner_module", str(runner_path))
        if spec and spec.loader:
            runner_module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(runner_module)
            
            FOURDLLM_MAGIC = runner_module.FOURDLLM_MAGIC
            FOURDLLM_VERSION_EXPECTED = runner_module.FOURDLLM_VERSION_EXPECTED
            FOURDLLM_VERSION_LEGACY = getattr(runner_module, "FOURDLLM_VERSION_LEGACY", 1)
            FOURDLLM_HEADER_SIZE = runner_module.FOURDLLM_HEADER_SIZE
            TOC_MAGIC = runner_module.TOC_MAGIC
            TOC_VERSION = runner_module.TOC_VERSION
            SECTION_GGUF_DATA = runner_module.SECTION_GGUF_DATA
            SECTION_PYTHON_SCRIPT = runner_module.SECTION_PYTHON_SCRIPT
            SECTION_METADATA = runner_module.SECTION_METADATA
            SECTION_SCRIPT_CONFIG = runner_module.SECTION_SCRIPT_CONFIG
            SECTION_MANIFEST = getattr(runner_module, "SECTION_MANIFEST", 0x05)
            FLAG_COMPRESSED_ZLIB = runner_module.FLAG_COMPRESSED_ZLIB
            SECTION_HDR_STRUCT = runner_module.SECTION_HDR_STRUCT
            LEGACY_SECTION_HDR_STRUCT = getattr(
                runner_module,
                "LEGACY_SECTION_HDR_STRUCT",
                struct.Struct("<BB2xQI"),
            )
            TOC_HDR_STRUCT = runner_module.TOC_HDR_STRUCT
            TOC_ENTRY_STRUCT = runner_module.TOC_ENTRY_STRUCT
            read_exact = runner_module.read_exact
            crc32_bytes = runner_module.crc32_bytes
            safe_json_loads = runner_module.safe_json_loads
            find_toc_offset = runner_module.find_toc_offset
            read_and_validate_toc = runner_module.read_and_validate_toc
            read_section_small = runner_module.read_section_small
            decode_and_validate = runner_module.decode_and_validate
            runner_loaded = True
    except (ImportError, AttributeError, FileNotFoundError, TypeError, Exception):
        # Silently fall back to default implementations
        runner_loaded = False

if not runner_loaded:
    # Fallback constants and functions
    FOURDLLM_MAGIC = b"4DLL"
    FOURDLLM_VERSION_EXPECTED = 2
    FOURDLLM_HEADER_SIZE = 64
    TOC_MAGIC = b"TOC1"
    TOC_VERSION = 1
    SECTION_GGUF_DATA = 0x01
    SECTION_PYTHON_SCRIPT = 0x02
    SECTION_METADATA = 0x03
    SECTION_SCRIPT_CONFIG = 0x04
    SECTION_MANIFEST = 0x05
    FLAG_COMPRESSED_ZLIB = 0x01
    SECTION_HDR_STRUCT = struct.Struct("<BB2xQQII")
    LEGACY_SECTION_HDR_STRUCT = struct.Struct("<BB2xQI")
    FOURDLLM_VERSION_LEGACY = 1
    TOC_HDR_STRUCT = struct.Struct("<4sII")
    TOC_ENTRY_STRUCT = struct.Struct("<BB2xQQQII")
    
    def read_exact(f, n: int) -> bytes:
        b = f.read(n)
        if len(b) != n:
            raise EOFError(f"Expected {n} bytes, got {len(b)}")
        return b
    
    def crc32_bytes(b: bytes) -> int:
        return zlib.crc32(b) & 0xFFFFFFFF
    
    def safe_json_loads(b: bytes, default: Any) -> Any:
        try:
            return json.loads(b.decode("utf-8", errors="replace"))
        except Exception:
            return default
    
    def find_toc_offset(path: Path, scan_back_bytes: int = 4 * 1024 * 1024) -> int:
        size = path.stat().st_size
        start = max(0, size - scan_back_bytes)
        with open(path, "rb") as f:
            f.seek(start)
            chunk = f.read(size - start)
        idx = chunk.rfind(TOC_MAGIC)
        if idx < 0:
            raise ValueError("TOC not found (TOC1). File may not be a v2 4DLLM.")
        return start + idx
    
    def read_and_validate_toc(path: Path):
        @dataclass
        class TocEntry:
            section_type: int
            flags: int
            offset: int
            size_c: int
            size_u: int
            extra_sz: int
            crc32_u: int
        
        toc_offset = find_toc_offset(path)
        with open(path, "rb") as f:
            f.seek(toc_offset)
            hdr = read_exact(f, TOC_HDR_STRUCT.size)
            magic, toc_ver, count = TOC_HDR_STRUCT.unpack(hdr)
            if magic != TOC_MAGIC:
                raise ValueError("Bad TOC magic")
            if toc_ver != TOC_VERSION:
                raise ValueError(f"Unsupported TOC version: {toc_ver}")
            
            entries_bytes = read_exact(f, TOC_ENTRY_STRUCT.size * count)
            footer_crc = struct.unpack("<I", read_exact(f, 4))[0]
            
            computed = crc32_bytes(hdr + entries_bytes)
            if computed != footer_crc:
                raise ValueError(f"TOC CRC mismatch: expected {footer_crc:08x}, got {computed:08x}")
            
            entries: List[TocEntry] = []
            for i in range(count):
                chunk = entries_bytes[i * TOC_ENTRY_STRUCT.size:(i + 1) * TOC_ENTRY_STRUCT.size]
                stype, flags, off, size_c, size_u, extra_sz, crc_u = TOC_ENTRY_STRUCT.unpack(chunk)
                entries.append(TocEntry(stype, flags, off, size_c, size_u, extra_sz, crc_u))
            
            return entries, toc_offset
    
    def read_section_small(path: Path, entry) -> Dict[str, Any]:
        @dataclass
        class SectionSmall:
            entry: Any
            extra: Dict[str, Any]
            payload_c: bytes
        
        with open(path, "rb") as f:
            f.seek(entry.offset)
            hdr = read_exact(f, SECTION_HDR_STRUCT.size)
            stype, flags, size_c, size_u, extra_sz, crc_u = SECTION_HDR_STRUCT.unpack(hdr)
            
            extra_bytes = read_exact(f, extra_sz) if extra_sz else b"{}"
            extra = safe_json_loads(extra_bytes, default={})
            payload_c = read_exact(f, size_c) if size_c else b""
            return SectionSmall(entry=entry, extra=extra, payload_c=payload_c)
    
    def decode_and_validate(section) -> bytes:
        data = section.payload_c
        if section.entry.flags & FLAG_COMPRESSED_ZLIB:
            data = zlib.decompress(data)
        
        c = zlib.crc32(data) & 0xFFFFFFFF
        if c != section.entry.crc32_u:
            raise ValueError(
                f"CRC mismatch for section {section.entry.section_type:#x}: "
                f"expected {section.entry.crc32_u:08x}, got {c:08x}"
            )
        
        if len(data) != section.entry.size_u:
            raise ValueError(
                f"Size_u mismatch after decode: expected {section.entry.size_u}, got {len(data)}"
            )
        return data


# ---------------- Premium Studio (CustomTkinter) ----------------

def _safe_import_builder():
    try:
        bspec = importlib.util.spec_from_file_location("builder_module", str(Path(__file__).parent / "4dllm_builder_v2.0.py"))
        if bspec and bspec.loader:
            bm = importlib.util.module_from_spec(bspec)
            bspec.loader.exec_module(bm)
            return bm
    except Exception:
        return None
    return None


class PremiumStudio(ctk.CTk):
    """
    Optional modern UI wrapper; keeps classic UI intact.
    Safe defaults, minimal CPU use (buffered reads + queued updates).
    """

    def __init__(self):
        super().__init__()
        self.title("4DLLM Studio — RomanAILabs")
        self.geometry("1400x900")
        self.configure(fg_color="#0f141a")
        self.builder_mod = _safe_import_builder()
        self.gguf_path: Optional[Path] = None
        self.out_path: Optional[Path] = None
        self.run_path: Optional[Path] = None
        self.proc: Optional[subprocess.Popen] = None
        self.queue: "queue.Queue[Tuple[str,str]]" = queue.Queue()
        self.profiles: Dict[str, Dict[str, Any]] = {
            "Default": {"n_ctx": "4096", "threads": "4", "gpu_layers": "0", "max_tokens": "256", "temp": "0.7", "backend": "llama_cpp"},
            "High Performance": {"n_ctx": "8192", "threads": "8", "gpu_layers": "35", "max_tokens": "512", "temp": "0.8", "backend": "llama_cpp"},
            "Low Memory": {"n_ctx": "2048", "threads": "2", "gpu_layers": "0", "max_tokens": "128", "temp": "0.6", "backend": "llama_cli"},
        }
        self.current_profile: Dict[str, Any] = self.profiles["Default"].copy()
        self.file_info: Dict[str, Any] = {}
        self.script_sections: List[Any] = []
        self._setup_keyboard_shortcuts()
        self._build_ui()
        self.after(80, self._poll_queue)

    def _setup_keyboard_shortcuts(self):
        """Setup keyboard shortcuts"""
        self.bind("<Control-o>", lambda e: self._pick_run())
        self.bind("<Control-Return>", lambda e: self._run_action() if self.run_path else None)
        self.bind("<Control-l>", lambda e: self._clear_terminal())

    def _build_ui(self):
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")
        
        # Configure main window with navy theme
        self.configure(fg_color=COLORS["bg_primary"])
        
        # Main container with elegant spacing
        main_container = ctk.CTkFrame(self, fg_color=COLORS["bg_primary"], corner_radius=0)
        main_container.pack(fill="both", expand=True, padx=0, pady=0)
        
        # Top header bar with STUNNING gradient effect
        header = tk.Frame(main_container, bg=COLORS["bg_primary"], height=60)
        header.pack(fill="x", padx=0, pady=0)
        header.pack_propagate(False)
        
        # Add vibrant gradient overlay to header
        gradient_frame, gradient_canvas = self._create_gradient_frame(
            header, height=60,
            color1="#0a1628",  # Dark navy start
            color2="#1e3a5f",   # Bright blue end
            direction="horizontal"
        )
        gradient_frame.place(x=0, y=0, relwidth=1, relheight=1)
        
        # Glass overlay for shine
        glass_overlay = tk.Frame(header, bg=COLORS["bg_primary"], height=20)
        glass_overlay.place(x=0, y=0, relwidth=1, height=20)
        glass_canvas = tk.Canvas(glass_overlay, highlightthickness=0, borderwidth=0, bg=COLORS["bg_primary"])
        glass_canvas.pack(fill="both", expand=True)
        glass_canvas.create_rectangle(0, 0, 2000, 20, fill="#ffffff", stipple="gray50", tags="glass")
        
        title_label = ctk.CTkLabel(
            header, 
            text="4DLLM Studio", 
            font=ctk.CTkFont(size=24, weight="bold"),
            text_color="#22d3ee",  # Bright cyan
            bg_color="transparent"
        )
        title_label.pack(side="left", padx=20, pady=15)
        
        subtitle = ctk.CTkLabel(
            header,
            text="RomanAILabs",
            font=ctk.CTkFont(size=11),
            text_color="#94a3b8",
            bg_color="transparent"
        )
        subtitle.pack(side="left", padx=(0, 20), pady=15)
        
        # Main content area with paned layout
        content_paned = ctk.CTkFrame(main_container, fg_color=COLORS["bg_primary"])
        content_paned.pack(fill="both", expand=True, padx=12, pady=12)
        
        # Left sidebar - glass-morphism navy panel with gradient
        sidebar = ctk.CTkFrame(content_paned, width=260, corner_radius=20, 
                               fg_color=COLORS["glass_dark"], border_width=2,
                               border_color=COLORS["glass_border"])
        sidebar.pack(side="left", fill="y", padx=(0, 12))
        sidebar.pack_propagate(False)
        
        # Add subtle vertical gradient overlay
        sidebar_gradient, _ = self._create_gradient_frame(
            sidebar,
            color1=COLORS["gradient_start"],
            color2=COLORS["gradient_mid"],
            direction="vertical"
        )
        sidebar_gradient.place(x=0, y=0, relwidth=1, relheight=1)
        
        # Sidebar header
        sidebar_header = ctk.CTkFrame(sidebar, fg_color="transparent", height=50)
        sidebar_header.pack(fill="x", padx=16, pady=16)
        sidebar_header.pack_propagate(False)
        
        # Recent section with custom styling
        recent_section = ctk.CTkFrame(sidebar, fg_color="transparent")
        recent_section.pack(fill="x", padx=16, pady=(0, 12))
        
        section_label = ctk.CTkLabel(
            recent_section, 
            text="Recent Files", 
            font=ctk.CTkFont(size=13, weight="bold"),
            text_color=COLORS["fg_primary"]
        )
        section_label.pack(anchor="w", pady=(0, 8))
        
        # Custom styled listbox with glass effect
        listbox_frame = ctk.CTkFrame(recent_section, fg_color=COLORS["glass_medium"], 
                                     corner_radius=12, border_width=1, 
                                     border_color=COLORS["glass_border"])
        listbox_frame.pack(fill="x", pady=(0, 0))
        
        self.recent_listbox = tk.Listbox(
            listbox_frame, 
            height=4, 
            bg=COLORS["bg_tertiary"], 
            fg=COLORS["fg_primary"], 
            selectbackground=COLORS["accent_blue"],
            selectforeground=COLORS["fg_primary"],
            font=("Consolas", 10),
            relief="flat",
            borderwidth=0,
            highlightthickness=0,
            activestyle="none"
        )
        self.recent_listbox.pack(fill="both", expand=True, padx=8, pady=8)
        self.recent_listbox.bind("<Double-Button-1>", lambda e: self._load_recent_file())
        
        # Files section with custom buttons
        files_section = ctk.CTkFrame(sidebar, fg_color="transparent")
        files_section.pack(fill="x", padx=16, pady=(0, 12))
        
        files_label = ctk.CTkLabel(
            files_section, 
            text="Files", 
            font=ctk.CTkFont(size=13, weight="bold"),
            text_color=COLORS["fg_primary"]
        )
        files_label.pack(anchor="w", pady=(0, 8))
        
        # Custom styled buttons
        self._create_custom_button(
            files_section, 
            "📂 Open .4dllm", 
            self._pick_run,
            "action"
        ).pack(fill="x", pady=(0, 8))
        
        self._create_custom_button(
            files_section, 
            "📂 Open .gguf", 
            self._pick_gguf,
            "secondary"
        ).pack(fill="x", pady=(0, 0))
        
        # Profiles section
        profiles_section = ctk.CTkFrame(sidebar, fg_color="transparent")
        profiles_section.pack(fill="x", padx=16, pady=(0, 12))
        
        profiles_label = ctk.CTkLabel(
            profiles_section, 
            text="Profiles", 
            font=ctk.CTkFont(size=13, weight="bold"),
            text_color=COLORS["fg_primary"]
        )
        profiles_label.pack(anchor="w", pady=(0, 8))
        
        # Custom styled option menu
        self.profile_var = tk.StringVar(value="Default")
        profile_menu = ctk.CTkOptionMenu(
            profiles_section, 
            variable=self.profile_var, 
            values=list(self.profiles.keys()),
            command=self._load_profile, 
            width=228,
            fg_color=COLORS["bg_tertiary"],
            button_color=COLORS["accent_blue"],
            button_hover_color=COLORS["accent_blue_dark"],
            text_color=COLORS["fg_primary"],
            dropdown_fg_color=COLORS["bg_secondary"],
            dropdown_text_color=COLORS["fg_primary"],
            dropdown_hover_color=COLORS["bg_tertiary"],
            corner_radius=8,
            font=ctk.CTkFont(size=11)
        )
        profile_menu.pack(fill="x", pady=(0, 0))
        
        # Safety badge with glass-morphism styling
        badge_frame = ctk.CTkFrame(sidebar, fg_color="transparent")
        badge_frame.pack(fill="x", padx=16, pady=(12, 16))
        
        self.badge = ctk.CTkLabel(
            badge_frame, 
            text="SAFE", 
            fg_color=COLORS["status_safe"], 
            text_color=COLORS["fg_primary"], 
            corner_radius=12,
            font=ctk.CTkFont(size=12, weight="bold"),
            height=40
        )
        self.badge.pack(fill="x", pady=0)

        # Center workspace with glass-morphism tabs and gradient
        center_frame = ctk.CTkFrame(content_paned, fg_color=COLORS["glass_dark"], 
                                    corner_radius=20, border_width=2, 
                                    border_color=COLORS["glass_border"])
        center_frame.pack(side="left", fill="both", expand=True, padx=(0, 12))
        
        # Add gradient overlay to center frame
        center_gradient, _ = self._create_gradient_frame(
            center_frame,
            color1=COLORS["gradient_start"],
            color2=COLORS["gradient_mid"],
            direction="vertical"
        )
        center_gradient.place(x=0, y=0, relwidth=1, relheight=1)
        
        tabs = ctk.CTkTabview(
            center_frame, 
            fg_color=COLORS["glass_dark"], 
            segmented_button_selected_color="#2563eb",  # Bright blue for selected
            segmented_button_selected_hover_color="#3b82f6",  # Lighter blue on hover
            segmented_button_unselected_color=COLORS["glass_medium"],
            segmented_button_unselected_hover_color=COLORS["glass_light"],
            text_color=COLORS["fg_primary"],
            corner_radius=14
        )
        tabs.pack(fill="both", expand=True, padx=12, pady=12)
        
        self._build_tab_build(tabs.add("Build"))
        self._build_tab_run(tabs.add("Run"))
        self._build_tab_inspect(tabs.add("Inspect"))
        self._build_tab_scripts(tabs.add("Scripts"))
        self._build_tab_settings(tabs.add("Settings"))

        # Right Details panel - glass-morphism navy panel with gradient
        details_panel = ctk.CTkFrame(content_paned, width=300, corner_radius=20,
                                    fg_color=COLORS["glass_dark"], border_width=2,
                                    border_color=COLORS["glass_border"])
        details_panel.pack(side="left", fill="y", padx=(0, 0))
        details_panel.pack_propagate(False)
        
        # Add gradient overlay to details panel
        details_gradient, _ = self._create_gradient_frame(
            details_panel,
            color1=COLORS["gradient_start"],
            color2=COLORS["gradient_mid"],
            direction="vertical"
        )
        details_gradient.place(x=0, y=0, relwidth=1, relheight=1)
        
        # Details header with subtle gradient
        details_header_frame = tk.Frame(details_panel, bg=COLORS["bg_primary"], height=55)
        details_header_frame.pack(fill="x", padx=16, pady=(16, 8))
        details_header_frame.pack_propagate(False)
        
        # Subtle blue gradient bar
        details_gradient_bar = self.GradientBar(details_header_frame, height=55)
        details_gradient_bar.pack(fill="both", expand=True)
        
        details_header = ctk.CTkLabel(
            details_header_frame,
            text="Details",
            font=ctk.CTkFont(size=16, weight="bold"),
            text_color=COLORS["accent_cyan"],  # Cyan accent text
            height=55,
            bg_color="transparent"
        )
        details_header.pack(fill="x", padx=16, pady=(16, 8))
        
        self.detail_box = ctk.CTkTextbox(
            details_panel, 
            fg_color=COLORS["glass_medium"], 
            text_color=COLORS["fg_primary"],
            font=ctk.CTkFont(family="Consolas", size=10),
            corner_radius=14,
            border_width=1,
            border_color=COLORS["glass_border"]
        )
        self.detail_box.pack(fill="both", expand=True, padx=16, pady=(0, 16))
        
        # Setup drag-drop if available
        if HAS_DND:
            try:
                dnd2.TkinterDnD(self)
                self.drop_target_register(dnd2.DND_FILES)
                self.dnd_bind('<<Drop>>', self._on_drop)
            except Exception:
                pass
    
    class GradientBar(tk.Frame):
        """Reusable gradient bar widget with subtle blue gradient and cyan accent"""
        def __init__(self, parent, height=50, accent_color="#06b6d4"):
            super().__init__(parent, bg=COLORS["bg_primary"], height=height)
            self.height = height
            self.accent_color = accent_color
            self.canvas = tk.Canvas(self, highlightthickness=0, borderwidth=0, 
                                   bg=COLORS["bg_primary"], height=height)
            self.canvas.pack(fill="both", expand=True)
            self.canvas.bind("<Configure>", lambda e: self._draw_gradient())
            self._draw_gradient()
        
        def _draw_gradient(self):
            """Draw subtle blue gradient with cyan accent underline"""
            try:
                w = self.canvas.winfo_width()
                h = self.canvas.winfo_height()
                if w <= 1 or h <= 1:
                    return
                
                self.canvas.delete("all")
                
                # Subtle blue gradient: dark navy -> slightly lighter navy
                color1 = "#0f172a"  # Dark navy
                color2 = "#1e293b"  # Slightly lighter navy
                
                r1, g1, b1 = int(color1[1:3], 16), int(color1[3:5], 16), int(color1[5:7], 16)
                r2, g2, b2 = int(color2[1:3], 16), int(color2[3:5], 16), int(color2[5:7], 16)
                
                # Draw horizontal gradient with many thin rectangles
                steps = max(w, 150)
                for i in range(steps):
                    x = int(i * w / steps)
                    ratio = i / steps
                    # Smooth easing
                    eased = ratio * ratio * (3 - 2 * ratio)
                    r = int(r1 + (r2 - r1) * eased)
                    g = int(g1 + (g2 - g1) * eased)
                    b = int(b1 + (b2 - b1) * eased)
                    color = f"#{r:02x}{g:02x}{b:02x}"
                    next_x = int((i + 1) * w / steps) if i < steps - 1 else w
                    self.canvas.create_rectangle(x, 0, next_x, h, fill=color, outline=color, tags="gradient")
                
                # Thin cyan accent underline (2px at bottom)
                self.canvas.create_rectangle(0, h-2, w, h, fill=self.accent_color, 
                                            outline=self.accent_color, tags="accent")
            except Exception as e:
                DEBUG_LOGGER.error(f"GradientBar draw error: {e}")
    
    def _create_gradient_frame(self, parent, width=None, height=None, 
                               color1=None, color2=None, direction="horizontal"):
        """Create a gradient frame for background overlays (kept for compatibility)"""
        frame = tk.Frame(parent, bg=COLORS["bg_primary"], highlightthickness=0, borderwidth=0)
        if width:
            frame.configure(width=width)
        if height:
            frame.configure(height=height)
        
        canvas = tk.Canvas(frame, highlightthickness=0, borderwidth=0, bg=COLORS["bg_primary"])
        canvas.pack(fill="both", expand=True)
        
        def draw_gradient():
            try:
                w = canvas.winfo_width()
                h = canvas.winfo_height()
                if w <= 1 or h <= 1:
                    return
                
                canvas.delete("all")
                r1, g1, b1 = int(color1[1:3], 16), int(color1[3:5], 16), int(color1[5:7], 16)
                r2, g2, b2 = int(color2[1:3], 16), int(color2[3:5], 16), int(color2[5:7], 16)
                
                if direction == "horizontal":
                    steps = max(w, 150)
                    for i in range(steps):
                        x = int(i * w / steps)
                        ratio = i / steps
                        eased = ratio * ratio * (3 - 2 * ratio)
                        r = int(r1 + (r2 - r1) * eased)
                        g = int(g1 + (g2 - g1) * eased)
                        b = int(b1 + (b2 - b1) * eased)
                        color = f"#{r:02x}{g:02x}{b:02x}"
                        next_x = int((i + 1) * w / steps) if i < steps - 1 else w
                        canvas.create_rectangle(x, 0, next_x, h, fill=color, outline=color, tags="gradient")
                else:  # vertical
                    steps = max(h, 150)
                    for i in range(steps):
                        y = int(i * h / steps)
                        ratio = i / steps
                        eased = ratio * ratio * (3 - 2 * ratio)
                        r = int(r1 + (r2 - r1) * eased)
                        g = int(g1 + (g2 - g1) * eased)
                        b = int(b1 + (b2 - b1) * eased)
                        color = f"#{r:02x}{g:02x}{b:02x}"
                        next_y = int((i + 1) * h / steps) if i < steps - 1 else h
                        canvas.create_rectangle(0, y, w, next_y, fill=color, outline=color, tags="gradient")
            except Exception as e:
                DEBUG_LOGGER.error(f"Gradient frame draw error: {e}")
        
        canvas.bind("<Configure>", lambda e: draw_gradient())
        frame.update_idletasks()
        draw_gradient()
        
        return frame, canvas
    
    def _create_custom_button(self, parent, text, command, button_type="primary"):
        """Create a stunning custom styled button with gradient effects"""
        # Define button styles with gradient-ready colors
        button_styles = {
            "primary": {
                "fg_color": COLORS["btn_primary"],
                "hover_color": COLORS["btn_primary_hover"],
                "text_color": COLORS["fg_primary"],
                "border_color": COLORS["border_light"],
                "gradient_start": COLORS["gradient_start"],
                "gradient_end": COLORS["gradient_mid"],
            },
            "secondary": {
                "fg_color": COLORS["btn_secondary"],
                "hover_color": COLORS["btn_secondary_hover"],
                "text_color": COLORS["fg_primary"],
                "border_color": COLORS["border_glow"],
                "gradient_start": COLORS["gradient_mid"],
                "gradient_end": COLORS["gradient_end"],
            },
            "accent": {
                "fg_color": COLORS["btn_accent"],
                "hover_color": COLORS["btn_accent_hover"],
                "text_color": COLORS["accent_cyan"],
                "border_color": COLORS["glass_border"],
                "gradient_start": COLORS["gradient_start"],
                "gradient_end": COLORS["gradient_mid"],
            },
            "action": {
                "fg_color": COLORS["btn_action"],
                "hover_color": COLORS["btn_action_hover"],
                "text_color": COLORS["fg_primary"],
                "border_color": COLORS["border_glow"],
                "gradient_start": COLORS["gradient_blue_start"],
                "gradient_end": COLORS["gradient_blue_end"],
            },
            "danger": {
                "fg_color": COLORS["btn_danger"],
                "hover_color": COLORS["btn_danger_hover"],
                "text_color": COLORS["fg_primary"],
                "border_color": COLORS["border_light"],
                "gradient_start": COLORS["gradient_mid"],
                "gradient_end": COLORS["gradient_end"],
            },
        }
        
        style = button_styles.get(button_type, button_styles["primary"])
        
        # Use gradient hover color for stunning effect
        btn = ctk.CTkButton(
            parent,
            text=text,
            command=command,
            fg_color=style["fg_color"],
            hover_color=style["hover_color"],
            text_color=style["text_color"],
            corner_radius=14,  # Slightly more rounded for elegance
            height=46,  # Slightly taller
            font=ctk.CTkFont(size=12, weight="bold"),
            border_width=2,  # Thicker border for depth
            border_color=style["border_color"],
        )
        return btn

    # ---- Build ----
    def _build_tab_build(self, tab: ctk.CTkFrame):
        frm = ctk.CTkFrame(tab, fg_color=COLORS["glass_medium"], corner_radius=18)
        frm.pack(fill="both", expand=True, padx=16, pady=16)
        
        # Add gradient overlay
        build_gradient, _ = self._create_gradient_frame(
            frm,
            color1=COLORS["gradient_mid"],
            color2=COLORS["gradient_end"],
            direction="vertical"
        )
        build_gradient.place(x=0, y=0, relwidth=1, relheight=1)
        
        # Header with subtle gradient
        header_frame = tk.Frame(frm, bg=COLORS["bg_primary"], height=60)
        header_frame.pack(anchor="w", fill="x", padx=20, pady=(20, 16))
        header_frame.pack_propagate(False)
        
        # Subtle blue gradient bar
        gradient_bar = self.GradientBar(header_frame, height=60)
        gradient_bar.pack(fill="both", expand=True)
        
        header = ctk.CTkLabel(
            header_frame, 
            text="Build 4DLLM Package", 
            font=ctk.CTkFont(size=20, weight="bold"),
            text_color=COLORS["accent_cyan"],  # Cyan accent text
            bg_color="transparent"
        )
        header.pack(anchor="w", padx=20, pady=(20, 16))
        
        # GGUF selection
        gguf_frame = ctk.CTkFrame(frm, fg_color="transparent")
        gguf_frame.pack(fill="x", padx=20, pady=(0, 12))
        
        ctk.CTkLabel(
            gguf_frame, 
            text="GGUF Model", 
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color=COLORS["fg_primary"]
        ).pack(anchor="w", pady=(0, 8))
        
        self.gguf_label = ctk.CTkLabel(
            gguf_frame, 
            text="No GGUF selected", 
            text_color=COLORS["fg_muted"],
            font=ctk.CTkFont(size=11)
        )
        self.gguf_label.pack(anchor="w", pady=(0, 8))
        
        self._create_custom_button(
            gguf_frame, 
            "📂 Select GGUF File", 
            self._pick_gguf,
            "action"
        ).pack(fill="x", pady=(0, 0))
        
        # Output path
        output_frame = ctk.CTkFrame(frm, fg_color="transparent")
        output_frame.pack(fill="x", padx=20, pady=(0, 12))
        
        ctk.CTkLabel(
            output_frame, 
            text="Output Path", 
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color=COLORS["fg_primary"]
        ).pack(anchor="w", pady=(0, 8))
        
        self.out_entry = ctk.CTkEntry(
            output_frame, 
            placeholder_text="Output .4dllm path (optional)",
            fg_color=COLORS["bg_secondary"],
            text_color=COLORS["fg_primary"],
            border_color=COLORS["border"],
            corner_radius=10,
            height=40,
            font=ctk.CTkFont(size=11)
        )
        self.out_entry.pack(fill="x", pady=(0, 0))
        
        # Build button
        button_frame = ctk.CTkFrame(frm, fg_color="transparent")
        button_frame.pack(fill="x", padx=20, pady=(12, 0))
        
        build_btn = self._create_custom_button(
            button_frame, 
            "🔨 Build Package", 
            self._build_action,
            "action"
        )
        build_btn.pack(side="right", padx=(0, 0))
        
        # Status
        self.build_status = ctk.CTkLabel(
            frm, 
            text="Ready", 
            text_color=COLORS["fg_muted"],
            font=ctk.CTkFont(size=11)
        )
        self.build_status.pack(anchor="w", padx=20, pady=(12, 20))

    # ---- Run ----
    def _build_tab_run(self, tab: ctk.CTkFrame):
        frm = ctk.CTkFrame(tab, fg_color=COLORS["glass_medium"], corner_radius=18)
        frm.pack(fill="both", expand=True, padx=16, pady=16)
        
        # Header
        header = ctk.CTkLabel(
            frm, 
            text="Run 4DLLM Model", 
            font=ctk.CTkFont(size=20, weight="bold"),
            text_color=COLORS["accent_cyan"]
        )
        header.pack(anchor="w", padx=20, pady=(20, 16))
        
        # Top controls with elegant layout
        top_frame = ctk.CTkFrame(frm, fg_color="transparent")
        top_frame.pack(fill="x", padx=20, pady=(0, 12))
        
        # File info
        file_info_frame = ctk.CTkFrame(top_frame, fg_color=COLORS["bg_secondary"], 
                                       corner_radius=12, border_width=1, border_color=COLORS["border"])
        file_info_frame.pack(side="left", fill="x", expand=True, padx=(0, 12))
        
        self.run_label = ctk.CTkLabel(
            file_info_frame, 
            text="No .4dllm selected", 
            text_color=COLORS["fg_muted"],
            font=ctk.CTkFont(size=12),
            anchor="w",
            height=50
        )
        self.run_label.pack(fill="x", padx=16, pady=0)
        
        # Control buttons
        btn_frame = ctk.CTkFrame(top_frame, fg_color="transparent")
        btn_frame.pack(side="right")
        
        self._create_custom_button(
            btn_frame, 
            "📂 Select", 
            self._pick_run,
            "secondary"
        ).pack(side="left", padx=(0, 8))
        
        self._create_custom_button(
            btn_frame, 
            "▶ Run", 
            self._run_action,
            "action"
        ).pack(side="left", padx=(0, 8))
        
        self._create_custom_button(
            btn_frame, 
            "■ Stop", 
            self._stop_action,
            "danger"
        ).pack(side="left", padx=(0, 8))
        
        self._create_custom_button(
            btn_frame, 
            "📋 Copy Cmd", 
            self._copy_command,
            "accent"
        ).pack(side="left", padx=(0, 0))
        
        # Safety warning with glass-morphism styling
        safety_frame = ctk.CTkFrame(frm, fg_color=COLORS["glass_medium"], 
                                    corner_radius=14, border_width=2, 
                                    border_color=COLORS["status_warning"])
        safety_frame.pack(fill="x", padx=20, pady=(0, 12))
        
        self.safety_warning = ctk.CTkLabel(
            safety_frame, 
            text="", 
            text_color=COLORS["fg_accent"], 
            font=ctk.CTkFont(size=11, weight="bold"),
            wraplength=900,
            justify="left",
            height=50
        )
        self.safety_warning.pack(fill="x", padx=16, pady=12)
        
        # Unsafe toggle with elegant styling
        unsafe_frame = ctk.CTkFrame(frm, fg_color="transparent")
        unsafe_frame.pack(fill="x", padx=20, pady=(0, 12))
        
        # Default to True since most 4DLLM files need unsafe modules
        self.unsafe_var = tk.BooleanVar(value=True)
        self.unsafe_check = ctk.CTkCheckBox(
            unsafe_frame, 
            text="⚠️ Allow Unsafe Modules (risky imports/calls detected)", 
            variable=self.unsafe_var, 
            command=self._toggle_safe,
            text_color=COLORS["fg_accent"],
            font=ctk.CTkFont(size=11, weight="bold"),
            fg_color=COLORS["status_warning"],
            hover_color=COLORS["status_unsafe"],
            checkmark_color=COLORS["fg_primary"],
            border_width=1,
            border_color=COLORS["glass_border"]
        )
        self.unsafe_check.pack(side="left")
        # Update badge to match default
        self._toggle_safe()
        
        # Terminal with glass-morphism navy styling and gradient
        term_frame = ctk.CTkFrame(frm, fg_color=COLORS["terminal_bg"], 
                                 corner_radius=18, border_width=2, 
                                 border_color=COLORS["glass_border"])
        term_frame.pack(fill="both", expand=True, padx=20, pady=(0, 20))
        
        # Add gradient overlay to terminal frame
        term_gradient, _ = self._create_gradient_frame(
            term_frame,
            color1=COLORS["terminal_bg"],
            color2=COLORS["gradient_start"],
            direction="vertical"
        )
        term_gradient.place(x=0, y=0, relwidth=1, relheight=1)
        
        # Terminal header with subtle gradient
        term_header = tk.Frame(term_frame, bg=COLORS["bg_primary"], height=45)
        term_header.pack(fill="x", padx=16, pady=(16, 0))
        term_header.pack_propagate(False)
        
        # Subtle blue gradient bar
        term_gradient_bar = self.GradientBar(term_header, height=45)
        term_gradient_bar.pack(fill="both", expand=True)
        
        header_label = ctk.CTkLabel(
            term_header,
            text="Terminal Output",
            font=ctk.CTkFont(size=13, weight="bold"),
            text_color=COLORS["accent_cyan"],  # Cyan accent text
            bg_color="transparent"
        )
        header_label.pack(side="left", padx=12, pady=12)
        
        # Terminal textbox (read-only output)
        self.term = ctk.CTkTextbox(
            term_frame, 
            fg_color=COLORS["terminal_bg"], 
            text_color=COLORS["terminal_fg"],
            font=ctk.CTkFont(family="Consolas", size=11),
            corner_radius=12,
            border_width=0
        )
        self.term.pack(fill="both", expand=True, padx=16, pady=(8, 12))
        
        # Separate chat input box (3 lines, scrollable) with gradient
        chat_input_frame = ctk.CTkFrame(term_frame, fg_color=COLORS["glass_medium"], 
                                       corner_radius=12, border_width=1,
                                       border_color=COLORS["glass_border"])
        chat_input_frame.pack(fill="x", padx=16, pady=(0, 16))
        
        # Chat input gradient overlay
        chat_gradient, _ = self._create_gradient_frame(
            chat_input_frame,
            color1=COLORS["gradient_mid"],
            color2=COLORS["gradient_end"],
            direction="horizontal"
        )
        chat_gradient.place(x=0, y=0, relwidth=1, relheight=1)
        
        chat_label = ctk.CTkLabel(
            chat_input_frame,
            text="Chat Input:",
            font=ctk.CTkFont(size=10, weight="bold"),
            text_color=COLORS["accent_cyan"],
            anchor="w",
            bg_color="transparent"
        )
        chat_label.pack(anchor="w", padx=12, pady=(8, 4))
        
        # Chat input textbox (3 lines, scrollable)
        self.chat_input = ctk.CTkTextbox(
            chat_input_frame,
            height=60,  # ~3 lines
            fg_color=COLORS["bg_secondary"],
            text_color=COLORS["fg_primary"],
            font=ctk.CTkFont(family="Consolas", size=11),
            corner_radius=8,
            border_width=1,
            border_color=COLORS["border_light"],
            wrap="word"
        )
        self.chat_input.pack(fill="x", padx=12, pady=(0, 8))
        # Enter sends message, Shift+Enter adds newline
        self.chat_input.bind("<Return>", self._on_chat_enter)
        self.chat_input.bind("<Shift-Return>", self._on_chat_shift_enter)
        
        # Chat send button
        chat_btn_frame = ctk.CTkFrame(chat_input_frame, fg_color="transparent")
        chat_btn_frame.pack(fill="x", padx=12, pady=(0, 8))
        
        self._create_custom_button(
            chat_btn_frame,
            "📤 Send",
            self._send_chat_message,
            "action"
        ).pack(side="right", padx=(8, 0))
        
        self._create_custom_button(
            chat_btn_frame,
            "🗑️ Clear",
            self._clear_chat_input,
            "secondary"
        ).pack(side="right", padx=(0, 0))
        
        # Add subtle watermark
        self.term.insert("end", "4DLLM Runner Terminal\n", "info")
        self.term.insert("end", "Ready to run 4DLLM models.\n", "info")
        self.term.insert("end", "Select a .4dllm file and click 'Run' to begin.\n\n", "output")
        self.term.insert("end", "\n\n\n")
        self.term.insert("end", "RomanAILabs", "watermark")
        # Note: CTkTextbox doesn't support font in tag_config, only foreground
        self.term.tag_config("watermark", foreground=COLORS["fg_muted"])
        self.term.tag_config("info", foreground=COLORS["terminal_cyan"])
        self.term.tag_config("output", foreground=COLORS["terminal_fg"])
        self.term.tag_config("command", foreground=COLORS["terminal_blue"])
        self.term.tag_config("success", foreground=COLORS["terminal_green"])
        self.term.tag_config("warning", foreground=COLORS["terminal_yellow"])
        self.term.tag_config("error", foreground=COLORS["terminal_red"])
        self.term.configure(state="disabled")

    # ---- Inspect ----
    def _build_tab_inspect(self, tab: ctk.CTkFrame):
        frm = ctk.CTkFrame(tab, fg_color=COLORS["glass_medium"], corner_radius=18)
        frm.pack(fill="both", expand=True, padx=16, pady=16)
        
        # Add gradient overlay
        inspect_gradient, _ = self._create_gradient_frame(
            frm,
            color1=COLORS["gradient_mid"],
            color2=COLORS["gradient_end"],
            direction="vertical"
        )
        inspect_gradient.place(x=0, y=0, relwidth=1, relheight=1)
        
        # Header with subtle gradient
        header_frame = tk.Frame(frm, bg=COLORS["bg_primary"], height=60)
        header_frame.pack(anchor="w", fill="x", padx=20, pady=(20, 16))
        header_frame.pack_propagate(False)
        
        # Subtle blue gradient bar
        gradient_bar = self.GradientBar(header_frame, height=60)
        gradient_bar.pack(fill="both", expand=True)
        
        header = ctk.CTkLabel(
            header_frame, 
            text="Inspect 4DLLM File", 
            font=ctk.CTkFont(size=20, weight="bold"),
            text_color=COLORS["accent_cyan"],  # Cyan accent text
            bg_color="transparent"
        )
        header.pack(anchor="w", padx=20, pady=(20, 16))
        
        # Controls
        top_frame = ctk.CTkFrame(frm, fg_color="transparent")
        top_frame.pack(fill="x", padx=20, pady=(0, 12))
        
        self._create_custom_button(
            top_frame, 
            "📂 Load .4dllm", 
            self._pick_inspect,
            "action"
        ).pack(side="left", padx=(0, 12))
        
        self._create_custom_button(
            top_frame, 
            "🔄 Refresh", 
            self._refresh_inspect,
            "secondary"
        ).pack(side="left", padx=(0, 0))
        
        # Inspect content with elegant styling
        self.inspect_box = ctk.CTkTextbox(
            frm, 
            fg_color=COLORS["terminal_bg"], 
            text_color=COLORS["fg_primary"],
            font=ctk.CTkFont(family="Consolas", size=10),
            corner_radius=16,
            border_width=1,
            border_color=COLORS["border"]
        )
        self.inspect_box.pack(fill="both", expand=True, padx=20, pady=(0, 20))
        self.inspect_box.insert("end", "Load a .4dllm file to inspect its structure.\n")
        self.inspect_box.configure(state="disabled")

    # ---- File pickers ----
    def _pick_gguf(self):
        fp = filedialog.askopenfilename(filetypes=[("GGUF", "*.gguf"), ("All", "*.*")])
        if not fp:
            return
        self.gguf_path = Path(fp)
        self.gguf_label.configure(text=self.gguf_path.name)
        self.detail_box.insert("end", f"GGUF: {fp}\n")

    def _pick_run(self):
        fp = filedialog.askopenfilename(filetypes=[("4DLLM", "*.4dllm"), ("All", "*.*")])
        if not fp:
            return
        self.run_path = Path(fp)
        self.run_label.configure(text=self.run_path.name)
        
        # Add to recent files
        if str(self.run_path) not in self.recent_listbox.get(0, tk.END):
            self.recent_listbox.insert(0, str(self.run_path))
            if self.recent_listbox.size() > 10:
                self.recent_listbox.delete(10, tk.END)
        
        # Load file info and analyze safety in background to prevent freeze
        def load_file_async():
            try:
                DEBUG_LOGGER.info(f"Loading file: {self.run_path}")
                self.file_info = read_4dllm_info(self.run_path)
                warnings, is_risky = self._analyze_safety(self.run_path)
                
                # Update UI in main thread
                self.after(0, lambda: self._update_file_info_ui(warnings, is_risky))
            except Exception as e:
                DEBUG_LOGGER.error(f"Error loading file: {e}", exc_info=True)
                self.after(0, lambda: messagebox.showerror("Error", f"Failed to load file:\n{e}"))
        
        threading.Thread(target=load_file_async, daemon=True).start()
        self._write_term(f"Loading {self.run_path.name}...\n", "info")
    
    def _update_file_info_ui(self, warnings: List[str], is_risky: bool):
        """Update file info UI (must run in main thread)"""
        # Update safety warning
        if warnings:
            warning_text = " | ".join(warnings[:3])  # Show first 3
            if len(warnings) > 3:
                warning_text += f" ... +{len(warnings)-3} more"
            self.safety_warning.configure(text=warning_text)
            self.unsafe_check.pack(side="left")  # Show checkbox
            # Auto-check if risky imports detected
            if is_risky:
                self.unsafe_var.set(True)
                self._toggle_safe()
        else:
            self.safety_warning.configure(text="✅ No risky imports/calls detected")
            # Keep checkbox visible but user can uncheck if they want safe mode
            self.unsafe_check.pack(side="left")
        
        # Update details
        self.detail_box.configure(state="normal")
        self.detail_box.delete("1.0", "end")
        self.detail_box.insert("end", f"File: {self.run_path.name}\n")
        self.detail_box.insert("end", f"Size: {self.run_path.stat().st_size / (1024*1024):.2f} MB\n")
        if self.file_info.get("valid"):
            self.detail_box.insert("end", f"Version: {self.file_info.get('version_label', 'unknown')}\n")
            self.detail_box.insert("end", f"Modules: {self.file_info.get('module_count', 0)}\n")
        self.detail_box.configure(state="disabled")
        
        # Load scripts into scripts tab
        self._load_scripts_tab()
        
        self._write_term(f"✓ Loaded {self.run_path.name}\n", "success")
        
        # Update safety warning
        if warnings:
            warning_text = " | ".join(warnings[:3])  # Show first 3
            if len(warnings) > 3:
                warning_text += f" ... +{len(warnings)-3} more"
            self.safety_warning.configure(text=warning_text)
            self.unsafe_check.pack(side="left")  # Show checkbox
            # Auto-check if risky imports detected
            if is_risky:
                self.unsafe_var.set(True)
                self._toggle_safe()
        else:
            self.safety_warning.configure(text="✅ No risky imports/calls detected")
            # Keep checkbox visible but user can uncheck if they want safe mode
            self.unsafe_check.pack(side="left")
        
        # Update details
        self.detail_box.configure(state="normal")
        self.detail_box.delete("1.0", "end")
        self.detail_box.insert("end", f"File: {self.run_path.name}\n")
        self.detail_box.insert("end", f"Size: {self.run_path.stat().st_size / (1024*1024):.2f} MB\n")
        if self.file_info.get("valid"):
            self.detail_box.insert("end", f"Version: {self.file_info.get('version_label', 'unknown')}\n")
            self.detail_box.insert("end", f"Modules: {self.file_info.get('module_count', 0)}\n")
        self.detail_box.configure(state="disabled")
        
        # Load scripts into scripts tab
        self._load_scripts_tab()

    def _pick_inspect(self):
        fp = filedialog.askopenfilename(filetypes=[("4DLLM", "*.4dllm"), ("All", "*.*")])
        if not fp:
            return
        self.run_path = Path(fp)
        self._refresh_inspect()
    
    def _refresh_inspect(self):
        """Refresh inspect view with current file - non-blocking"""
        if not self.run_path or not self.run_path.exists():
            return
        
        # Run inspection in background thread
        def inspect_async():
            try:
                DEBUG_LOGGER.info(f"Inspecting file: {self.run_path}")
                self._do_inspect()
            except Exception as e:
                DEBUG_LOGGER.error(f"Inspect error: {e}", exc_info=True)
                self.after(0, lambda: messagebox.showerror("Inspect failed", str(e)))
        
        threading.Thread(target=inspect_async, daemon=True).start()
        self.inspect_box.configure(state="normal")
        self.inspect_box.delete("1.0", "end")
        self.inspect_box.insert("end", "Inspecting file...\n")
        self.inspect_box.configure(state="disabled")
    
    def _do_inspect(self):
        """Do the actual inspection (runs in background thread)"""
        try:
            self.inspect_box.configure(state="normal")
            self.inspect_box.delete("1.0", "end")
            
            lines = []
            lines.append(f"=== 4DLLM File Inspection ===\n")
            lines.append(f"File: {self.run_path.name}\n")
            lines.append(f"Size: {self.run_path.stat().st_size / (1024*1024):.2f} MB\n")
            lines.append("")
            
            # Read file version
            with open(self.run_path, "rb") as f:
                magic = f.read(4)
                if magic != FOURDLLM_MAGIC:
                    lines.append("❌ ERROR: Not a valid 4DLLM file (bad magic)\n")
                    self.inspect_box.insert("end", "".join(lines))
                    self.inspect_box.configure(state="disabled")
                    return
                ver = struct.unpack("<I", f.read(4))[0]
            
            lines.append(f"Version: {ver} ({'legacy v1' if ver == 1 else f'v{ver}'})\n")
            lines.append("")
            
            if ver == FOURDLLM_VERSION_EXPECTED:
                entries, toc_off = read_and_validate_toc(self.run_path)
                lines.append(f"✅ TOC found at offset: {toc_off} (0x{toc_off:x})\n")
                lines.append(f"Section count: {len(entries)}\n")
                lines.append("")
                lines.append("=== Sections ===\n")
                
                section_names = {
                    SECTION_GGUF_DATA: "GGUF Data",
                    SECTION_PYTHON_SCRIPT: "Python Script",
                    SECTION_METADATA: "Metadata",
                    SECTION_SCRIPT_CONFIG: "Script Config",
                    SECTION_MANIFEST: "Manifest",
                }
                
                warnings = []
                for i, ent in enumerate(entries):
                    sec_name = section_names.get(ent.section_type, f"Unknown (0x{ent.section_type:02x})")
                    compressed = "Yes" if (ent.flags & FLAG_COMPRESSED_ZLIB) else "No"
                    lines.append(f"\n[{i+1}] {sec_name}")
                    lines.append(f"    Type: 0x{ent.section_type:02x}")
                    lines.append(f"    Offset: {ent.offset} (0x{ent.offset:x})")
                    lines.append(f"    Compressed: {compressed}")
                    lines.append(f"    Size (compressed): {ent.size_c:,} bytes")
                    lines.append(f"    Size (uncompressed): {ent.size_u:,} bytes")
                    lines.append(f"    CRC32: 0x{ent.crc32_u:08x}")
                    
                    # Validate CRC if possible
                    if ent.section_type in (SECTION_METADATA, SECTION_SCRIPT_CONFIG, SECTION_PYTHON_SCRIPT):
                        try:
                            sec = read_section_small(self.run_path, ent)
                            decoded = decode_and_validate(sec)
                            lines.append(f"    ✅ CRC32: Valid")
                        except Exception as e:
                            lines.append(f"    ❌ CRC32: FAILED - {e}")
                            warnings.append(f"Section {i+1} ({sec_name}): CRC validation failed")
                
                if warnings:
                    lines.append("\n=== Warnings ===\n")
                    for w in warnings:
                        lines.append(f"⚠️  {w}\n")
                else:
                    lines.append("\n✅ All sections validated successfully\n")
            
            # Update UI in main thread
            self.after(0, lambda: self._update_inspect_ui("".join(lines)))
            
        except Exception as e:
            DEBUG_LOGGER.error(f"Inspection failed: {e}", exc_info=True)
            error_msg = f"❌ Inspection failed: {e}\n"
            self.after(0, lambda: self._update_inspect_ui(error_msg))
            self.after(0, lambda: messagebox.showerror("Inspect failed", str(e)))
    
    def _update_inspect_ui(self, content: str):
        """Update inspect UI (must run in main thread)"""
        self.inspect_box.configure(state="normal")
        self.inspect_box.delete("1.0", "end")
        self.inspect_box.insert("end", content)
        self.inspect_box.configure(state="disabled")

    # ---- Build action ----
    def _build_action(self):
        if not self.builder_mod:
            messagebox.showerror("Missing builder", "4dllm_builder_v2.0.py not found.")
            return
        if not self.gguf_path:
            messagebox.showwarning("Missing GGUF", "Select a GGUF.")
            return
        out = self.out_entry.get().strip() or str(self.gguf_path.with_suffix(".4dllm"))
        try:
            b = self.builder_mod.FourDLLMBuilderV2(str(self.gguf_path))
            b.metadata = {"name": "RomanAILabs 4DLLM"}
            mod_dir = Path(__file__).parent / "modules"
            if mod_dir.exists():
                for p in sorted(mod_dir.glob("*.py")):
                    content = p.read_text(encoding="utf-8")
                    item = self.builder_mod.ScriptItem(
                        name=p.name,
                        content=content,
                        description="Module script",
                        priority=5,
                        enabled=True,
                        source_path=str(p),
                    )
                    b.add_script(item)
            b.build(out, compress_scripts=True, compress_metadata=True)
            self.build_status.configure(text=f"Built: {Path(out).name}")
            messagebox.showinfo("Built", f"Created {out}")
        except Exception as e:
            self.build_status.configure(text=f"Build failed: {e}")
            messagebox.showerror("Build failed", str(e))

    def _load_scripts_tab(self):
        """Load scripts into scripts tab - non-blocking"""
        if not hasattr(self, 'scripts_tree'):
            return
        
        if not self.run_path or not self.file_info.get("valid"):
            return
        
        # Load in background thread
        def load_scripts_async():
            try:
                DEBUG_LOGGER.debug("Loading scripts tab")
                entries, _ = read_and_validate_toc(self.run_path)
                script_config = self.file_info.get("script_config", {})
                scripts_cfg = script_config.get("scripts", [])
                
                # Create mapping
                cfg_map = {s.get("name", ""): s for s in scripts_cfg}
                
                script_entries = [e for e in entries if e.section_type == SECTION_PYTHON_SCRIPT]
                script_data = []
                
                for ent in script_entries:
                    try:
                        sec = read_section_small(self.run_path, ent)
                        extra = sec.extra or {}
                        name = extra.get("name", "unknown.py")
                        cfg = cfg_map.get(name, {})
                        priority = cfg.get("priority", extra.get("priority", 0))
                        enabled = cfg.get("enabled", True)
                        
                        script_data.append((name, priority, enabled, ent.size_u))
                    except Exception as e:
                        DEBUG_LOGGER.warning(f"Error loading script entry: {e}")
                
                # Update UI in main thread
                self.after(0, lambda: self._update_scripts_tree(script_data))
            except Exception as e:
                DEBUG_LOGGER.error(f"Error loading scripts: {e}", exc_info=True)
        
        threading.Thread(target=load_scripts_async, daemon=True).start()
    
    def _update_scripts_tree(self, script_data: List[Tuple[str, int, bool, int]]):
        """Update scripts tree (must run in main thread)"""
        # Clear existing
        for item in self.scripts_tree.get_children():
            self.scripts_tree.delete(item)
        
        # Insert new data
        for name, priority, enabled, size_u in script_data:
            self.scripts_tree.insert("", "end", text=name,
                                    values=(priority, "Yes" if enabled else "No", 
                                           f"{size_u:,} bytes"))

    # ---- Run action ----
    def _run_action(self):
        """Run action - non-blocking with threading"""
        if self.proc or not self.run_path:
            return
        
        # Run in background thread to prevent UI freeze
        def run_in_thread():
            try:
                # Check safety if risky content detected
                _, is_risky = self._analyze_safety(self.run_path)
                if is_risky and not self.unsafe_var.get():
                    self.after(0, lambda: messagebox.askyesno("Risky Content Detected", 
                                      "This file contains risky imports/calls.\n"
                                      "Enable 'Allow Unsafe Modules' to proceed.\n\n"
                                      "Proceed anyway?"))
                    return
                
                cmd = self._build_command()
                
                # Update UI in main thread
                self.after(0, lambda: self._update_badge_for_run())
                
                # Use unbuffered mode for maximum speed
                # Set environment for unbuffered Python output
                env = os.environ.copy()
                env['PYTHONUNBUFFERED'] = '1'
                env['PYTHONIOENCODING'] = 'utf-8'
                
                # Add -u flag to Python for unbuffered stdout/stderr
                if cmd[0] == sys.executable:
                    cmd = [cmd[0], '-u'] + cmd[1:]
                
                # Use unbuffered mode (bufsize=0) for maximum speed
                self.proc = subprocess.Popen(
                    cmd, 
                    stdout=subprocess.PIPE, 
                    stderr=subprocess.STDOUT, 
                    stdin=subprocess.PIPE,
                    text=True, 
                    bufsize=0,  # Unbuffered for maximum speed
                    env=env,
                    universal_newlines=True
                )
                threading.Thread(target=self._reader, daemon=True).start()
                self.after(0, lambda: self._write_term(" ".join(cmd) + "\n", "info"))
                DEBUG_LOGGER.info(f"Started process: {' '.join(cmd)}")
            except Exception as e:
                DEBUG_LOGGER.error(f"Run failed: {e}", exc_info=True)
                self.after(0, lambda: messagebox.showerror("Run failed", str(e)))
        
        # Start in background thread
        threading.Thread(target=run_in_thread, daemon=True).start()
    
    def _update_badge_for_run(self):
        """Update badge UI (must run in main thread)"""
        if self.unsafe_var.get():
            self.badge.configure(text="UNSAFE", fg_color=COLORS["status_unsafe"], 
                                text_color=COLORS["fg_primary"],
                                font=ctk.CTkFont(size=12, weight="bold"))
        else:
            self.badge.configure(text="SAFE", fg_color=COLORS["status_safe"], 
                               text_color=COLORS["fg_primary"],
                               font=ctk.CTkFont(size=12, weight="bold"))
    
    def _send_chat_message(self):
        """Send chat message to running process"""
        if not self.proc:
            self._write_term("[No process running]\n", "warning")
            return
        
        # Check if process is still running
        if self.proc.poll() is not None:
            self._write_term("[Process has finished]\n", "warning")
            self.proc = None
            return
        
        if not self.proc.stdin:
            self._write_term("[Stdin not available]\n", "warning")
            return
        
        # Get text from chat input
        text = self.chat_input.get("1.0", "end-1c").strip()
        if not text:
            return
        
        # Send to process in a thread to avoid blocking
        def send_in_thread():
            try:
                # Write with newline and flush immediately
                self.proc.stdin.write(text + "\n")
                self.proc.stdin.flush()
                
                # Echo to terminal in main thread
                self.after(0, lambda: self._write_term(f"You> {text}\n", "command"))
                
                # Clear chat input in main thread
                self.after(0, lambda: self.chat_input.delete("1.0", "end"))
                
                DEBUG_LOGGER.debug(f"Sent chat message: {text[:50]}")
            except BrokenPipeError:
                DEBUG_LOGGER.warning("Process stdin pipe broken")
                self.after(0, lambda: self._write_term("[Process stdin closed]\n", "error"))
                self.after(0, lambda: setattr(self, 'proc', None))
            except Exception as e:
                DEBUG_LOGGER.error(f"Failed to send chat message: {e}", exc_info=True)
                self.after(0, lambda: self._write_term(f"[Error sending message: {e}]\n", "error"))
        
        threading.Thread(target=send_in_thread, daemon=True).start()
    
    def _on_chat_enter(self, event):
        """Handle Enter key in chat input - sends message"""
        # Check if Shift is held (Shift+Enter should add newline)
        if event.state & 0x1:  # Shift key pressed
            return None  # Allow normal Enter behavior (newline)
        # Enter without Shift sends the message
        self._send_chat_message()
        return "break"
    
    def _on_chat_shift_enter(self, event):
        """Handle Shift+Enter in chat input - adds newline"""
        # Allow normal Enter behavior (newline)
        return None
    
    def _clear_chat_input(self):
        """Clear chat input box"""
        self.chat_input.delete("1.0", "end")

    def _reader(self):
        """Reader thread optimized for maximum speed"""
        assert self.proc and self.proc.stdout
        partial = ""
        
        try:
            while self.proc.poll() is None:
                try:
                    # Fast non-blocking read check with minimal timeout
                    if sys.platform != "win32":
                        ready, _, _ = select.select([self.proc.stdout], [], [], 0.001)  # 1ms timeout
                        if not ready:
                            time.sleep(0.001)  # Minimal sleep
                            continue
                    
                    # Read larger chunks for better throughput (4KB)
                    chunk = self.proc.stdout.read(4096)
                    if not chunk:
                        if self.proc.poll() is not None:
                            break
                        time.sleep(0.001)  # Minimal sleep
                        continue
                    
                    # Combine with partial line
                    data = partial + chunk
                    lines = data.split('\n')
                    
                    # Last element is either empty (if data ended with \n) or a partial line
                    if data.endswith('\n'):
                        partial = ""
                        complete_lines = lines[:-1]  # All complete
                    else:
                        partial = lines[-1]  # Save partial for next read
                        complete_lines = lines[:-1]  # All but last are complete
                    
                    # Batch queue complete lines for speed
                    for line in complete_lines:
                        try:
                            self.queue.put_nowait(("out", line + '\n'))
                        except queue.Full:
                            # Queue full, wait a tiny bit
                            time.sleep(0.001)
                            self.queue.put_nowait(("out", line + '\n'))
                    
                    # If we have a partial line and process is done, flush it
                    if partial and self.proc.poll() is not None:
                        self.queue.put(("out", partial))
                        partial = ""
                        
                except Exception as e:
                    DEBUG_LOGGER.error(f"Reader error: {e}", exc_info=True)
                    self.queue.put(("out", f"[Read error: {e}]\n"))
                    break
            
            # Flush any remaining partial line
            if partial:
                self.queue.put(("out", partial + '\n'))
            self.queue.put(("done", ""))
        except Exception as e:
            DEBUG_LOGGER.error(f"Reader thread error: {e}", exc_info=True)
            self.queue.put(("done", ""))

    def _poll_queue(self):
        """Poll queue for process output - optimized for maximum speed"""
        try:
            # Batch process multiple items for speed
            batch = []
            count = 0
            max_batch = 10  # Process up to 10 items per poll
            
            while count < max_batch:
                try:
                    tag, text = self.queue.get_nowait()
                    if tag == "out":
                        batch.append(text)
                        count += 1
                    elif tag == "done":
                        # Flush batch first
                        if batch:
                            output_tag = self._detect_output_tag(batch[0])
                            self._write_term_batch(batch, output_tag)
                        self._write_term("\n[process finished]\n", "info")
                        self.proc = None
                        DEBUG_LOGGER.info("Process finished")
                        break
                except queue.Empty:
                    break
            
            # Write batched output for speed
            if batch:
                output_tag = self._detect_output_tag(batch[0])
                self._write_term_batch(batch, output_tag)
                
        except Exception as e:
            DEBUG_LOGGER.error(f"Queue poll error: {e}", exc_info=True)
        self.after(10, self._poll_queue)  # Ultra-fast polling (10ms) for maximum responsiveness
    
    def _detect_output_tag(self, text: str) -> str:
        """Detect output type for syntax highlighting"""
        text_lower = text.lower()
        if text.strip().startswith("AI>"):
            return "success"  # AI responses in success color
        elif "error" in text_lower or "exception" in text_lower or "failed" in text_lower or "traceback" in text_lower:
            return "error"
        elif "success" in text_lower or "✓" in text or "completed" in text_lower:
            return "success"
        elif "warning" in text_lower or "warn" in text_lower:
            return "warning"
        elif "[4dllm]" in text_lower or "info" in text_lower:
            return "info"
        return "output"

    def _write_term(self, text: str, tag: str = "output"):
        """Write to terminal with optional tag - optimized"""
        try:
            self.term.configure(state="normal")
            self.term.insert("end", text, tag)
            self.term.see("end")
            self.term.configure(state="disabled")
        except Exception as e:
            DEBUG_LOGGER.error(f"Error writing to terminal: {e}", exc_info=True)
    
    def _write_term_batch(self, texts: List[str], tag: str = "output"):
        """Write multiple texts in one operation for maximum speed"""
        try:
            # Single state change for batch write
            self.term.configure(state="normal")
            combined = "".join(texts)
            # Insert all at once
            self.term.insert("end", combined, tag)
            # Auto-scroll to end
            self.term.see("end")
            # Single state change back
            self.term.configure(state="disabled")
            # Force update for immediate display
            self.term.update_idletasks()
        except Exception as e:
            DEBUG_LOGGER.error(f"Error writing batch to terminal: {e}", exc_info=True)

    def _stop_action(self):
        """Stop the running process"""
        if self.proc:
            try:
                DEBUG_LOGGER.info("Terminating process")
                self.proc.terminate()
                time.sleep(0.5)
                if self.proc.poll() is None:
                    self.proc.kill()
                self.proc = None
                self._write_term("\n[terminated]\n", "warning")
            except Exception as e:
                DEBUG_LOGGER.error(f"Error stopping process: {e}", exc_info=True)
                self._write_term(f"\n[Error stopping: {e}]\n", "error")

    def _build_tab_scripts(self, tab: ctk.CTkFrame):
        """Scripts tab: list embedded scripts with search, enable/disable, priority ordering"""
        frm = ctk.CTkFrame(tab, fg_color=COLORS["glass_medium"], corner_radius=18)
        frm.pack(fill="both", expand=True, padx=16, pady=16)
        
        # Add gradient overlay
        scripts_gradient, _ = self._create_gradient_frame(
            frm,
            color1=COLORS["gradient_mid"],
            color2=COLORS["gradient_end"],
            direction="vertical"
        )
        scripts_gradient.place(x=0, y=0, relwidth=1, relheight=1)
        
        # Header with subtle gradient
        header_frame = tk.Frame(frm, bg=COLORS["bg_primary"], height=60)
        header_frame.pack(anchor="w", fill="x", padx=20, pady=(20, 16))
        header_frame.pack_propagate(False)
        
        # Subtle blue gradient bar
        gradient_bar = self.GradientBar(header_frame, height=60)
        gradient_bar.pack(fill="both", expand=True)
        
        header = ctk.CTkLabel(
            header_frame, 
            text="Scripts & Modules", 
            font=ctk.CTkFont(size=20, weight="bold"),
            text_color=COLORS["accent_cyan"],  # Cyan accent text
            bg_color="transparent"
        )
        header.pack(anchor="w", padx=20, pady=(20, 16))
        
        # Top controls with elegant search
        top_frame = ctk.CTkFrame(frm, fg_color="transparent")
        top_frame.pack(fill="x", padx=20, pady=(0, 12))
        
        ctk.CTkLabel(
            top_frame, 
            text="Search:", 
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color=COLORS["fg_primary"]
        ).pack(side="left", padx=(0, 12))
        
        self.script_search_var = tk.StringVar()
        self.script_search_var.trace("w", lambda *a: self._filter_scripts())
        search_entry = ctk.CTkEntry(
            top_frame, 
            textvariable=self.script_search_var, 
            width=300,
            fg_color=COLORS["bg_secondary"],
            text_color=COLORS["fg_primary"],
            border_color=COLORS["border"],
            corner_radius=10,
            height=40,
            font=ctk.CTkFont(size=11)
        )
        search_entry.pack(side="left", padx=(0, 0))
        
        # Scripts list with glass-morphism styling
        list_frame = ctk.CTkFrame(frm, fg_color=COLORS["glass_dark"], 
                                  corner_radius=18, border_width=2, 
                                  border_color=COLORS["glass_border"])
        list_frame.pack(fill="both", expand=True, padx=20, pady=(0, 12))
        
        # Use Treeview with custom styling
        tree_frame = tk.Frame(list_frame, bg=COLORS["bg_secondary"])
        tree_frame.pack(fill="both", expand=True, padx=16, pady=16)
        
        # Custom scrollbar styling
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Treeview", 
                       background=COLORS["bg_tertiary"],
                       foreground=COLORS["fg_primary"],
                       fieldbackground=COLORS["bg_tertiary"],
                       borderwidth=0)
        style.configure("Treeview.Heading",
                       background=COLORS["bg_quaternary"],
                       foreground=COLORS["fg_primary"],
                       borderwidth=1,
                       relief="flat")
        style.map("Treeview",
                 background=[("selected", COLORS["accent_blue"])],
                 foreground=[("selected", COLORS["fg_primary"])])
        
        scrollbar = ttk.Scrollbar(tree_frame, style="TScrollbar")
        scrollbar.pack(side="right", fill="y")
        
        self.scripts_tree = ttk.Treeview(
            tree_frame, 
            columns=("priority", "enabled", "size"), 
            show="tree headings", 
            yscrollcommand=scrollbar.set,
            selectmode="browse"
        )
        scrollbar.config(command=self.scripts_tree.yview)
        
        self.scripts_tree.heading("#0", text="Script Name")
        self.scripts_tree.heading("priority", text="Priority")
        self.scripts_tree.heading("enabled", text="Enabled")
        self.scripts_tree.heading("size", text="Size")
        
        self.scripts_tree.column("#0", width=300)
        self.scripts_tree.column("priority", width=100)
        self.scripts_tree.column("enabled", width=100)
        self.scripts_tree.column("size", width=120)
        
        self.scripts_tree.pack(side="left", fill="both", expand=True)
        self.scripts_tree.bind("<Double-Button-1>", self._show_script_preview)
        
        # Preview pane with glass-morphism styling
        preview_frame = ctk.CTkFrame(frm, fg_color=COLORS["terminal_bg"], 
                                     corner_radius=18, border_width=2, 
                                     border_color=COLORS["glass_border"])
        preview_frame.pack(fill="both", expand=True, padx=20, pady=(0, 20))
        
        preview_header = ctk.CTkLabel(
            preview_frame, 
            text="Script Preview (read-only)", 
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color=COLORS["accent_cyan"],
            height=50
        )
        preview_header.pack(fill="x", padx=16, pady=(16, 0))
        
        self.script_preview = ctk.CTkTextbox(
            preview_frame, 
            fg_color=COLORS["terminal_bg"], 
            text_color=COLORS["fg_primary"],
            font=ctk.CTkFont(family="Consolas", size=10),
            corner_radius=12,
            border_width=0
        )
        self.script_preview.pack(fill="both", expand=True, padx=16, pady=(0, 16))
        self.script_preview.configure(state="disabled")
    
    def _build_tab_settings(self, tab: ctk.CTkFrame):
        """Settings tab for configuration"""
        frm = ctk.CTkFrame(tab, fg_color=COLORS["glass_medium"], corner_radius=18)
        frm.pack(fill="both", expand=True, padx=16, pady=16)
        
        # Header
        header = ctk.CTkLabel(
            frm, 
            text="Settings", 
            font=ctk.CTkFont(size=20, weight="bold"),
            text_color=COLORS["accent_cyan"]
        )
        header.pack(anchor="w", padx=20, pady=(20, 16))
        
        # Profile management with glass-morphism styling
        profile_mgmt = ctk.CTkFrame(frm, fg_color=COLORS["glass_dark"], 
                                    corner_radius=18, border_width=2, 
                                    border_color=COLORS["glass_border"])
        profile_mgmt.pack(fill="both", expand=True, padx=20, pady=(0, 20))
        
        profile_header = ctk.CTkLabel(
            profile_mgmt, 
            text="Profile Management", 
            font=ctk.CTkFont(size=16, weight="bold"),
            text_color=COLORS["accent_cyan"],
            height=50
        )
        profile_header.pack(fill="x", padx=16, pady=(16, 0))
        
        # Profile editor with elegant styling
        self.profile_display = ctk.CTkTextbox(
            profile_mgmt, 
            height=400, 
            fg_color=COLORS["terminal_bg"], 
            text_color=COLORS["fg_primary"],
            font=ctk.CTkFont(family="Consolas", size=10),
            corner_radius=12,
            border_width=1,
            border_color=COLORS["border"]
        )
        self.profile_display.pack(fill="both", expand=True, padx=16, pady=(0, 16))
        self.profile_display.insert("end", "Current profile settings will be shown here.\n")
        self.profile_display.configure(state="disabled")
    
    def _filter_scripts(self):
        """Filter scripts based on search"""
        # Implementation would filter treeview items
        pass
    
    def _show_script_preview(self, event):
        """Show script preview when double-clicked"""
        selection = self.scripts_tree.selection()
        if not selection:
            return
        item = selection[0]
        # Implementation would load and display script content
        self.script_preview.configure(state="normal")
        self.script_preview.delete("1.0", "end")
        self.script_preview.insert("end", f"Preview for: {self.scripts_tree.item(item, 'text')}\n")
        self.script_preview.configure(state="disabled")
    
    def _load_profile(self, profile_name: str):
        """Load a profile preset"""
        if profile_name in self.profiles:
            self.current_profile = self.profiles[profile_name].copy()
            # Update UI elements if they exist
            if hasattr(self, 'profile_display'):
                self.profile_display.configure(state="normal")
                self.profile_display.delete("1.0", "end")
                self.profile_display.insert("end", f"Profile: {profile_name}\n")
                for k, v in self.current_profile.items():
                    self.profile_display.insert("end", f"  {k}: {v}\n")
                self.profile_display.configure(state="disabled")
    
    def _copy_command(self):
        """Copy the command that would be run"""
        if not self.run_path:
            messagebox.showwarning("No file", "Select a .4dllm file first.")
            return
        
        cmd = self._build_command()
        cmd_str = " ".join(shlex.quote(str(arg)) for arg in cmd)
        
        self.clipboard_clear()
        self.clipboard_append(cmd_str)
        messagebox.showinfo("Copied", "Command copied to clipboard!")
    
    def _build_command(self) -> List[str]:
        """Build the command to run"""
        runner_script = Path(__file__).parent / "4dllm_runner.py"
        cmd = [
            sys.executable,
            str(runner_script),
            "--file", str(self.run_path),
            "--backend", self.current_profile.get("backend", "llama_cpp"),
            "--n-ctx", str(self.current_profile.get("n_ctx", "4096")),
            "--threads", str(self.current_profile.get("threads", "4")),
            "--gpu-layers", str(self.current_profile.get("gpu_layers", "0")),
            "--max-tokens", str(self.current_profile.get("max_tokens", "256")),
            "--temp", str(self.current_profile.get("temp", "0.7")),
        ]
        if self.unsafe_var.get():
            cmd.append("--unsafe-modules")
        return cmd
    
    def _on_drop(self, event):
        """Handle drag-drop of .4dllm files"""
        if not HAS_DND:
            return
        
        try:
            files = self.tk.splitlist(event.data)
            for file_path in files:
                if file_path.endswith('.4dllm'):
                    self.run_path = Path(file_path)
                    self._pick_run()
                    break
        except Exception as e:
            messagebox.showerror("Drop failed", str(e))
    
    
    def _clear_terminal(self):
        """Clear terminal"""
        self.term.configure(state="normal")
        self.term.delete("1.0", "end")
        self.term.configure(state="disabled")
    
    def _load_recent_file(self):
        """Load file from recent list"""
        selection = self.recent_listbox.curselection()
        if selection:
            file_path = self.recent_listbox.get(selection[0])
            self.run_path = Path(file_path)
            self._pick_run()
    
    def _analyze_safety(self, file_path: Path) -> Tuple[List[str], bool]:
        """Analyze file for risky imports/calls. Returns (warnings, is_risky)"""
        warnings = []
        is_risky = False
        
        try:
            info = read_4dllm_info(file_path)
            if not info.get("valid"):
                return warnings, False
            
            script_config = info.get("script_config", {})
            scripts = script_config.get("scripts", [])
            
            risky_imports = {"subprocess", "os", "sys", "hashlib", "eval", "exec", "__import__", 
                           "open", "file", "socket", "urllib", "requests", "pickle", "shutil",
                           "tempfile", "pathlib", "json", "base64", "zlib", "gzip"}
            risky_calls = {"eval", "exec", "compile", "__import__", "open"}
            
            for script in scripts:
                if not script.get("enabled", True):
                    continue
                
                name = script.get("name", "unknown")
                source = script.get("source", "")
                
                if not source:
                    continue
                
                try:
                    tree = ast.parse(source)
                    for node in ast.walk(tree):
                        # Check imports
                        if isinstance(node, ast.Import):
                            for alias in node.names:
                                if alias.name.split('.')[0] in risky_imports:
                                    warnings.append(f"⚠️ {name}: risky import '{alias.name}'")
                                    is_risky = True
                        elif isinstance(node, ast.ImportFrom):
                            if node.module and node.module.split('.')[0] in risky_imports:
                                warnings.append(f"⚠️ {name}: risky import from '{node.module}'")
                                is_risky = True
                        
                        # Check function calls
                        if isinstance(node, ast.Call):
                            if isinstance(node.func, ast.Name):
                                if node.func.id in risky_calls:
                                    warnings.append(f"⚠️ {name}: risky call '{node.func.id}()'")
                                    is_risky = True
                except SyntaxError:
                    warnings.append(f"⚠️ {name}: syntax error (cannot analyze)")
        
        except Exception as e:
            warnings.append(f"⚠️ Safety analysis failed: {e}")
        
        return warnings, is_risky

    def _toggle_safe(self):
        if self.unsafe_var.get():
            self.badge.configure(text="UNSAFE", fg_color=COLORS["status_unsafe"], 
                                text_color=COLORS["fg_primary"],
                                font=ctk.CTkFont(size=12, weight="bold"))
        else:
            self.badge.configure(text="SAFE", fg_color=COLORS["status_safe"], 
                               text_color=COLORS["fg_primary"],
                               font=ctk.CTkFont(size=12, weight="bold"))


# ---------------- UI Theme - World-Class Navy Deep Blue ----------------
COLORS = {
    # Deep navy backgrounds with gradient-ready colors
    "bg_primary": "#020617",           # Deepest navy - main background
    "bg_secondary": "#0f172a",        # Slightly lighter navy - panels
    "bg_tertiary": "#1e293b",          # Medium navy - elevated panels
    "bg_quaternary": "#334155",       # Lighter navy - hover states
    "bg_elevated": "#1e293b",         # Elevated surfaces
    
    # Glass-morphism colors (simulated with subtle transparency effects)
    "glass_dark": "#0f172a",          # Dark glass base
    "glass_medium": "#1e293b",        # Medium glass
    "glass_light": "#334155",          # Light glass
    "glass_border": "#475569",         # Glass border highlight
    
    # Text colors with hierarchy
    "fg_primary": "#f1f5f9",          # Primary text (brighter for contrast)
    "fg_secondary": "#cbd5e1",         # Secondary text
    "fg_muted": "#94a3b8",             # Muted text
    "fg_disabled": "#64748b",          # Disabled text
    "fg_accent": "#e2e8f0",            # Accent text
    
    # Accent colors (sophisticated navy/cyan palette)
    "accent_cyan": "#06b6d4",          # Bright cyan accent
    "accent_cyan_dark": "#0891b2",      # Darker cyan
    "accent_blue": "#3b82f6",          # Primary blue
    "accent_blue_dark": "#2563eb",     # Dark blue
    "accent_blue_light": "#60a5fa",    # Light blue
    "accent_indigo": "#6366f1",        # Indigo accent
    
    # Button colors - elegant navy/grey palette (NO green/red)
    "btn_primary": "#1e293b",          # Primary button - dark navy
    "btn_primary_hover": "#334155",    # Primary hover - lighter navy
    "btn_secondary": "#334155",        # Secondary button
    "btn_secondary_hover": "#475569",  # Secondary hover
    "btn_accent": "#0f172a",           # Accent button - very dark
    "btn_accent_hover": "#1e293b",      # Accent hover
    "btn_action": "#1e40af",           # Action button - deep blue
    "btn_action_hover": "#2563eb",     # Action hover - brighter blue
    "btn_danger": "#475569",           # Danger button - grey (not red)
    "btn_danger_hover": "#64748b",      # Danger hover - lighter grey
    
    # Status colors - muted, sophisticated
    "status_safe": "#334155",          # Safe status - grey navy
    "status_unsafe": "#475569",        # Unsafe status - lighter grey
    "status_warning": "#64748b",       # Warning - muted grey
    "status_info": "#475569",          # Info - grey
    
    # Borders and dividers with glass effect
    "border": "#1e293b",               # Subtle borders
    "border_light": "#334155",          # Lighter borders
    "border_glow": "#475569",           # Glowing borders
    "divider": "#1e293b",              # Dividers
    
    # Terminal colors
    "terminal_bg": "#0a0f1a",          # Very dark navy terminal
    "terminal_fg": "#e2e8f0",          # Terminal text (brighter)
    "terminal_green": "#34d399",       # Terminal success (softer)
    "terminal_yellow": "#fbbf24",      # Terminal warning (softer)
    "terminal_red": "#f87171",         # Terminal error (softer)
    "terminal_blue": "#60a5fa",        # Terminal info
    "terminal_cyan": "#22d3ee",        # Terminal accent (brighter)
    "terminal_purple": "#a78bfa",      # Terminal special
    
    # Gradient colors for stunning effects
    "gradient_start": "#0f172a",       # Gradient start (dark navy)
    "gradient_mid": "#1e293b",         # Gradient middle (medium navy)
    "gradient_end": "#334155",          # Gradient end (lighter navy)
    "gradient_cyan_start": "#0891b2",  # Cyan gradient start
    "gradient_cyan_end": "#06b6d4",     # Cyan gradient end
    "gradient_blue_start": "#1e40af",  # Blue gradient start
    "gradient_blue_end": "#3b82f6",    # Blue gradient end
    "gradient_overlay": "#1e293b40",   # Gradient overlay (semi-transparent)
}


# ---------------- Data Structures ----------------

@dataclass
class ModuleInfo:
    name: str
    path: Path
    enabled: bool = True
    description: str = ""
    imports: List[str] = None
    
    def __post_init__(self):
        if self.imports is None:
            self.imports = []


@dataclass
class TerminalSession:
    name: str
    process: Optional[subprocess.Popen] = None
    thread: Optional[threading.Thread] = None
    queue: Optional[queue.Queue] = None
    running: bool = False


# ---------------- Terminal Widget ----------------

class IntegratedTerminal(scrolledtext.ScrolledText):
    """Advanced integrated terminal widget with syntax highlighting and features"""
    
    def __init__(self, parent, **kwargs):
        kwargs.setdefault("bg", COLORS["terminal_bg"])
        kwargs.setdefault("fg", COLORS["terminal_fg"])
        kwargs.setdefault("font", ("Consolas", 11))
        kwargs.setdefault("insertbackground", COLORS["accent_cyan"])
        kwargs.setdefault("relief", "flat")
        kwargs.setdefault("borderwidth", 0)
        kwargs.setdefault("padx", 12)
        kwargs.setdefault("pady", 10)
        
        super().__init__(parent, **kwargs)
        
        # Configure tags with navy theme colors
        self.tag_config("prompt", foreground=COLORS["terminal_green"], font=("Consolas", 11, "bold"))
        self.tag_config("command", foreground=COLORS["terminal_blue"])
        self.tag_config("output", foreground=COLORS["terminal_fg"])
        self.tag_config("error", foreground=COLORS["terminal_red"])
        self.tag_config("success", foreground=COLORS["terminal_green"])
        self.tag_config("warning", foreground=COLORS["terminal_yellow"])
        self.tag_config("info", foreground=COLORS["terminal_cyan"])
        self.tag_config("timestamp", foreground=COLORS["terminal_purple"], font=("Consolas", 9))
        self.tag_config("highlight", background=COLORS["bg_quaternary"])
        
        self.command_history: List[str] = []
        self.history_index = -1
        self.current_prompt = "> "
        self.process: Optional[subprocess.Popen] = None
        self.read_thread: Optional[threading.Thread] = None
        self.output_queue: queue.Queue = queue.Queue()
        self.running = False
        
        self.bind("<Return>", self._on_enter)
        self.bind("<Up>", self._on_up)
        self.bind("<Down>", self._on_down)
        self.bind("<Control-c>", self._on_copy_or_interrupt)
        self.bind("<Control-v>", self._on_paste)
        self.bind("<Control-x>", self._on_cut)
        self.bind("<Control-a>", self._on_select_all)
        self.bind("<Control-l>", self._on_clear)
        self.bind("<Button-1>", lambda e: self.focus_set())
        self.bind("<Button-3>", self._on_right_click)  # Right-click menu
        self.bind("<Shift-Insert>", self._on_paste)  # Shift+Insert paste
        self.bind("<Control-Insert>", self._copy_selection)  # Ctrl+Insert copy
        self.bind("<Key>", self._on_key)  # Handle all key presses
        
        # Enable text selection (don't pre-select everything)
        
        # Start queue processor
        self.after(50, self._process_queue)
        
        # Create context menu with navy theme
        self.context_menu = tk.Menu(self, tearoff=0, bg=COLORS["bg_secondary"], 
                                   fg=COLORS["fg_primary"], 
                                   activebackground=COLORS["accent_blue"],
                                   activeforeground=COLORS["fg_primary"],
                                   borderwidth=1,
                                   relief="flat")
        self.context_menu.add_command(label="Copy", command=self._copy_selection, accelerator="Ctrl+C")
        self.context_menu.add_command(label="Paste", command=self._paste_clipboard, accelerator="Ctrl+V")
        self.context_menu.add_separator()
        self.context_menu.add_command(label="Select All", command=self._select_all_text, accelerator="Ctrl+A")
        self.context_menu.add_separator()
        self.context_menu.add_command(label="Clear Terminal", command=self._on_clear)
        
        # Track cursor position for input editing
        self.input_start = "1.0"
    
    def _on_key(self, event=None):
        """Handle key presses for better input handling"""
        if event.keysym in ("Return", "Up", "Down", "Control_L", "Control_R"):
            return  # Let other handlers deal with these
        
        # If process is running, allow typing at the end
        if self.running:
            current_pos = self.index("insert")
            end_pos = self.index("end-1c")
            # Only allow typing at or near the end
            if self.compare(current_pos, "<", end_pos):
                # Check if we're on the last line (allow editing current input)
                current_line = self.index("insert linestart")
                end_line = self.index("end-1c linestart")
                if current_line != end_line:
                    # Not on last line, move to end
                    self.mark_set("insert", "end-1c")
    
    def _on_enter(self, event=None):
        """Handle Enter key - execute command or send to process"""
        # Get current line content
        line_start = self.index("insert linestart")
        line_end = self.index("insert lineend")
        line = self.get(line_start, line_end)
        
        # Remove prompt if present (handle both "> " and "You> ")
        if "You> " in line:
            line = line.split("You> ", 1)[-1].strip()
        elif line.startswith(self.current_prompt):
            line = line[len(self.current_prompt):].strip()
        else:
            line = line.strip()
        
        if self.running and self.process:
            # Send to running process
            if line:
                # Echo the input back to terminal
                self.config(state=tk.NORMAL)
                self.insert("end", f"You> {line}\n", "command")
                self.config(state=tk.DISABLED)
                # Send to process
                self.send_input(line + "\n")
            else:
                # Just send newline
                self.send_input("\n")
                self.config(state=tk.NORMAL)
                self.insert("end", "\n")
                self.config(state=tk.DISABLED)
            self.mark_set("insert", "end")
        else:
            # Execute as command
            if line:
                self.execute_command(line)
        
        self.see("end")
        return "break"
    
    def _on_up(self, event=None):
        """Navigate command history up"""
        if self.command_history and self.history_index > 0:
            self.history_index -= 1
            self._set_history_command()
        return "break"
    
    def _on_down(self, event=None):
        """Navigate command history down"""
        if self.command_history:
            if self.history_index < len(self.command_history) - 1:
                self.history_index += 1
                self._set_history_command()
            else:
                self.history_index = -1
                self._clear_line()
        return "break"
    
    def _set_history_command(self):
        """Set current line to history command"""
        cmd = self.command_history[self.history_index]
        self._clear_line()
        self.insert("insert", cmd)
        self.mark_set("insert", "end")
    
    def _clear_line(self):
        """Clear current input line"""
        line_start = self.index("insert linestart")
        line_end = self.index("insert lineend")
        self.delete(line_start, line_end)
    
    def _on_copy_or_interrupt(self, event=None):
        """Copy selection or send Ctrl+C to process"""
        # Always check for selection first
        try:
            # Check if there's a selection
            selection = self.tag_ranges("sel")
            if selection:
                # Copy selection to clipboard
                start = str(selection[0])
                end = str(selection[1])
                text = self.get(start, end)
                self.clipboard_clear()
                self.clipboard_append(text)
                return "break"
        except Exception:
            pass
        
        # If no selection, interrupt process (if running)
        if self.process and self.running:
            try:
                self.process.send_signal(2)  # SIGINT
                self.config(state=tk.NORMAL)
                self.insert("end", "^C\n", "warning")
                self.config(state=tk.DISABLED)
                self.see("end")
            except Exception:
                pass
        return "break"
    
    def _on_paste(self, event=None):
        """Paste from clipboard"""
        try:
            clipboard_text = self.clipboard_get()
            if clipboard_text:
                self.config(state=tk.NORMAL)
                # If process is running, send to it
                if self.running and self.process:
                    # Send to process stdin
                    self.send_input(clipboard_text)
                    # Display what was pasted (for feedback)
                    self.insert("insert", clipboard_text, "output")
                else:
                    # Paste into current position
                    self.insert("insert", clipboard_text)
                self.config(state=tk.DISABLED)
                self.see("insert")
        except tk.TclError:
            pass  # Clipboard empty or not available
        except Exception:
            pass
        return "break"
    
    def _on_cut(self, event=None):
        """Cut selection"""
        try:
            if self.tag_ranges("sel"):
                selection = self.get("sel.first", "sel.last")
                self.clipboard_clear()
                self.clipboard_append(selection)
                self.config(state=tk.NORMAL)
                self.delete("sel.first", "sel.last")
                self.config(state=tk.DISABLED)
        except:
            pass
        return "break"
    
    def _on_select_all(self, event=None):
        """Select all text"""
        self.tag_add("sel", "1.0", "end")
        self.mark_set("insert", "end")
        return "break"
    
    def _on_right_click(self, event):
        """Show context menu on right click"""
        try:
            self.context_menu.tk_popup(event.x_root, event.y_root)
        finally:
            self.context_menu.grab_release()
    
    def _copy_selection(self):
        """Copy selected text to clipboard"""
        try:
            if self.tag_ranges("sel"):
                selection = self.get("sel.first", "sel.last")
                self.clipboard_clear()
                self.clipboard_append(selection)
            else:
                # Copy current line if nothing selected
                line = self.get("insert linestart", "insert lineend")
                self.clipboard_clear()
                self.clipboard_append(line)
        except Exception:
            pass
    
    def _paste_clipboard(self):
        """Paste from clipboard"""
        self._on_paste()
    
    def _select_all_text(self):
        """Select all text"""
        self.tag_add("sel", "1.0", "end")
        self.mark_set("insert", "end")
        self.see("end")
    
    def _on_clear(self, event=None):
        """Clear terminal"""
        self.delete(1.0, "end")
        return "break"
    
    def execute_command(self, command: str):
        """Execute a command locally"""
        if not command.strip():
            self.write_prompt()
            return
        
        self.command_history.append(command)
        self.history_index = -1
        
        # Display command
        self.write(self.current_prompt, "prompt")
        self.write(command + "\n", "command")
        
        # Handle special commands
        cmd_lower = command.lower().strip()
        if cmd_lower in ("clear", "cls"):
            self.delete(1.0, "end")
            self.write_prompt()
            return
        elif cmd_lower in ("exit", "quit"):
            self.write("Use 'Stop' button to terminate processes.\n", "info")
            self.write_prompt()
            return
        elif cmd_lower.startswith("echo "):
            text = command[5:]
            self.write(text + "\n", "output")
            self.write_prompt()
            return
        
        # Default: show message
        self.write(f"Command: {command}\n", "info")
        self.write("(Process commands are handled by running processes)\n", "info")
        self.write_prompt()
    
    def write(self, text: str, tag: str = "output"):
        """Write text to terminal with tag"""
        # Keep terminal editable when process is running (for chat input)
        if not self.running:
            self.config(state=tk.NORMAL)
            self.insert("end", text, tag)
            self.config(state=tk.DISABLED)
        else:
            # Process running - keep editable for input
            self.config(state=tk.NORMAL)
            self.insert("end", text, tag)
            # Don't disable - keep editable for typing
        self.see("end")
    
    def write_prompt(self):
        """Write prompt"""
        self.config(state=tk.NORMAL)
        self.insert("end", self.current_prompt, "prompt")
        # Keep editable if process is running
        if not self.running:
            self.config(state=tk.DISABLED)
        self.mark_set("insert", "end")
        self.see("end")
    
    def start_process(self, cmd: List[str], cwd: Optional[str] = None, env: Optional[Dict] = None):
        """Start a subprocess and capture its output"""
        if self.running:
            self.stop_process()
        
        try:
            self.process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                stdin=subprocess.PIPE,
                cwd=cwd,
                env=env,
                bufsize=1,  # Line buffered for better interactivity
                text=True,
                universal_newlines=True,
            )
            
            self.running = True
            self.read_thread = threading.Thread(target=self._read_output, daemon=True)
            self.read_thread.start()
            
            self.write(f"Started process: {' '.join(cmd)}\n", "success")
            # Don't write prompt yet - wait for process to prompt us
            
        except Exception as e:
            self.write(f"Error starting process: {e}\n", "error")
            self.write_prompt()
    
    def stop_process(self):
        """Stop the running process"""
        if self.process:
            try:
                self.process.terminate()
                time.sleep(0.5)
                if self.process.poll() is None:
                    self.process.kill()
                self.process = None
            except:
                pass
        
        self.running = False
        if self.read_thread:
            self.read_thread.join(timeout=1)
        
        self.write("\n[Process stopped]\n", "warning")
        self.write_prompt()
    
    def send_input(self, text: str):
        """Send input to the process"""
        if self.process and self.process.stdin:
            try:
                self.process.stdin.write(text)
                self.process.stdin.flush()
            except:
                pass
    
    def _read_output(self):
        """Read output from process in background thread - buffered reads for low CPU"""
        if not self.process:
            return
        
        # Use buffered reads (8KB chunks) instead of char-by-char
        buffer_size = 8192
        partial_line = ""
        
        while self.running and self.process.poll() is None:
            try:
                # Check if stdout is ready (non-blocking)
                if sys.platform != "win32":
                    # Unix: use select for non-blocking check
                    ready, _, _ = select.select([self.process.stdout], [], [], 0.1)
                    if not ready:
                        time.sleep(0.05)  # Small sleep to avoid busy-wait
                        continue
                
                # Read buffered chunk
                chunk = self.process.stdout.read(buffer_size)
                if not chunk:
                    if self.process.poll() is not None:
                        break
                    time.sleep(0.05)
                    continue
                
                # Combine with any partial line from previous read
                data = partial_line + chunk
                lines = data.split('\n')
                
                # Last element is either empty (if data ended with \n) or a partial line
                if data.endswith('\n'):
                    partial_line = ""
                    complete_lines = lines[:-1]  # All complete
                else:
                    partial_line = lines[-1]  # Save partial for next read
                    complete_lines = lines[:-1]  # All but last are complete
                
                # Queue complete lines
                for line in complete_lines:
                    if line or partial_line:  # Include empty lines if we have partial
                        self.output_queue.put(("output", line + '\n'))
                
            except Exception as e:
                if self.running:
                    self.output_queue.put(("output", f"[Read error: {e}]\n"))
                break
        
        # Flush any remaining partial line
        if partial_line:
            self.output_queue.put(("output", partial_line + '\n'))
        
        self.output_queue.put(("finished", None))
    
    def _process_queue(self):
        """Process output queue (runs in main thread)"""
        try:
            while True:
                try:
                    tag, text = self.output_queue.get_nowait()
                    if tag == "finished":
                        self.running = False
                        self.write("\n[Process finished]\n", "info")
                        self.write_prompt()
                    else:
                        # Auto-detect output type
                        if text:
                            final_tag = self._detect_output_type(text)
                            self.write(text, final_tag)
                            
                            # If we see "You> " prompt, enable input mode
                            if "You> " in text and self.running:
                                self.config(state=tk.NORMAL)
                                # Allow typing at the end
                                self.mark_set("insert", "end")
                                self.config(state=tk.NORMAL)  # Keep enabled for input
                except queue.Empty:
                    break
        except:
            pass
        
        self.after(10, self._process_queue)  # Faster polling for better responsiveness
    
    def _detect_output_type(self, text: str) -> str:
        """Detect output type for syntax highlighting"""
        text_lower = text.lower()
        
        if "error" in text_lower or "exception" in text_lower or "failed" in text_lower or "traceback" in text_lower:
            return "error"
        elif "success" in text_lower or "✓" in text or "completed" in text_lower:
            return "success"
        elif "warning" in text_lower or "warn" in text_lower:
            return "warning"
        elif "info" in text_lower or "[4dllm]" in text_lower:
            return "info"
        
        return "output"


# ---------------- 4DLLM File Reader ----------------

def read_4dllm_info(file_path: Path) -> Dict[str, Any]:
    """Read metadata and basic info from a 4DLLM file"""
    info = {
        "valid": False,
        "error": None,
        "metadata": {},
        "script_config": {},
        "file_size": 0,
        "modules": [],
        "module_count": 0,
    }
    
    try:
        if not file_path.exists():
            info["error"] = "File not found"
            return info
        
        info["file_size"] = file_path.stat().st_size
        
        with open(file_path, "rb") as f:
            magic = f.read(4)
            if magic != FOURDLLM_MAGIC:
                info["error"] = "Not a 4DLLM file (bad magic)"
                return info
            
            ver = struct.unpack("<I", f.read(4))[0]
            info["version"] = ver
            info["version_label"] = "legacy v1" if ver == 1 else f"v{ver}"

        if ver == 1:
            info.update(read_4dllm_info_v1(file_path))
        elif ver == FOURDLLM_VERSION_EXPECTED:
            entries, toc_offset = read_and_validate_toc(file_path)
            
            for ent in entries:
                if ent.section_type == SECTION_METADATA:
                    sec = read_section_small(file_path, ent)
                    info["metadata"] = safe_json_loads(decode_and_validate(sec), default={})
                elif ent.section_type == SECTION_SCRIPT_CONFIG:
                    sec = read_section_small(file_path, ent)
                    info["script_config"] = safe_json_loads(decode_and_validate(sec), default={})
            
            scripts = info["script_config"].get("scripts", [])
            info["modules"] = [s.get("name", "unknown") for s in scripts if s.get("enabled", True)]
            info["module_count"] = len(info["modules"])
            info["modules_registry"] = info["script_config"].get("modules", {})
            
            info["valid"] = True
            info["toc_offset"] = toc_offset
        else:
            info["error"] = f"Unsupported version: {ver}"
        
    except Exception as e:
        info["error"] = str(e)
    
    return info


def read_4dllm_info_v1(file_path: Path) -> Dict[str, Any]:
    """
    Minimal reader for legacy v1 files (no TOC). Extracts metadata and script_config.
    """
    out = {
        "valid": False,
        "error": None,
        "metadata": {},
        "script_config": {},
        "modules": [],
        "module_count": 0,
    }

    try:
        with open(file_path, "rb") as f:
            f.seek(FOURDLLM_HEADER_SIZE)

            while True:
                hdr = f.read(LEGACY_SECTION_HDR_STRUCT.size)
                if not hdr or len(hdr) < LEGACY_SECTION_HDR_STRUCT.size:
                    break

                stype, flags, size_c, extra_sz = LEGACY_SECTION_HDR_STRUCT.unpack(hdr)
                extra_bytes = f.read(extra_sz) if extra_sz else b"{}"
                extra = safe_json_loads(extra_bytes, default={})
                payload_c = f.read(size_c) if size_c else b""
                payload = zlib.decompress(payload_c) if (flags & FLAG_COMPRESSED_ZLIB) else payload_c

                if stype == SECTION_METADATA:
                    out["metadata"] = safe_json_loads(payload, default={})
                elif stype == SECTION_SCRIPT_CONFIG:
                    out["script_config"] = safe_json_loads(payload, default={})
                elif stype == SECTION_PYTHON_SCRIPT:
                    name = extra.get("name") or "module.py"
                    out.setdefault("modules", []).append(name)

        modules_list = out.get("modules", [])
        out["module_count"] = len(modules_list)
        out["valid"] = True
        return out
    except Exception as e:
        out["error"] = str(e)
        return out


# ---------------- Main GUI Application ----------------

class FourDLLMRunnerGUI:
    """GUI with integrated terminal and module manager"""
    
    def __init__(self, root: tk.Tk):
        self.root = root
        self.current_file: Optional[Path] = None
        self.file_info: Dict[str, Any] = {}
        self.additional_modules: List[ModuleInfo] = []
        self.current_session: Optional[TerminalSession] = None
        
        self._setup_window()
        self._setup_ui()
    
    def _setup_window(self) -> None:
        self.root.title("4DLLM Runner — Integrated Terminal & Module Manager")
        self.root.geometry("1400x850")
        self.root.configure(bg=COLORS["bg_primary"])
        
        # Center window
        self.root.update_idletasks()
        w = self.root.winfo_width()
        h = self.root.winfo_height()
        x = (self.root.winfo_screenwidth() // 2) - (w // 2)
        y = (self.root.winfo_screenheight() // 2) - (h // 2)
        self.root.geometry(f"{w}x{h}+{x}+{y}")
    
    def _setup_ui(self) -> None:
        # Main container with paned windows
        main_paned = ttk.PanedWindow(self.root, orient=tk.HORIZONTAL)
        main_paned.pack(fill="both", expand=True)
        
        # Left panel - Controls (set minimum width)
        left_frame = tk.Frame(main_paned, bg=COLORS["bg_secondary"], width=380)
        main_paned.add(left_frame, weight=0)
        
        # Right panel - Terminal (smaller, more balanced)
        right_frame = tk.Frame(main_paned, bg=COLORS["bg_primary"])
        main_paned.add(right_frame, weight=2)
        
        self._setup_left_panel(left_frame)
        self._setup_right_panel(right_frame)
    
    def _setup_left_panel(self, parent: tk.Frame) -> None:
        # Header
        header = tk.Frame(parent, bg=COLORS["bg_tertiary"], height=60)
        header.pack(fill="x")
        header.pack_propagate(False)
        
        title = tk.Label(
            header,
            text="4DLLM Runner",
            font=("Segoe UI", 16, "bold"),
            bg=COLORS["bg_tertiary"],
            fg=COLORS["accent"],
        )
        title.pack(pady=15)
        
        # Content frame (no scrolling - just use pack with proper organization)
        content = tk.Frame(parent, bg=COLORS["bg_secondary"])
        
        # Use a scrollable frame only if needed
        canvas_container = tk.Frame(parent, bg=COLORS["bg_secondary"])
        canvas_container.pack(fill="both", expand=True)
        
        canvas = tk.Canvas(canvas_container, bg=COLORS["bg_secondary"], highlightthickness=0)
        scrollbar = ttk.Scrollbar(canvas_container, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg=COLORS["bg_secondary"])
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas_window = canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        def configure_canvas_width(event):
            canvas_width = event.width
            canvas.itemconfig(canvas_window, width=canvas_width)
        
        canvas.bind('<Configure>', configure_canvas_width)
        
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Use scrollable_frame as content
        content = scrollable_frame
        
        # File Selection
        file_frame = ttk.LabelFrame(content, text="📁 4DLLM File", padding=12)
        file_frame.pack(fill="x", padx=10, pady=8)
        
        self.file_label = tk.Label(
            file_frame,
            text="No file selected",
            font=("Segoe UI", 9),
            bg=COLORS["bg_secondary"],
            fg=COLORS["fg_secondary"],
            wraplength=350,
            anchor="w",
        )
        self.file_label.pack(fill="x", pady=5)
        
        tk.Button(
            file_frame,
            text="📂 Browse 4DLLM",
            command=self.browse_file,
            bg=COLORS["accent"],
            fg=COLORS["fg_primary"],
            font=("Segoe UI", 9, "bold"),
            relief="flat",
            padx=15,
            pady=6,
            cursor="hand2",
        ).pack(fill="x", pady=3)
        
        # Model Info (compact)
        info_frame = ttk.LabelFrame(content, text="ℹ️ Model Information", padding=10)
        info_frame.pack(fill="both", expand=True, padx=10, pady=6)
        
        self.info_text = scrolledtext.ScrolledText(
            info_frame,
            height=8,
            font=("Consolas", 8),
            bg=COLORS["bg_tertiary"],
            fg=COLORS["fg_primary"],
            wrap=tk.WORD,
            relief="flat",
            borderwidth=0,
            padx=8,
            pady=6,
        )
        self.info_text.pack(fill="both", expand=True)
        self.info_text.config(state=tk.DISABLED)
        
        # Configuration (more compact)
        config_frame = ttk.LabelFrame(content, text="⚙️ Configuration", padding=10)
        config_frame.pack(fill="x", padx=10, pady=6)
        
        # Backend
        tk.Label(
            config_frame, text="Backend:", font=("Segoe UI", 9),
            bg=COLORS["bg_secondary"], fg=COLORS["fg_primary"]
        ).grid(row=0, column=0, sticky="w", padx=5, pady=4)
        
        self.backend_var = tk.StringVar(value="llama_cpp")
        backend_frame = tk.Frame(config_frame, bg=COLORS["bg_secondary"])
        backend_frame.grid(row=0, column=1, sticky="w", padx=5, pady=4)
        
        tk.Radiobutton(
            backend_frame, text="llama_cpp", variable=self.backend_var, value="llama_cpp",
            bg=COLORS["bg_secondary"], fg=COLORS["fg_primary"], selectcolor=COLORS["bg_tertiary"],
            activebackground=COLORS["bg_secondary"], font=("Segoe UI", 8),
        ).pack(side="left", padx=3)
        
        tk.Radiobutton(
            backend_frame, text="llama_cli", variable=self.backend_var, value="llama_cli",
            bg=COLORS["bg_secondary"], fg=COLORS["fg_primary"], selectcolor=COLORS["bg_tertiary"],
            activebackground=COLORS["bg_secondary"], font=("Segoe UI", 8),
        ).pack(side="left", padx=3)
        
        # Parameters grid
        params = [
            ("Context:", "n_ctx_var", "4096"),
            ("Threads:", "threads_var", "4"),
            ("GPU Layers:", "gpu_layers_var", "0"),
            ("Max Tokens:", "max_tokens_var", "256"),
            ("Temperature:", "temp_var", "0.7"),
        ]
        
        for i, (label, attr, default) in enumerate(params):
            tk.Label(
                config_frame, text=label, font=("Segoe UI", 9),
                bg=COLORS["bg_secondary"], fg=COLORS["fg_primary"]
            ).grid(row=i+1, column=0, sticky="w", padx=5, pady=4)
            
            var = tk.StringVar(value=default)
            setattr(self, attr, var)
            tk.Entry(
                config_frame, textvariable=var, width=12,
                bg=COLORS["bg_tertiary"], fg=COLORS["fg_primary"],
                insertbackground=COLORS["fg_primary"], relief="flat", font=("Consolas", 9)
            ).grid(row=i+1, column=1, sticky="w", padx=5, pady=4)
        
        # Options
        self.unsafe_modules_var = tk.BooleanVar(value=True)
        tk.Checkbutton(
            config_frame, text="Unsafe Modules", variable=self.unsafe_modules_var,
            bg=COLORS["bg_secondary"], fg=COLORS["fg_primary"],
            selectcolor=COLORS["bg_tertiary"], activebackground=COLORS["bg_secondary"],
            font=("Segoe UI", 9),
        ).grid(row=len(params)+1, column=0, columnspan=2, sticky="w", padx=5, pady=4)
        
        # Additional Modules (more compact)
        modules_frame = ttk.LabelFrame(content, text="📦 Additional Modules", padding=10)
        modules_frame.pack(fill="both", expand=True, padx=10, pady=6)
        
        modules_list_frame = tk.Frame(modules_frame, bg=COLORS["bg_secondary"])
        modules_list_frame.pack(fill="both", expand=True, pady=4)
        
        self.modules_listbox = tk.Listbox(
            modules_list_frame,
            bg=COLORS["bg_tertiary"],
            fg=COLORS["fg_primary"],
            selectbackground=COLORS["accent"],
            selectforeground=COLORS["fg_primary"],
            font=("Consolas", 8),
            relief="flat",
            borderwidth=0,
            height=4,
        )
        self.modules_listbox.pack(fill="both", expand=True)
        
        modules_btn_frame = tk.Frame(modules_frame, bg=COLORS["bg_secondary"])
        modules_btn_frame.pack(fill="x", pady=4)
        
        tk.Button(
            modules_btn_frame,
            text="+ Add Module",
            command=self.add_module,
            bg=COLORS["accent"],
            fg=COLORS["fg_primary"],
            font=("Segoe UI", 8),
            relief="flat",
            padx=10,
            pady=4,
            cursor="hand2",
        ).pack(side="left", padx=2, fill="x", expand=True)
        
        tk.Button(
            modules_btn_frame,
            text="− Remove",
            command=self.remove_module,
            bg=COLORS["error"],
            fg=COLORS["fg_primary"],
            font=("Segoe UI", 8),
            relief="flat",
            padx=10,
            pady=4,
            cursor="hand2",
        ).pack(side="left", padx=2, fill="x", expand=True)
        
        # Control Buttons (more compact)
        controls_frame = tk.Frame(content, bg=COLORS["bg_secondary"])
        controls_frame.pack(fill="x", padx=10, pady=6)
        
        self.run_btn = tk.Button(
            controls_frame,
            text="▶ Start",
            command=self.start_runner,
            bg=COLORS["success"],
            fg=COLORS["bg_primary"],
            font=("Segoe UI", 10, "bold"),
            relief="flat",
            padx=15,
            pady=10,
            cursor="hand2",
            state=tk.DISABLED,
        )
        self.run_btn.pack(fill="x", pady=2)
        
        self.stop_btn = tk.Button(
            controls_frame,
            text="■ Stop",
            command=self.stop_runner,
            bg=COLORS["error"],
            fg=COLORS["fg_primary"],
            font=("Segoe UI", 10, "bold"),
            relief="flat",
            padx=15,
            pady=10,
            cursor="hand2",
            state=tk.DISABLED,
        )
        self.stop_btn.pack(fill="x", pady=2)
        
        tk.Button(
            controls_frame,
            text="🗑️ Clear Terminal",
            command=self.clear_terminal,
            bg=COLORS["bg_tertiary"],
            fg=COLORS["fg_primary"],
            font=("Segoe UI", 8),
            relief="flat",
            padx=12,
            pady=6,
            cursor="hand2",
        ).pack(fill="x", pady=2)
    
    def _setup_right_panel(self, parent: tk.Frame) -> None:
        # Terminal header
        terminal_header = tk.Frame(parent, bg=COLORS["bg_tertiary"], height=40)
        terminal_header.pack(fill="x")
        terminal_header.pack_propagate(False)
        
        tk.Label(
            terminal_header,
            text="📺 Integrated Terminal",
            font=("Segoe UI", 12, "bold"),
            bg=COLORS["bg_tertiary"],
            fg=COLORS["accent"],
        ).pack(side="left", padx=15, pady=8)
        
        # Status indicator
        self.status_indicator = tk.Label(
            terminal_header,
            text="●",
            font=("Segoe UI", 14),
            bg=COLORS["bg_tertiary"],
            fg=COLORS["fg_tertiary"],
        )
        self.status_indicator.pack(side="right", padx=15, pady=8)
        
        self.status_label = tk.Label(
            terminal_header,
            text="Ready",
            font=("Segoe UI", 9),
            bg=COLORS["bg_tertiary"],
            fg=COLORS["fg_secondary"],
        )
        self.status_label.pack(side="right", padx=5, pady=8)
        
        # Terminal widget (adjusted height)
        self.terminal = IntegratedTerminal(parent, height=30)
        self.terminal.pack(fill="both", expand=True, padx=2, pady=2)
        self.terminal.write("4DLLM Runner Terminal\n", "info")
        self.terminal.write("Ready to run 4DLLM models.\n", "info")
        self.terminal.write("Select a .4dllm file and click 'Start' to begin.\n\n", "output")
        self.terminal.write_prompt()
    
    def browse_file(self) -> None:
        """Browse for 4DLLM file"""
        fp = filedialog.askopenfilename(
            title="Select 4DLLM File",
            filetypes=[("4DLLM files", "*.4dllm"), ("All files", "*.*")],
            initialdir=str(Path.home()),
        )
        if not fp:
            return
        
        self.current_file = Path(fp)
        self.load_file_info()
    
    def load_file_info(self) -> None:
        """Load file information"""
        if not self.current_file:
            return
        
        self.file_info = read_4dllm_info(self.current_file)
        
        if not self.file_info["valid"]:
            messagebox.showerror("Error", f"Failed to read file:\n{self.file_info.get('error')}")
            self.file_label.config(text="Invalid file", fg=COLORS["error"])
            self.run_btn.config(state=tk.DISABLED)
            return
        
        file_name = self.current_file.name
        file_size_mb = self.file_info["file_size"] / (1024 * 1024)
        self.file_label.config(
            text=f"✓ {file_name}\n({file_size_mb:.2f} MB)",
            fg=COLORS["success"]
        )
        
        self._update_info_display()
        self.run_btn.config(state=tk.NORMAL)
        self.update_status("Ready to run", "ready")
    
    def _update_info_display(self) -> None:
        """Update model information display"""
        self.info_text.config(state=tk.NORMAL)
        self.info_text.delete(1.0, tk.END)
        
        info = self.file_info
        lines = []
        
        meta = info.get("metadata", {})
        if meta.get("name"):
            lines.append(f"Name: {meta['name']}")
        if meta.get("description"):
            lines.append(f"Description: {meta['description']}")
        
        lines.append(f"\nModules: {info['module_count']}")
        modules_reg = meta.get("modules", {})
        if modules_reg:
            all_mods = modules_reg.get("all_modules", [])
            if all_mods:
                lines.append(f"Available: {', '.join(all_mods[:10])}")
                if len(all_mods) > 10:
                    lines.append(f"... +{len(all_mods) - 10} more")
        
        self.info_text.insert(1.0, "\n".join(lines))
        self.info_text.config(state=tk.DISABLED)
    
    def add_module(self) -> None:
        """Add additional Python module"""
        fp = filedialog.askopenfilename(
            title="Select Python Module",
            filetypes=[("Python files", "*.py"), ("All files", "*.*")],
            initialdir=str(Path(__file__).parent / "modules"),
        )
        if not fp:
            return
        
        mod_path = Path(fp)
        try:
            content = mod_path.read_text(encoding="utf-8")
            # Simple import parsing
            imports = re.findall(r'^import\s+(\w+)|^from\s+(\w+)', content, re.MULTILINE)
            imports = [imp[0] or imp[1] for imp in imports if imp[0] or imp[1]]
            
            mod_info = ModuleInfo(
                name=mod_path.name,
                path=mod_path,
                imports=imports,
            )
            self.additional_modules.append(mod_info)
            self.modules_listbox.insert(tk.END, mod_path.name)
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load module:\n{e}")
    
    def remove_module(self) -> None:
        """Remove selected module"""
        selection = self.modules_listbox.curselection()
        if selection:
            idx = selection[0]
            self.modules_listbox.delete(idx)
            self.additional_modules.pop(idx)
    
    def start_runner(self) -> None:
        """Start the 4DLLM runner"""
        if not self.current_file or not self.file_info["valid"]:
            messagebox.showwarning("Warning", "Please select a valid 4DLLM file first.")
            return
        
        if self.terminal.running:
            messagebox.showinfo("Info", "A process is already running. Stop it first.")
            return
        
        # Build command
        runner_script = Path(__file__).parent / "4dllm_runner.py"
        if not runner_script.exists():
            messagebox.showerror("Error", "Runner script not found!")
            return
        
        cmd = [
            sys.executable,
            str(runner_script),
            "--file", str(self.current_file.resolve()),
            "--backend", self.backend_var.get(),
            "--n-ctx", self.n_ctx_var.get(),
            "--threads", self.threads_var.get(),
            "--gpu-layers", self.gpu_layers_var.get(),
            "--max-tokens", self.max_tokens_var.get(),
            "--temp", self.temp_var.get(),
        ]
        
        if self.unsafe_modules_var.get():
            cmd.append("--unsafe-modules")
        
        # Add additional modules if any
        if self.additional_modules:
            mod_paths = [str(m.path.resolve()) for m in self.additional_modules if m.enabled]
            if mod_paths:
                # Note: This would require runner support for --additional-modules
                # For now, we'll just log it
                self.terminal.write(f"\n[Additional modules: {', '.join([m.name for m in self.additional_modules])}]\n", "info")
        
        # Start in terminal
        env = os.environ.copy()
        self.terminal.start_process(cmd, cwd=str(Path(__file__).parent), env=env)
        
        self.run_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)
        self.update_status("Running", "running")
    
    def stop_runner(self) -> None:
        """Stop the runner"""
        self.terminal.stop_process()
        self.run_btn.config(state=tk.NORMAL)
        self.stop_btn.config(state=tk.DISABLED)
        self.update_status("Stopped", "stopped")
    
    def clear_terminal(self) -> None:
        """Clear terminal"""
        self.terminal.delete(1.0, "end")
        self.terminal.write_prompt()
    
    def update_status(self, text: str, state: str = "ready") -> None:
        """Update status indicator"""
        self.status_label.config(text=text)
        
        colors = {
            "ready": COLORS["fg_tertiary"],
            "running": COLORS["success"],
            "stopped": COLORS["error"],
            "error": COLORS["error"],
        }
        self.status_indicator.config(fg=colors.get(state, COLORS["fg_tertiary"]))


def main() -> int:
    """Main entry point"""
    ap = argparse.ArgumentParser()
    ap.add_argument("--classic", action="store_true", help="Use classic Tkinter UI")
    args = ap.parse_args()
    if HAS_CTK and not args.classic:
        app = PremiumStudio()
        app.mainloop()
        return 0
    root = tk.Tk()
    app = FourDLLMRunnerGUI(root)
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
