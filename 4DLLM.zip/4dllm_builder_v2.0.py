#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Copyright Daniel Harding - RomanAILabs
Credits: Built with assistance from OpenAI (GPT-5.2 Thinking)

4DLLM Builder (v2) — GUI + Modules Folder Auto-Pack + Runner-Friendly TOC

What this version adds over the original:
- Auto-loads scripts from ./modules/ (lowercase) next to this file (your “dump folder” workflow)
- Streams GGUF bytes into the output file (does NOT read entire model into RAM)
- Writes a footer TOC (index) + CRC32 per section for robust runner parsing/validation
- Stores both compressed and uncompressed sizes per section
- Safer "Math Enhancer" template (AST-based, no eval)

File Format (4DLLM v2):
- Header:
  magic '4DLL' (4 bytes)
  version u32 LE
  reserved/padding to 64 bytes
- Sections (streamed sequentially):
  [SectionHeader][ExtraData][Payload]
- Footer TOC:
  magic 'TOC1' (4 bytes)
  toc_version u32
  section_count u32
  [TOCEntry...]
  footer_crc32 u32 (CRC over TOC bytes excluding this crc itself)

SectionHeader struct (LE):
  type       u8
  flags      u8  (bit0 = compressed_zlib)
  reserved   u16
  size_c     u64 (payload bytes written)
  size_u     u64 (original bytes before compression)
  extra_sz   u32
  crc32      u32 (CRC32 of *uncompressed* payload bytes)

TOCEntry struct (LE):
  type       u8
  flags      u8
  reserved   u16
  offset     u64 (file offset of SectionHeader)
  size_c     u64
  size_u     u64
  extra_sz   u32
  crc32      u32
"""

from __future__ import annotations

import ast
import json
import logging
import os
import struct
import time
import zlib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Any, Optional, List, Tuple, Set

import tkinter as tk
from tkinter import ttk, filedialog, messagebox


# ---------------- Logging ----------------
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("4dllm_builder")


# ---------------- 4DLLM Constants ----------------
FOURDLLM_MAGIC = b"4DLL"
FOURDLLM_VERSION = 2
FOURDLLM_HEADER_SIZE = 64

TOC_MAGIC = b"TOC1"
TOC_VERSION = 1

# Section Types
SECTION_GGUF_DATA = 0x01
SECTION_PYTHON_SCRIPT = 0x02
SECTION_METADATA = 0x03
SECTION_SCRIPT_CONFIG = 0x04
SECTION_MANIFEST = 0x05

# Flags
FLAG_COMPRESSED_ZLIB = 0x01

# Structs
SECTION_HDR_STRUCT = struct.Struct("<BB2xQQII")   # type, flags, size_c, size_u, extra_sz, crc32
TOC_HDR_STRUCT = struct.Struct("<4sII")          # magic, toc_version, section_count
TOC_ENTRY_STRUCT = struct.Struct("<BB2xQQQII")   # type, flags, offset, size_c, size_u, extra_sz, crc32


# ---------------- UI Theme ----------------
COLORS = {
    "bg_primary": "#1e1e1e",
    "bg_secondary": "#2d2d2d",
    "bg_tertiary": "#3a3a3a",
    "fg_primary": "#ffffff",
    "fg_secondary": "#cccccc",
    "accent": "#0078d4",
    "accent_hover": "#106ebe",
    "success": "#00ff00",
    "warning": "#ffaa00",
    "error": "#ff4444",
    "border": "#3a3a3a",
}

# Modules folder name (your requirement)
MODULES_DIRNAME = "modules"  # lowercase


def utc_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


# ---------------- Module Validation & Auto-Correction ----------------

def validate_and_fix_script(content: str, script_name: str) -> Tuple[str, List[str]]:
    """
    Validates and auto-fixes common issues in scripts that might conflict
    with module awareness injection.
    Returns: (fixed_content, warnings_list)
    """
    warnings = []
    fixed = content
    lines = fixed.split('\n')
    
    # 1. Check for __future__ imports in wrong positions
    future_imports = []
    future_import_indices = []
    seen_other_code = False
    
    for i, line in enumerate(lines):
        stripped = line.strip()
        
        # Skip shebang and docstrings at start
        if i == 0 and stripped.startswith('#!'):
            continue
        if stripped.startswith('"""') or stripped.startswith("'''"):
            continue
        
        # Track __future__ imports
        if stripped.startswith('from __future__'):
            if seen_other_code:
                warnings.append(f"Line {i+1}: 'from __future__' import found after other code. Moving to top.")
                future_imports.append(line)
                future_import_indices.append(i)
            else:
                # Already in correct position
                pass
        elif stripped and not stripped.startswith('#') and not stripped.startswith('"""') and not stripped.startswith("'''"):
            seen_other_code = True
    
    # If we found __future__ imports in wrong positions, move them
    if future_import_indices:
        # Remove from wrong positions
        for idx in reversed(future_import_indices):
            lines.pop(idx)
        
        # Find insertion point (after shebang/docstring, before other imports)
        insert_pos = 0
        for i, line in enumerate(lines):
            stripped = line.strip()
            if i == 0 and stripped.startswith('#!'):
                insert_pos = i + 1
                continue
            if stripped.startswith('"""') or stripped.startswith("'''"):
                # Find end of docstring
                quote_type = '"""' if stripped.startswith('"""') else "'''"
                if stripped.count(quote_type) >= 2:
                    insert_pos = i + 1
                else:
                    # Multi-line docstring
                    for j in range(i + 1, len(lines)):
                        if quote_type in lines[j]:
                            insert_pos = j + 1
                            break
                continue
            if stripped and not stripped.startswith('#'):
                break
            insert_pos = i + 1
        
        # Insert at correct position
        for future_import in reversed(future_imports):
            lines.insert(insert_pos, future_import)
        
        fixed = '\n'.join(lines)
        warnings.append(f"Fixed: Moved {len(future_imports)} 'from __future__' import(s) to correct position.")
    
    # 2. Validate syntax
    try:
        compile(fixed, script_name, "exec")
    except SyntaxError as e:
        warnings.append(f"Syntax error at line {e.lineno}: {e.msg}")
        
        # Try to auto-fix common syntax issues
        # Remove trailing whitespace that might cause issues
        fixed_lines = fixed.split('\n')
        for i, line in enumerate(fixed_lines):
            fixed_lines[i] = line.rstrip()
        fixed = '\n'.join(fixed_lines)
        
        # Try compiling again
        try:
            compile(fixed, script_name, "exec")
            warnings.append("Fixed: Removed trailing whitespace that caused syntax error.")
        except SyntaxError:
            warnings.append("Warning: Could not auto-fix syntax error. Manual review needed.")
    
    # 3. Check for problematic patterns
    if '__file__' in fixed and 'injected' in fixed.lower():
        warnings.append("Note: Script uses __file__ which may reference injected code.")
    
    # 4. Ensure proper line endings
    if fixed and not fixed.endswith('\n'):
        fixed += '\n'
        warnings.append("Fixed: Added missing newline at end of file.")
    
    return fixed, warnings


# ---------------- Module Awareness Functions ----------------

def parse_imports_from_script(content: str) -> List[str]:
    """
    Parse all imports from a Python script using AST.
    Returns a list of module names (e.g., ['cv2', 'numpy', 'deepface', 'tkinter.messagebox'])
    """
    imports: Set[str] = set()
    try:
        tree = ast.parse(content, mode="exec")
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    imports.add(alias.name.split('.')[0])  # get top-level module
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    imports.add(node.module.split('.')[0])  # get top-level module
                # Also track the full import path for from...import
                if node.module:
                    imports.add(node.module)
    except SyntaxError:
        # If parsing fails, return empty list - syntax check will catch it later
        pass
    except Exception:
        pass
    return sorted(list(imports))


def create_module_awareness_code(
    script_name: str,
    script_imports: List[str],
    all_available_modules: Dict[str, Any]
) -> str:
    """
    Creates code that injects module awareness into a script.
    This makes the script 'self-aware' of what modules it has access to.
    """
    modules_json = json.dumps(all_available_modules, indent=2)
    
    awareness_code = f'''
# ========== 4DLLM Module Awareness Injection ==========
# This script is aware of its modules and dependencies
# Generated automatically by 4DLLM Builder v2

__4dllm_script_name__ = {repr(script_name)}
__4dllm_script_imports__ = {repr(script_imports)}
__4dllm_available_modules__ = {modules_json}

def __4dllm_get_modules__():
    """
    Returns information about modules available to this script.
    Returns: dict with 'script_name', 'imports', 'available_modules'
    """
    return {{
        'script_name': __4dllm_script_name__,
        'my_imports': __4dllm_script_imports__,
        'available_modules': __4dllm_available_modules__,
        'has_module': lambda name: name in __4dllm_available_modules__.get('all_modules', [])
    }}

def __4dllm_check_module__(module_name: str) -> bool:
    """Check if a specific module is available in this 4DLLM build."""
    all_mods = __4dllm_available_modules__.get('all_modules', [])
    return module_name in all_mods or any(module_name in mod for mod in all_mods)

# Make module info accessible via __modules__ variable
__modules__ = __4dllm_get_modules__()

# ========== End Module Awareness Injection ==========

'''
    return awareness_code


def inject_module_awareness(script: ScriptItem, all_modules: Dict[str, Any]) -> str:
    """
    Injects module awareness code into a script.
    Respects 'from __future__' imports which must be at the beginning.
    Returns the modified script content.
    """
    awareness_code = create_module_awareness_code(
        script.name,
        script.imports,
        all_modules
    )
    
    content = script.content
    
    # Check for __future__ imports - they must be at the very beginning
    # Python allows: shebang, module docstring, then __future__ imports, then everything else
    lines = content.split('\n')
    future_imports_end = 0
    seen_first_non_blank = False
    in_future_imports = False
    docstring_open = False
    docstring_type = None
    
    for i, line in enumerate(lines):
        stripped = line.strip()
        orig_stripped = stripped
        
        # Handle shebang (must be first line)
        if i == 0 and stripped.startswith('#!'):
            future_imports_end = i + 1
            continue
        
        # Handle docstrings (can come before imports)
        if not docstring_open:
            if stripped.startswith('"""') or stripped.startswith("'''"):
                docstring_type = '"""' if stripped.startswith('"""') else "'''"
                docstring_open = True
                # If it's a one-liner docstring
                if stripped.count(docstring_type) >= 2:
                    docstring_open = False
                continue
        else:
            # Inside docstring
            if docstring_type in stripped:
                docstring_open = False
            continue
        
        # Skip blank lines (but track if we've seen content)
        if not stripped:
            if not in_future_imports:
                continue
            # Blank line after future imports is OK
            continue
        
        # Skip comments (unless after future imports have started)
        if stripped.startswith('#') and not in_future_imports:
            continue
        
        # Check for __future__ import
        if stripped.startswith('from __future__'):
            in_future_imports = True
            seen_first_non_blank = True
            future_imports_end = i + 1
            continue
        
        # If we're in a future import block and hit something else
        if in_future_imports:
            # Comments are OK after future imports
            if stripped.startswith('#'):
                future_imports_end = i + 1
                continue
            # This is the end of future imports block
            break
        
        # If we've seen non-future content, we're past where future imports can be
        if seen_first_non_blank:
            break
        
        # Regular import or code - future imports can't come after this
        if not in_future_imports:
            seen_first_non_blank = True
            break
    
    # Insert awareness code after __future__ imports
    if future_imports_end > 0:
        before = '\n'.join(lines[:future_imports_end])
        after = '\n'.join(lines[future_imports_end:])
        return before + '\n\n' + awareness_code + '\n' + after
    else:
        # No __future__ imports, insert at beginning
        return awareness_code + '\n' + content


# ---------------- Safer Built-in Templates ----------------
SAFE_MATH_TEMPLATE = r'''# Math Enhancement Script (SAFE AST)
# No eval(). Only basic arithmetic: + - * / ** % ( ) and numbers.
import ast
import re

_ALLOWED_NODES = (
    ast.Expression, ast.BinOp, ast.UnaryOp, ast.Num, ast.Constant,
    ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Pow, ast.Mod,
    ast.UAdd, ast.USub, ast.FloorDiv,
    ast.Load, ast.Tuple
)

def _safe_eval_expr(expr: str):
    expr = expr.strip()
    if not expr:
        return None
    # quick reject: only allow math symbols + digits + dots + spaces
    if not re.match(r'^[0-9+\-*/().%\s**]+$', expr):
        return None
    try:
        tree = ast.parse(expr, mode="eval")
    except Exception:
        return None

    for node in ast.walk(tree):
        if not isinstance(node, _ALLOWED_NODES):
            return None
        # reject names/calls/attributes etc
        if isinstance(node, (ast.Name, ast.Call, ast.Attribute, ast.Subscript, ast.Lambda)):
            return None

    try:
        # Evaluate using Python's eval on the already-sanitized AST
        code = compile(tree, "<safe-math>", "eval")
        return eval(code, {"__builtins__": {}}, {})
    except Exception:
        return None

if 'input' in context:
    text = context.get('input', '')
    patterns = [
        r'what is\s+([0-9+\-*/().%\s]+)\?',
        r'calculate\s+([0-9+\-*/().%\s]+)',
        r'([0-9+\-*/().%\s]+)\s*=\s*\?',
    ]
    for pattern in patterns:
        for match in re.finditer(pattern, text, re.IGNORECASE):
            expr = match.group(1).strip()
            val = _safe_eval_expr(expr)
            if val is not None:
                text = text.replace(match.group(0), f"{match.group(0)} → {val}")
    context['input'] = text
    result = {'enhanced': True, 'type': 'math_safe'}
'''

CODE_ANALYZER_TEMPLATE = r'''# Code Analysis Script
import ast
import re

def analyze_code(text: str):
    code_blocks = re.findall(r'```(?:python|py)?\n(.*?)```', text, re.DOTALL)
    analysis = {'code_blocks': len(code_blocks), 'functions': [], 'classes': []}
    for code in code_blocks:
        try:
            tree = ast.parse(code)
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    analysis['functions'].append(node.name)
                if isinstance(node, ast.ClassDef):
                    analysis['classes'].append(node.name)
        except Exception:
            pass
    return analysis

if 'input' in context:
    analysis = analyze_code(context.get('input', ''))
    context['code_analysis'] = analysis
    result = {'enhanced': True, 'type': 'code', 'analysis': analysis}
'''

REASONING_CHAIN_TEMPLATE = r'''# Reasoning Enhancement Script
def add_reasoning(text: str):
    return f"""Let's think step by step:
1. Understand the problem
2. Break it down into components
3. Analyze each component
4. Synthesize the solution
5. Verify the answer

Problem: {text}
"""

if 'input' in context:
    context['input'] = add_reasoning(context.get('input', ''))
    result = {'enhanced': True, 'type': 'reasoning'}
'''

SCRIPT_TEMPLATES = {
    "Math Enhancer (SAFE)": SAFE_MATH_TEMPLATE,
    "Code Analyzer": CODE_ANALYZER_TEMPLATE,
    "Reasoning Chain": REASONING_CHAIN_TEMPLATE,
}


@dataclass
class ScriptItem:
    name: str
    content: str
    description: str = ""
    priority: int = 0
    enabled: bool = True
    source_path: str = ""   # optional, for UI info
    imports: List[str] = None  # parsed imports
    injected_content: str = ""  # content with module awareness injected
    
    def __post_init__(self):
        if self.imports is None:
            self.imports = []
        if not self.injected_content:
            self.injected_content = self.content


@dataclass
class SectionRecord:
    section_type: int
    flags: int
    offset: int
    size_c: int
    size_u: int
    extra_sz: int
    crc32: int
    sha256: Optional[str] = None


@dataclass
class _SmallSection:
    entry: SectionRecord
    extra: Dict[str, Any]
    payload_c: bytes
    payload_u: Optional[bytes] = None


# ---------------- Builder-side Validation (keeps runner happy) ----------------

def _val_read_exact(f, n: int) -> bytes:
    b = f.read(n)
    if len(b) != n:
        raise EOFError(f"Expected {n} bytes, got {len(b)}")
    return b


def _val_crc32_bytes(b: bytes) -> int:
    return zlib.crc32(b) & 0xFFFFFFFF


def _sha256_bytes(b: bytes) -> str:
    import hashlib
    return hashlib.sha256(b).hexdigest()


def _val_safe_json_loads(b: bytes, default: Any) -> Any:
    try:
        return json.loads(b.decode("utf-8", errors="replace"))
    except Exception:
        return default


def _find_toc_offset(path: Path, scan_back_bytes: int = 4 * 1024 * 1024) -> int:
    size = path.stat().st_size
    start = max(0, size - scan_back_bytes)
    with open(path, "rb") as f:
        f.seek(start)
        chunk = f.read(size - start)
    idx = chunk.rfind(TOC_MAGIC)
    if idx < 0:
        raise ValueError("TOC not found (TOC1). File may not be a v2 4DLLM.")
    return start + idx


def _read_and_validate_toc(path: Path) -> Tuple[List[SectionRecord], int]:
    toc_offset = _find_toc_offset(path)
    with open(path, "rb") as f:
        f.seek(toc_offset)
        hdr = _val_read_exact(f, TOC_HDR_STRUCT.size)
        magic, toc_ver, count = TOC_HDR_STRUCT.unpack(hdr)
        if magic != TOC_MAGIC:
            raise ValueError("Bad TOC magic")
        if toc_ver != TOC_VERSION:
            raise ValueError(f"Unsupported TOC version: {toc_ver}")

        entries_bytes = _val_read_exact(f, TOC_ENTRY_STRUCT.size * count)
        footer_crc = struct.unpack("<I", _val_read_exact(f, 4))[0]

        computed = _val_crc32_bytes(hdr + entries_bytes)
        if computed != footer_crc:
            raise ValueError(f"TOC CRC mismatch: expected {footer_crc:08x}, got {computed:08x}")

        entries: List[SectionRecord] = []
        for i in range(count):
            chunk = entries_bytes[i * TOC_ENTRY_STRUCT.size:(i + 1) * TOC_ENTRY_STRUCT.size]
            stype, flags, off, size_c, size_u, extra_sz, crc_u = TOC_ENTRY_STRUCT.unpack(chunk)
            entries.append(SectionRecord(stype, flags, off, size_c, size_u, extra_sz, crc_u))

        return entries, toc_offset


def _read_section_small(path: Path, entry: SectionRecord) -> _SmallSection:
    with open(path, "rb") as f:
        f.seek(entry.offset)
        hdr = _val_read_exact(f, SECTION_HDR_STRUCT.size)
        stype, flags, size_c, size_u, extra_sz, crc_u = SECTION_HDR_STRUCT.unpack(hdr)

        if stype != entry.section_type or flags != entry.flags:
            raise ValueError("Section header mismatch vs TOC (type/flags).")
        if size_c != entry.size_c or size_u != entry.size_u:
            raise ValueError("Section header mismatch vs TOC (sizes).")
        if extra_sz != entry.extra_sz or crc_u != entry.crc32:
            raise ValueError("Section header mismatch vs TOC (extra/crc).")

        extra_bytes = _val_read_exact(f, extra_sz) if extra_sz else b"{}"
        extra = _val_safe_json_loads(extra_bytes, default={})
        payload_c = _val_read_exact(f, size_c) if size_c else b""
        return _SmallSection(entry=entry, extra=extra, payload_c=payload_c)


def _decode_and_validate_section(section: _SmallSection) -> bytes:
    if section.payload_u is not None:
        return section.payload_u

    data = section.payload_c
    if section.entry.flags & FLAG_COMPRESSED_ZLIB:
        data = zlib.decompress(data)

    c = zlib.crc32(data) & 0xFFFFFFFF
    if c != section.entry.crc32:
        raise ValueError(
            f"CRC mismatch for section {section.entry.section_type:#x}: "
            f"expected {section.entry.crc32:08x}, got {c:08x}"
        )

    if len(data) != section.entry.size_u:
        raise ValueError(
            f"Size_u mismatch after decode: expected {section.entry.size_u}, got {len(data)}"
        )

    section.payload_u = data
    return data


def validate_built_file(path: Path) -> Dict[str, Any]:
    """
    Lightweight validation to ensure the freshly built file will load in the runner.
    Checks header/version, TOC CRC, per-section CRC/size, and script count alignment.
    Returns a small summary dict.
    """
    with open(path, "rb") as f:
        magic = _val_read_exact(f, 4)
        if magic != FOURDLLM_MAGIC:
            raise ValueError("Not a 4DLLM file (bad magic).")
        ver = struct.unpack("<I", _val_read_exact(f, 4))[0]
        if ver != FOURDLLM_VERSION:
            raise ValueError(f"Unsupported 4DLLM version: {ver} (expected {FOURDLLM_VERSION})")

    entries, toc_offset = _read_and_validate_toc(path)
    gguf_entries = [e for e in entries if e.section_type == SECTION_GGUF_DATA]
    if not gguf_entries:
        raise ValueError("No GGUF section found.")

    metadata: Dict[str, Any] = {}
    script_config: Dict[str, Any] = {}
    script_sections = 0

    for ent in entries:
        if ent.section_type == SECTION_METADATA:
            sec = _read_section_small(path, ent)
            metadata = _val_safe_json_loads(_decode_and_validate_section(sec), default={})
        elif ent.section_type == SECTION_SCRIPT_CONFIG:
            sec = _read_section_small(path, ent)
            script_config = _val_safe_json_loads(_decode_and_validate_section(sec), default={})
        elif ent.section_type == SECTION_PYTHON_SCRIPT:
            sec = _read_section_small(path, ent)
            _decode_and_validate_section(sec)
            script_sections += 1
        elif ent.section_type == SECTION_MANIFEST:
            sec = _read_section_small(path, ent)
            _val_safe_json_loads(_decode_and_validate_section(sec), default={})

    expected_scripts = script_config.get("script_count")
    if isinstance(expected_scripts, int) and expected_scripts != script_sections:
        raise ValueError(
            f"script_count mismatch: config={expected_scripts}, sections={script_sections}"
        )

    return {
        "toc_offset": toc_offset,
        "section_count": len(entries),
        "script_sections": script_sections,
        "script_count_declared": expected_scripts,
        "metadata_keys": sorted(list(metadata.keys())),
        "script_config_keys": sorted(list(script_config.keys())),
    }


class FourDLLMBuilderV2:
    """
    Builder that writes a runner-friendly .4dllm (v2) with a footer TOC.
    Key: streams GGUF file, no huge RAM load.
    """

    def __init__(self, gguf_file: str):
        self.gguf_file = Path(gguf_file)
        if not self.gguf_file.exists():
            raise FileNotFoundError(f"GGUF file not found: {gguf_file}")
        self.scripts: List[ScriptItem] = []
        self.metadata: Dict[str, Any] = {}
        self.module_registry: Dict[str, Any] = {}  # tracks all modules across scripts

    def add_script(self, item: ScriptItem) -> None:
        # Parse imports if not already done
        if not item.imports:
            item.imports = parse_imports_from_script(item.content)
        self.scripts.append(item)
    
    def _build_module_registry(self) -> Dict[str, Any]:
        """
        Builds a comprehensive registry of all modules used across all scripts.
        This makes scripts aware of what modules are available in the 4DLLM.
        """
        all_modules: Set[str] = set()
        script_modules: Dict[str, List[str]] = {}
        
        for script in self.scripts:
            if not script.enabled:
                continue
            # Ensure imports are parsed
            if not script.imports:
                script.imports = parse_imports_from_script(script.content)
            script_modules[script.name] = script.imports
            all_modules.update(script.imports)
        
        return {
            "all_modules": sorted(list(all_modules)),
            "modules_by_script": script_modules,
            "module_count": len(all_modules),
            "script_count": len(script_modules),
        }

    def build(self, output_path: str, compress_scripts: bool = True, compress_metadata: bool = True) -> str:
        out = Path(output_path)
        tmp_out = out.with_suffix(out.suffix + ".tmp")

        # Sort scripts by priority (desc) then name
        self.scripts.sort(key=lambda s: (s.priority, s.name), reverse=True)

        # Build module registry BEFORE injecting awareness
        self.module_registry = self._build_module_registry()
        
        # Inject module awareness into each enabled script
        for script in self.scripts:
            if script.enabled:
                script.injected_content = inject_module_awareness(script, self.module_registry)

        sections: List[SectionRecord] = []

        with open(tmp_out, "wb") as f:
            # Header
            f.write(FOURDLLM_MAGIC)
            f.write(struct.pack("<I", FOURDLLM_VERSION))
            f.write(b"\x00" * (FOURDLLM_HEADER_SIZE - 8))

            # 1) GGUF Section (streamed, never compressed)
            gguf_extra = {"name": self.gguf_file.name}
            sec = self._write_section_stream_file(
                f=f,
                section_type=SECTION_GGUF_DATA,
                file_path=self.gguf_file,
                compress=False,
                extra_data=gguf_extra,
            )
            sections.append(sec)

            # 2) Metadata section
            if not self.metadata:
                self.metadata = {}
            self.metadata.setdefault("built_at", utc_iso())
            self.metadata.setdefault("builder_version", "4dllm_builder_v2")
            self.metadata.setdefault("fourdllm_version", FOURDLLM_VERSION)
            # Add module registry to metadata
            self.metadata.setdefault("modules", self.module_registry)

            meta_bytes = json.dumps(self.metadata, indent=2, sort_keys=True).encode("utf-8")
            sec = self._write_section_bytes(
                f=f,
                section_type=SECTION_METADATA,
                data=meta_bytes,
                compress=compress_metadata,
                extra_data={"kind": "metadata"},
            )
            sections.append(sec)

            # 3) Script config section (what runner uses)
            script_config = {
                # runner only receives enabled scripts as sections
                "script_count": sum(1 for s in self.scripts if s.enabled),
                "scripts": [
                    {
                        "name": s.name,
                        "priority": s.priority,
                        "enabled": s.enabled,
                        "source_path": s.source_path,
                        "description": s.description,
                        "imports": s.imports,  # Include module dependencies
                    }
                    for s in self.scripts
                ],
                "modules": self.module_registry,  # Full module registry
                # Future: define hook points here (pre_prompt, post_prompt, tool_call, etc.)
                "hooks": {
                    "pre_prompt": [],
                    "post_prompt": [],
                    "tool_call": [],
                },
                "runner_contract": {
                    "context_keys_min": ["input", "meta"],
                    "script_outputs": "script may set `result` dict; runner may read it",
                    "module_awareness": "scripts have __modules__ variable and __4dllm_get_modules__() function",
                },
            }
            cfg_bytes = json.dumps(script_config, indent=2, sort_keys=True).encode("utf-8")
            sec = self._write_section_bytes(
                f=f,
                section_type=SECTION_SCRIPT_CONFIG,
                data=cfg_bytes,
                compress=compress_metadata,
                extra_data={"kind": "script_config"},
            )
            sections.append(sec)

            # 4) Script sections (use injected_content which has module awareness)
            for s in self.scripts:
                if not s.enabled:
                    continue
                # Use injected_content (with module awareness) instead of raw content
                script_bytes = s.injected_content.encode("utf-8")
                sec = self._write_section_bytes(
                    f=f,
                    section_type=SECTION_PYTHON_SCRIPT,
                    data=script_bytes,
                    compress=compress_scripts,
                    extra_data={
                        "name": s.name,
                        "priority": s.priority,
                        "imports": s.imports,  # Include imports in extra data
                    },
                )
                sections.append(sec)

            # 5) Manifest section (self-describing)
            manifest = {
                "schema_version": "1.0",
                "fourdllm_version": FOURDLLM_VERSION,
                "features": {
                    "crc32": True,
                    "sha256": True,
                    "toc_footer": True,
                    "compressed_zlib": True,
                },
                "sections": [
                    {
                        "type": s.section_type,
                        "flags": s.flags,
                        "size_c": s.size_c,
                        "size_u": s.size_u,
                        "extra_sz": s.extra_sz,
                        "crc32": s.crc32,
                        "sha256": s.sha256,
                    }
                    for s in sections
                ],
            }
            manifest_bytes = json.dumps(manifest, indent=2, sort_keys=True).encode("utf-8")
            sec = self._write_section_bytes(
                f=f,
                section_type=SECTION_MANIFEST,
                data=manifest_bytes,
                compress=False,
                extra_data={"kind": "manifest", "schema": "1.0"},
            )
            sections.append(sec)

            # Footer TOC
            self._write_toc(f, sections)

        tmp_out.replace(out)
        return str(out)

    def _write_section_bytes(
        self,
        f,
        section_type: int,
        data: bytes,
        compress: bool,
        extra_data: Optional[Dict[str, Any]] = None,
    ) -> SectionRecord:
        offset = f.tell()

        extra_bytes = b""
        if extra_data:
            extra_bytes = json.dumps(extra_data, separators=(",", ":"), sort_keys=True).encode("utf-8")
        extra_sz = len(extra_bytes)

        crc = zlib.crc32(data) & 0xFFFFFFFF
        sha256 = _sha256_bytes(data)
        size_u = len(data)

        flags = 0
        payload = data
        if compress:
            payload = zlib.compress(data, level=9)
            flags |= FLAG_COMPRESSED_ZLIB
        size_c = len(payload)

        # write header
        f.write(SECTION_HDR_STRUCT.pack(section_type, flags, size_c, size_u, extra_sz, crc))
        if extra_sz:
            f.write(extra_bytes)
        f.write(payload)

        return SectionRecord(section_type, flags, offset, size_c, size_u, extra_sz, crc, sha256)

    def _write_section_stream_file(
        self,
        f,
        section_type: int,
        file_path: Path,
        compress: bool,
        extra_data: Optional[Dict[str, Any]] = None,
        chunk_size: int = 1024 * 1024,
    ) -> SectionRecord:
        if compress:
            raise ValueError("Streaming file compression not supported (intentional). Keep GGUF raw.")

        offset = f.tell()

        extra_bytes = b""
        if extra_data:
            extra_bytes = json.dumps(extra_data, separators=(",", ":"), sort_keys=True).encode("utf-8")
        extra_sz = len(extra_bytes)

        crc = 0
        size_u = 0

        # reserve header now, we’ll come back and patch it
        hdr_pos = f.tell()
        f.write(b"\x00" * SECTION_HDR_STRUCT.size)

        if extra_sz:
            f.write(extra_bytes)

        payload_start = f.tell()

        with open(file_path, "rb") as rf:
            while True:
                chunk = rf.read(chunk_size)
                if not chunk:
                    break
                size_u += len(chunk)
                crc = zlib.crc32(chunk, crc)

                f.write(chunk)

        payload_end = f.tell()
        size_c = payload_end - payload_start
        flags = 0
        crc &= 0xFFFFFFFF

        # patch header
        cur = f.tell()
        f.seek(hdr_pos)
        f.write(SECTION_HDR_STRUCT.pack(section_type, flags, size_c, size_u, extra_sz, crc))
        f.seek(cur)

        return SectionRecord(section_type, flags, offset, size_c, size_u, extra_sz, crc)

    def _write_toc(self, f, sections: List[SectionRecord]) -> None:
        toc_start = f.tell()
        f.write(TOC_HDR_STRUCT.pack(TOC_MAGIC, TOC_VERSION, len(sections)))

        toc_bytes_for_crc = bytearray()
        toc_bytes_for_crc += TOC_HDR_STRUCT.pack(TOC_MAGIC, TOC_VERSION, len(sections))

        for s in sections:
            entry = TOC_ENTRY_STRUCT.pack(
                s.section_type, s.flags, s.offset, s.size_c, s.size_u, s.extra_sz, s.crc32
            )
            f.write(entry)
            toc_bytes_for_crc += entry

        footer_crc = zlib.crc32(toc_bytes_for_crc) & 0xFFFFFFFF
        f.write(struct.pack("<I", footer_crc))

        logger.info("Wrote TOC footer at offset %d (crc32=%08x)", toc_start, footer_crc)


class FourDLLMBuilderGUI:
    """GUI for 4DLLM Builder v2"""

    def __init__(self, root: tk.Tk):
        self.root = root

        self.gguf_file: Optional[str] = None
        self.scripts: List[ScriptItem] = []

        # Resolve modules folder beside this script
        self.script_dir = Path(__file__).resolve().parent
        self.modules_dir = self.script_dir / MODULES_DIRNAME

        self._setup_window()
        self._setup_ui()

        # Auto-load modules folder on startup if exists
        self._auto_load_modules_folder()

    def _setup_window(self) -> None:
        self.root.title("✨ 4DLLM Builder v2 — Modules Folder + TOC")
        self.root.geometry("980x760")
        self.root.configure(bg=COLORS["bg_primary"])

        self.root.update_idletasks()
        w = self.root.winfo_width()
        h = self.root.winfo_height()
        x = (self.root.winfo_screenwidth() // 2) - (w // 2)
        y = (self.root.winfo_screenheight() // 2) - (h // 2)
        self.root.geometry(f"{w}x{h}+{x}+{y}")

    def _setup_ui(self) -> None:
        header = tk.Frame(self.root, bg=COLORS["bg_secondary"], height=84)
        header.pack(fill="x")
        header.pack_propagate(False)

        title = tk.Label(
            header,
            text="✨ 4DLLM Builder v2",
            font=("Segoe UI", 24, "bold"),
            bg=COLORS["bg_secondary"],
            fg=COLORS["accent"],
        )
        title.pack(pady=18)

        main = tk.Frame(self.root, bg=COLORS["bg_primary"])
        main.pack(fill="both", expand=True, padx=18, pady=18)

        # Step 1
        step1 = ttk.LabelFrame(main, text="📁 Step 1: Select GGUF File", padding=14)
        step1.pack(fill="x", pady=8)

        self.file_label = tk.Label(
            step1,
            text="No file selected",
            font=("Segoe UI", 10),
            bg=COLORS["bg_primary"],
            fg=COLORS["fg_secondary"],
            anchor="w",
        )
        self.file_label.pack(fill="x", pady=5)

        btn_row = tk.Frame(step1, bg=COLORS["bg_primary"])
        btn_row.pack(fill="x", pady=5)

        select_btn = tk.Button(
            btn_row,
            text="📂 Select GGUF File",
            command=self.select_gguf_file,
            bg=COLORS["accent"],
            fg=COLORS["fg_primary"],
            font=("Segoe UI", 10, "bold"),
            relief="flat",
            padx=20,
            pady=10,
            cursor="hand2",
        )
        select_btn.pack(side="left")

        # Step 2
        step2 = ttk.LabelFrame(main, text="🐍 Step 2: Add Python Scripts", padding=14)
        step2.pack(fill="both", expand=True, pady=8)

        buttons_frame = tk.Frame(step2, bg=COLORS["bg_primary"])
        buttons_frame.pack(fill="x", pady=6)

        tk.Label(
            buttons_frame,
            text="Built-in:",
            font=("Segoe UI", 10, "bold"),
            bg=COLORS["bg_primary"],
            fg=COLORS["fg_primary"],
        ).pack(side="left", padx=5)

        for script_name in SCRIPT_TEMPLATES.keys():
            btn = tk.Button(
                buttons_frame,
                text=f"+ {script_name}",
                command=lambda n=script_name: self.add_builtin_script(n),
                bg=COLORS["bg_tertiary"],
                fg=COLORS["fg_primary"],
                font=("Segoe UI", 9),
                relief="flat",
                padx=10,
                pady=6,
                cursor="hand2",
            )
            btn.pack(side="left", padx=5)

        custom_btn = tk.Button(
            buttons_frame,
            text="+ Custom Script File",
            command=self.add_custom_script,
            bg=COLORS["accent"],
            fg=COLORS["fg_primary"],
            font=("Segoe UI", 9, "bold"),
            relief="flat",
            padx=10,
            pady=6,
            cursor="hand2",
        )
        custom_btn.pack(side="left", padx=5)

        modules_btn = tk.Button(
            buttons_frame,
            text=f"↻ Load ./{MODULES_DIRNAME}/",
            command=self.load_modules_folder,
            bg=COLORS["bg_tertiary"],
            fg=COLORS["fg_primary"],
            font=("Segoe UI", 9, "bold"),
            relief="flat",
            padx=10,
            pady=6,
            cursor="hand2",
        )
        modules_btn.pack(side="left", padx=8)

        # Scripts list (scrollable)
        list_frame = tk.Frame(step2, bg=COLORS["bg_primary"])
        list_frame.pack(fill="both", expand=True, pady=10)

        canvas = tk.Canvas(list_frame, bg=COLORS["bg_secondary"], highlightthickness=0)
        scrollbar = ttk.Scrollbar(list_frame, orient="vertical", command=canvas.yview)
        self.scripts_container = tk.Frame(canvas, bg=COLORS["bg_secondary"])

        self.scripts_container.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=self.scripts_container, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        self.scripts_canvas = canvas

        # Step 3
        step3 = tk.Frame(main, bg=COLORS["bg_primary"])
        step3.pack(fill="x", pady=10)

        build_btn = tk.Button(
            step3,
            text="🚀 Build 4DLLM File (v2 + TOC)",
            command=self.build_file,
            bg=COLORS["success"],
            fg=COLORS["bg_primary"],
            font=("Segoe UI", 12, "bold"),
            relief="flat",
            padx=28,
            pady=15,
            cursor="hand2",
        )
        build_btn.pack()

        # Status bar
        self.status_label = tk.Label(
            self.root,
            text="Ready",
            font=("Segoe UI", 9),
            bg=COLORS["bg_secondary"],
            fg=COLORS["fg_secondary"],
            anchor="w",
            padx=10,
            pady=6,
        )
        self.status_label.pack(fill="x", side="bottom")

    # ------------ Helpers ------------

    def update_status(self, msg: str) -> None:
        self.status_label.config(text=msg)
        self.root.update_idletasks()

    def _auto_load_modules_folder(self) -> None:
        if self.modules_dir.exists() and self.modules_dir.is_dir():
            self._load_modules_dir(self.modules_dir, silent=True)

    def _refresh_script_list_ui(self) -> None:
        for child in list(self.scripts_container.winfo_children()):
            child.destroy()

        for item in self.scripts:
            self._add_script_to_list_ui(item)

        self.scripts_container.update_idletasks()
        self.scripts_canvas.configure(scrollregion=self.scripts_canvas.bbox("all"))

    def _add_script_to_list_ui(self, item: ScriptItem) -> None:
        frame = tk.Frame(self.scripts_container, bg=COLORS["bg_tertiary"], relief="flat", bd=1)
        frame.pack(fill="x", padx=6, pady=6)

        info = tk.Frame(frame, bg=COLORS["bg_tertiary"])
        info.pack(fill="x", padx=10, pady=6)

        label = tk.Label(
            info,
            text=f"🐍 {item.name}",
            font=("Segoe UI", 10, "bold"),
            bg=COLORS["bg_tertiary"],
            fg=COLORS["fg_primary"],
            anchor="w",
        )
        label.pack(side="left")

        src = item.source_path or "built-in"
        badge = tk.Label(
            info,
            text=src,
            font=("Segoe UI", 8),
            bg=COLORS["accent"] if src == "built-in" else COLORS["bg_secondary"],
            fg=COLORS["fg_primary"],
            padx=6,
            pady=2,
        )
        badge.pack(side="left", padx=8)

        size_label = tk.Label(
            info,
            text=f"({len(item.content.encode('utf-8'))} bytes)",
            font=("Segoe UI", 8),
            bg=COLORS["bg_tertiary"],
            fg=COLORS["fg_secondary"],
        )
        size_label.pack(side="left")
        
        # Show module count if imports are parsed
        if item.imports:
            mod_label = tk.Label(
                info,
                text=f"📦 {len(item.imports)} modules",
                font=("Segoe UI", 8),
                bg=COLORS["bg_tertiary"],
                fg=COLORS["accent"],
                padx=6,
            )
            mod_label.pack(side="left", padx=4)

        enabled_var = tk.BooleanVar(value=item.enabled)

        def toggle_enabled():
            item.enabled = bool(enabled_var.get())
            self.update_status(f"{'Enabled' if item.enabled else 'Disabled'}: {item.name}")

        chk = tk.Checkbutton(
            info,
            text="enabled",
            variable=enabled_var,
            command=toggle_enabled,
            bg=COLORS["bg_tertiary"],
            fg=COLORS["fg_primary"],
            activebackground=COLORS["bg_tertiary"],
            selectcolor=COLORS["bg_secondary"],
        )
        chk.pack(side="right", padx=(6, 0))

        def remove():
            self.scripts = [s for s in self.scripts if s.name != item.name]
            self._refresh_script_list_ui()
            self.update_status(f"Removed: {item.name}")

        rm = tk.Button(
            info,
            text="✕ Remove",
            command=remove,
            bg=COLORS["error"],
            fg=COLORS["fg_primary"],
            font=("Segoe UI", 8),
            relief="flat",
            padx=10,
            pady=2,
            cursor="hand2",
        )
        rm.pack(side="right", padx=(10, 0))

    # ------------ Actions ------------

    def select_gguf_file(self) -> None:
        fp = filedialog.askopenfilename(
            title="Select GGUF File",
            filetypes=[("GGUF files", "*.gguf"), ("All files", "*.*")]
        )
        if not fp:
            return
        self.gguf_file = fp
        file_name = os.path.basename(fp)
        file_size = os.path.getsize(fp) / (1024 * 1024)
        self.file_label.config(text=f"✓ {file_name} ({file_size:.2f} MB)", fg=COLORS["success"])
        self.update_status(f"Selected: {file_name}")

    def add_builtin_script(self, name: str) -> None:
        if name not in SCRIPT_TEMPLATES:
            return
        item = ScriptItem(
            name=name.replace(" (SAFE)", "").replace(" ", "_").lower() + ".py",
            content=SCRIPT_TEMPLATES[name],
            description="Built-in template",
            priority=10,
            enabled=True,
            source_path="built-in",
        )
        # Parse imports for module awareness
        item.imports = parse_imports_from_script(item.content)
        # Avoid duplicates by name
        self.scripts = [s for s in self.scripts if s.name != item.name] + [item]
        self._refresh_script_list_ui()
        mod_info = f" ({len(item.imports)} modules)" if item.imports else ""
        self.update_status(f"Added built-in: {item.name}{mod_info}")

    def add_custom_script(self) -> None:
        fp = filedialog.askopenfilename(
            title="Select Python Script",
            filetypes=[("Python files", "*.py"), ("All files", "*.*")]
        )
        if not fp:
            return
        try:
            content = Path(fp).read_text(encoding="utf-8")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load script:\n{e}")
            return

        name = Path(fp).name
        item = ScriptItem(
            name=name,
            content=content,
            description="Custom script file",
            priority=5,
            enabled=True,
            source_path=str(fp),
        )
        # Parse imports for module awareness
        item.imports = parse_imports_from_script(item.content)
        self.scripts = [s for s in self.scripts if s.name != item.name] + [item]
        self._refresh_script_list_ui()
        mod_info = f" ({len(item.imports)} modules)" if item.imports else ""
        self.update_status(f"Added custom: {name}{mod_info}")

    def load_modules_folder(self) -> None:
        # user wants ./modules beside builder
        if not self.modules_dir.exists():
            messagebox.showwarning(
                "modules folder missing",
                f"Expected folder:\n{self.modules_dir}\n\nCreate it and drop .py files inside."
            )
            return
        self._load_modules_dir(self.modules_dir, silent=False)

    def _load_modules_dir(self, mod_dir: Path, silent: bool) -> None:
        py_files = sorted([p for p in mod_dir.glob("*.py") if p.is_file()])
        if not py_files:
            if not silent:
                messagebox.showinfo("No modules", f"No .py files found in:\n{mod_dir}")
            return

        added = 0
        total_modules = 0
        for p in py_files:
            try:
                content = p.read_text(encoding="utf-8")
            except Exception:
                continue

            item = ScriptItem(
                name=p.name,
                content=content,
                description="Module folder script",
                priority=7,
                enabled=True,
                source_path=str(p),
            )
            # Parse imports for module awareness
            item.imports = parse_imports_from_script(item.content)
            total_modules += len(item.imports)
            self.scripts = [s for s in self.scripts if s.name != item.name] + [item]
            added += 1

        self._refresh_script_list_ui()
        mod_info = f" ({total_modules} total modules)" if total_modules > 0 else ""
        self.update_status(f"Loaded {added} module(s) from ./{MODULES_DIRNAME}/{mod_info}")

    def build_file(self) -> None:
        if not self.gguf_file:
            messagebox.showwarning("Warning", "Select a GGUF file first.")
            return
        if not self.scripts:
            messagebox.showwarning("Warning", "Add at least one script (or load ./modules/).")
            return

        out = filedialog.asksaveasfilename(
            title="Save 4DLLM File",
            defaultextension=".4dllm",
            filetypes=[("4DLLM files", "*.4dllm"), ("All files", "*.*")]
        )
        if not out:
            return

        # Validate and auto-fix scripts before building
        validation_warnings = []
        fixed_count = 0
        
        for s in self.scripts:
            if not s.enabled:
                continue
            
            # Validate and auto-fix
            fixed_content, warnings = validate_and_fix_script(s.content, s.name)
            if warnings:
                validation_warnings.append((s.name, warnings))
                s.content = fixed_content
                s.imports = parse_imports_from_script(fixed_content)
                fixed_count += 1
            
            # Final syntax check (after fixes)
            try:
                compile(s.content, s.name, "exec")
            except SyntaxError as se:
                validation_warnings.append((s.name, [
                    f"Syntax error at line {se.lineno}: {se.msg}",
                    "Could not auto-fix. Please review manually."
                ]))
            except Exception as e:
                validation_warnings.append((s.name, [f"Error: {str(e)}"]))
        
        # Show validation results
        if validation_warnings:
            warning_text = []
            error_count = 0
            fix_count = 0
            
            for script_name, warnings in validation_warnings:
                warning_text.append(f"\n{script_name}:")
                for warning in warnings:
                    warning_text.append(f"  • {warning}")
                    if "Fixed:" in warning:
                        fix_count += 1
                    elif "error" in warning.lower() or "Error" in warning:
                        error_count += 1
            
            if error_count > 0:
                msg = f"Found {error_count} error(s) and fixed {fix_count} issue(s):\n" + "\n".join(warning_text)
                result = messagebox.askyesno(
                    "Validation Results",
                    msg + "\n\nSome errors could not be auto-fixed.\nContinue building anyway?",
                    icon="warning"
                )
                if not result:
                    return
            elif fix_count > 0:
                # Show summary of fixes (limit to first 15 lines for readability)
                summary = "\n".join(warning_text[:15])
                if len(warning_text) > 15:
                    summary += f"\n  ... and {len(warning_text) - 15} more fix(es)"
                messagebox.showinfo(
                    "✅ Auto-Fixes Applied",
                    f"Fixed {fix_count} issue(s) in your scripts:\n{summary}"
                )

        try:
            self.update_status("Building 4DLLM v2 (streaming GGUF + TOC)...")
            builder = FourDLLMBuilderV2(self.gguf_file)

            # Metadata
            builder.metadata = {
                "name": "RomanAILabs 4DLLM",
                "description": "GGUF + injected python modules (4DLLM v2)",
                "modules_dir": str(self.modules_dir),
                "gguf": {"path": self.gguf_file, "name": Path(self.gguf_file).name},
            }

            for s in self.scripts:
                builder.add_script(s)

            result = builder.build(out, compress_scripts=True, compress_metadata=True)
            mb = os.path.getsize(result) / (1024 * 1024)

            # Post-build validation to guarantee runner compatibility
            validation = validate_built_file(Path(result))
            summary = (
                f"Sections: {validation.get('section_count', '?')}, "
                f"Scripts: {validation.get('script_sections', '?')}, "
                f"TOC @ {validation.get('toc_offset', '?')}"
            )

            messagebox.showinfo(
                "Success",
                (
                    "4DLLM created and validated!\n\n"
                    f"File: {os.path.basename(result)}\n"
                    f"Size: {mb:.2f} MB\n"
                    f"Scripts: {sum(1 for s in self.scripts if s.enabled)}\n"
                    f"{summary}"
                )
            )
            self.update_status(f"✓ Built: {os.path.basename(result)} | {summary}")

        except Exception as e:
            logger.error("Build failed", exc_info=True)
            messagebox.showerror("Build failed", f"{e}")
            self.update_status(f"✗ Error: {e}")


def main() -> int:
    root = tk.Tk()
    app = FourDLLMBuilderGUI(root)
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

