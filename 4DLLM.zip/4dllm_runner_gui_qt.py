#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Copyright Daniel Harding - RomanAILabs
4DLLM Runner GUI — World-Class PyQt6 + HTML/CSS/JS Interface

A stunning graphical interface built with PyQt6 and modern web technologies
for running 4DLLM files with maximum visual quality.
"""

from __future__ import annotations

import json
import os
import queue
import select
import struct
import subprocess
import sys
import threading
import time
import zlib
import ast
import shlex
import logging
import importlib.util
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from datetime import datetime

# For non-blocking I/O
try:
    import fcntl
    HAS_FCNTL = True
except ImportError:
    HAS_FCNTL = False

try:
    from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                                 QHBoxLayout, QPushButton, QLabel, QTextEdit, 
                                 QFileDialog, QMessageBox, QComboBox, QCheckBox,
                                 QLineEdit, QSplitter, QTreeWidget, QTreeWidgetItem,
                                 QTabWidget, QFrame, QScrollArea)
    from PyQt6.QtCore import Qt, QUrl, QThread, pyqtSignal, pyqtSlot, QTimer, QSize
    from PyQt6.QtGui import QFont, QColor, QPalette, QIcon
    from PyQt6.QtWebEngineWidgets import QWebEngineView
    from PyQt6.QtWebChannel import QWebChannel
    HAS_PYQT6 = True
except ImportError:
    try:
        from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                                      QHBoxLayout, QPushButton, QLabel, QTextEdit,
                                      QFileDialog, QMessageBox, QComboBox, QCheckBox,
                                      QLineEdit, QSplitter, QTreeWidget, QTreeWidgetItem,
                                      QTabWidget, QFrame, QScrollArea)
        from PySide6.QtCore import Qt, QUrl, QThread, Signal, Slot, QTimer, QSize
        from PySide6.QtGui import QFont, QColor, QPalette, QIcon
        from PySide6.QtWebEngineWidgets import QWebEngineView
        from PySide6.QtWebChannel import QWebChannel
        HAS_PYQT6 = True
        pyqtSignal = Signal
        pyqtSlot = Slot
    except ImportError:
        HAS_PYQT6 = False

# Import shared utilities from original file using importlib
import importlib.util

def _import_runner_utils():
    """Import utilities from 4dllm_runner.py"""
    runner_path = Path(__file__).parent / "4dllm_runner.py"
    if runner_path.exists():
        try:
            spec = importlib.util.spec_from_file_location("runner_module", str(runner_path))
            if spec and spec.loader:
                runner_module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(runner_module)
                return runner_module
        except Exception as e:
            DEBUG_LOGGER.error(f"Failed to load runner module: {e}")
    return None

def _import_gui_utils():
    """Import utilities from 4dllm_runner_gui.py"""
    gui_path = Path(__file__).parent / "4dllm_runner_gui.py"
    if gui_path.exists():
        try:
            spec = importlib.util.spec_from_file_location("gui_module", str(gui_path))
            if spec and spec.loader:
                gui_module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(gui_module)
                return gui_module
        except Exception as e:
            DEBUG_LOGGER.error(f"Failed to load GUI module: {e}")
    return None

# Setup logger
DEBUG_LOG_FILE = Path(__file__).parent / "4dllm_runner_debug.log"
DEBUG_LOGGER = logging.getLogger("4dllm_runner_gui_qt")
DEBUG_LOGGER.setLevel(logging.DEBUG)
fh = logging.FileHandler(DEBUG_LOG_FILE, mode='a', encoding='utf-8')
fh.setLevel(logging.DEBUG)
# Console handler for verbose output
ch = logging.StreamHandler(sys.stderr)
ch.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s [%(levelname)s] %(name)s: %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
fh.setFormatter(formatter)
ch.setFormatter(formatter)
DEBUG_LOGGER.addHandler(fh)
DEBUG_LOGGER.addHandler(ch)

# GUI Debug Log Handler (will be set up after GUI is created)
class GUIDebugLogHandler(logging.Handler):
    """Custom handler that forwards log messages to the GUI debug log"""
    def __init__(self, gui_instance):
        super().__init__()
        self.gui_instance = gui_instance
        self.setLevel(logging.DEBUG)
        formatter = logging.Formatter('%(levelname)s: %(message)s')
        self.setFormatter(formatter)
    
    def emit(self, record):
        """Emit a log record to the GUI"""
        try:
            if self.gui_instance and hasattr(self.gui_instance, '_append_debug_log'):
                msg = self.format(record)
                level_map = {
                    'DEBUG': 'debug',
                    'INFO': 'info',
                    'WARNING': 'warning',
                    'ERROR': 'error',
                    'CRITICAL': 'error'
                }
                level = level_map.get(record.levelname, 'info')
                self.gui_instance._append_debug_log(msg, level)
        except Exception:
            pass  # Don't let logging errors break the app

# Import utilities
runner_module = _import_runner_utils()
gui_module = _import_gui_utils()

# Import builder functionality
builder_path = Path(__file__).parent / "4dllm_builder_v2.0.py"
builder_module = None
if builder_path.exists():
    try:
        spec = importlib.util.spec_from_file_location("builder_module", str(builder_path))
        if spec and spec.loader:
            builder_module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(builder_module)
        DEBUG_LOGGER.info("Builder module loaded successfully")
    except Exception as e:
        DEBUG_LOGGER.error(f"Failed to load builder module: {e}")

# Import GGUF editor functionality
editor_path = Path(__file__).parent / "gguf-editor.py"
editor_module = None
if editor_path.exists():
    try:
        spec = importlib.util.spec_from_file_location("editor_module", str(editor_path))
        if spec and spec.loader:
            editor_module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(editor_module)
        DEBUG_LOGGER.info("Editor module loaded successfully")
    except Exception as e:
        DEBUG_LOGGER.error(f"Failed to load editor module: {e}")

if gui_module and hasattr(gui_module, 'read_4dllm_info'):
    read_4dllm_info = gui_module.read_4dllm_info
else:
    def read_4dllm_info(path):
        return {"valid": False, "error": "Import failed"}

if runner_module:
    read_and_validate_toc = runner_module.read_and_validate_toc
    read_section_small = runner_module.read_section_small
    SECTION_PYTHON_SCRIPT = runner_module.SECTION_PYTHON_SCRIPT
    SECTION_METADATA = runner_module.SECTION_METADATA
    SECTION_SCRIPT_CONFIG = runner_module.SECTION_SCRIPT_CONFIG
else:
    def read_and_validate_toc(path):
        return [], None
    def read_section_small(path, entry):
        return None
    SECTION_PYTHON_SCRIPT = 0x02
    SECTION_METADATA = 0x03
    SECTION_SCRIPT_CONFIG = 0x04

# ---------------- World-Class HTML/CSS/JS Interface ----------------

HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>4DLLM Studio</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', 'Segoe UI', -apple-system, BlinkMacSystemFont, sans-serif;
            background: linear-gradient(135deg, #0a0f1a 0%, #1a1f2e 100%);
            color: #e2e8f0;
            overflow: hidden;
            height: 100vh;
            width: 100vw;
        }
        
        .app-container {
            display: flex;
            flex-direction: column;
            height: 100vh;
            width: 100vw;
        }
        
        /* World-Class Header Banner */
        .header {
            background: linear-gradient(135deg, #0a0f1a 0%, #1e293b 30%, #334155 70%, #1e293b 100%);
            padding: 24px 40px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.5), inset 0 1px 0 rgba(255, 255, 255, 0.1);
            border-bottom: 3px solid transparent;
            background-image: 
                linear-gradient(135deg, #0a0f1a 0%, #1e293b 30%, #334155 70%, #1e293b 100%),
                linear-gradient(90deg, transparent 0%, #06b6d4 20%, #22d3ee 50%, #06b6d4 80%, transparent 100%);
            background-size: 100% 100%, 200% 3px;
            background-position: center, bottom;
            background-repeat: no-repeat, repeat-x;
            position: relative;
            overflow: hidden;
        }
        
        .header-code-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 0;
            overflow: hidden;
        }
        
        .code-easter-egg {
            position: absolute;
            right: -100px;
            top: 50%;
            transform: translateY(-50%) rotate(-10deg);
            font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
            font-size: 64px;
            font-weight: 800;
            white-space: nowrap;
            line-height: 1.5;
            letter-spacing: 4px;
            user-select: none;
            animation: codeGlow 8s ease-in-out infinite;
        }
        
        .code-easter-egg .code-line {
            display: block;
            margin-bottom: 16px;
            font-size: 58px;
            text-shadow: 0 0 30px rgba(6, 182, 212, 0.5), 0 0 60px rgba(34, 211, 238, 0.3);
        }
        
        .code-easter-egg .code-line:nth-child(1) {
            color: rgba(6, 182, 212, 0.22);
            animation: codeLinePulse 6s ease-in-out infinite;
        }
        
        .code-easter-egg .code-line:nth-child(2) {
            color: rgba(34, 211, 238, 0.20);
            animation: codeLinePulse 6s ease-in-out infinite 0.8s;
        }
        
        @keyframes codeGlow {
            0%, 100% {
                opacity: 0.18;
            }
            50% {
                opacity: 0.26;
            }
        }
        
        @keyframes codeLinePulse {
            0%, 100% {
                text-shadow: 0 0 30px rgba(6, 182, 212, 0.4), 0 0 60px rgba(34, 211, 238, 0.2);
            }
            50% {
                text-shadow: 0 0 45px rgba(34, 211, 238, 0.6), 0 0 90px rgba(6, 182, 212, 0.4);
            }
        }
        
        .header::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, 
                transparent 0%, 
                rgba(6, 182, 212, 0.1) 50%, 
                transparent 100%);
            animation: shimmer 4s infinite;
        }
        
        @keyframes shimmer {
            0% { left: -100%; }
            100% { left: 100%; }
        }
        
        .header-content {
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: relative;
            z-index: 1;
        }
        
        .logo-container {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .logo-img {
            width: 101px;
            height: 101px;
            object-fit: contain;
            filter: drop-shadow(0 0 25px rgba(6, 182, 212, 0.7));
            animation: logoGlow 3s ease-in-out infinite;
            transition: transform 0.3s;
        }
        
        .logo-img:hover {
            transform: scale(1.05) rotate(5deg);
        }
        
        .logo-svg {
            width: 72px;
            height: 72px;
            filter: drop-shadow(0 0 25px rgba(6, 182, 212, 0.7));
            animation: logoGlow 3s ease-in-out infinite;
            transition: transform 0.3s;
            display: none !important;
        }
        
        @keyframes logoGlow {
            0%, 100% { 
                filter: drop-shadow(0 0 25px rgba(6, 182, 212, 0.7)) 
                        drop-shadow(0 0 10px rgba(34, 211, 238, 0.5)); 
            }
            50% { 
                filter: drop-shadow(0 0 35px rgba(34, 211, 238, 1)) 
                        drop-shadow(0 0 15px rgba(6, 182, 212, 0.8)); 
            }
        }
        
        .logo-text-container {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }
        
        .logo-main-text {
            font-size: 42px;
            font-weight: 900;
            background: linear-gradient(135deg, #06b6d4 0%, #22d3ee 40%, #3b82f6 60%, #22d3ee 80%, #06b6d4 100%);
            background-size: 200% 200%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            letter-spacing: -1px;
            text-shadow: 0 0 50px rgba(6, 182, 212, 0.5);
            line-height: 1.1;
            animation: gradientShift 4s ease infinite;
        }
        
        @keyframes gradientShift {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }
        
        .logo-brand-text {
            font-size: 16px;
            font-weight: 600;
            color: #cbd5e1;
            letter-spacing: 1px;
            margin-top: 2px;
            text-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
        }
        
        .logo-email {
            font-size: 14px;
            color: #94a3b8;
            font-weight: 500;
            margin-top: 6px;
            transition: all 0.3s;
            cursor: pointer;
            display: inline-block;
        }
        
        .logo-email:hover {
            color: #22d3ee;
            text-shadow: 0 0 10px rgba(34, 211, 238, 0.5);
            transform: translateX(2px);
        }
        
        /* Integrated Navigation in Sidebar */
        .nav-tabs {
            display: flex;
            flex-direction: column;
            gap: 8px;
            margin-top: 20px;
        }
        
        .nav-tab {
            width: 100%;
            padding: 12px 16px;
            background: rgba(51, 65, 85, 0.4);
            border: 1px solid rgba(71, 85, 105, 0.3);
            color: #cbd5e1;
            font-size: 13px;
            font-weight: 600;
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
            text-align: left;
        }
        
        .nav-tab::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(6, 182, 212, 0.2), transparent);
            transition: left 0.5s;
        }
        
        .nav-tab:hover::before {
            left: 100%;
        }
        
        .nav-tab:hover {
            background: rgba(6, 182, 212, 0.2);
            border-color: rgba(6, 182, 212, 0.5);
            color: #22d3ee;
            transform: translateX(2px);
            box-shadow: 0 2px 8px rgba(6, 182, 212, 0.3);
        }
        
        .nav-tab.active {
            background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%);
            border-color: rgba(59, 130, 246, 0.5);
            color: #ffffff;
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4),
                        inset 0 1px 0 rgba(255, 255, 255, 0.2);
            transform: translateX(2px);
        }
        
        /* Main Content Area */
        .main-content {
            display: flex;
            flex: 1;
            overflow: hidden;
            gap: 12px;
            padding: 12px;
        }
        
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, #0f172a 0%, #1e293b 100%);
            border-radius: 16px;
            padding: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
            border: 1px solid rgba(71, 85, 105, 0.3);
            backdrop-filter: blur(10px);
            overflow-y: auto;
        }
        
        .sidebar-section {
            margin-bottom: 24px;
        }
        
        .section-title {
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: #06b6d4;
            margin-bottom: 12px;
        }
        
        .btn-primary {
            width: 100%;
            padding: 12px 20px;
            background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%);
            border: none;
            border-radius: 10px;
            color: #ffffff;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 4px 15px rgba(59, 130, 246, 0.3);
            margin-bottom: 8px;
            position: relative;
            overflow: hidden;
        }
        
        .btn-primary::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.3);
            transform: translate(-50%, -50%);
            transition: width 0.6s, height 0.6s;
        }
        
        .btn-primary:hover::before {
            width: 300px;
            height: 300px;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(59, 130, 246, 0.5);
        }
        
        .btn-primary:active {
            transform: translateY(0);
        }
        
        .btn-secondary {
            width: 100%;
            padding: 10px 18px;
            background: rgba(51, 65, 85, 0.6);
            border: 1px solid rgba(71, 85, 105, 0.5);
            border-radius: 10px;
            color: #e2e8f0;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-bottom: 8px;
        }
        
        .btn-secondary:hover {
            background: rgba(71, 85, 105, 0.8);
            border-color: #06b6d4;
            transform: translateY(-1px);
        }
        
        .workspace {
            flex: 1;
            background: linear-gradient(180deg, #0f172a 0%, #1e293b 100%);
            border-radius: 16px;
            padding: 24px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
            border: 1px solid rgba(71, 85, 105, 0.3);
            backdrop-filter: blur(10px);
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }
        
        .tab-content {
            display: none;
            flex: 1;
            overflow-y: auto;
            padding: 20px;
        }
        
        .tab-content.active {
            display: flex;
            flex-direction: column;
        }
        
        .content-header {
            font-size: 24px;
            font-weight: 700;
            background: linear-gradient(135deg, #06b6d4 0%, #22d3ee 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 24px;
        }
        
        .terminal-container {
            flex: 1;
            background: #0a0f1a;
            border-radius: 12px;
            padding: 16px;
            border: 1px solid rgba(71, 85, 105, 0.3);
            display: flex;
            flex-direction: column;
            font-family: 'Consolas', 'Monaco', monospace;
            font-size: 13px;
            overflow: hidden;
            position: relative;
        }
        
        .terminal-overlay-logo {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 288px;
            height: 288px;
            pointer-events: none;
            z-index: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0;
            padding: 0;
        }
        
        .terminal-overlay-logo .logo-main {
            position: relative;
            width: 288px;
            height: 288px;
            object-fit: contain;
            opacity: 0.15;
            filter: drop-shadow(0 0 20px rgba(6, 182, 212, 0.4)) drop-shadow(0 0 40px rgba(34, 211, 238, 0.2)) brightness(1.1);
            animation: logoPulse 6s ease-in-out infinite;
            margin: auto;
        }
        
        .terminal-overlay-logo img {
            position: relative;
            width: 288px;
            height: 288px;
            object-fit: contain;
            opacity: 0.25;
            filter: drop-shadow(0 0 20px rgba(6, 182, 212, 0.4)) drop-shadow(0 0 40px rgba(34, 211, 238, 0.2)) brightness(1.1);
            animation: logoPulse 6s ease-in-out infinite;
            display: block !important;
            margin: 0 auto;
        }
        
        @keyframes logoPulse {
            0%, 100% { 
                transform: scale(1);
                opacity: 0.20;
                filter: drop-shadow(0 0 20px rgba(6, 182, 212, 0.2));
            }
            50% { 
                transform: scale(1.03);
                opacity: 0.30;
                filter: drop-shadow(0 0 30px rgba(34, 211, 238, 0.4));
            }
        }
        
        .terminal-output {
            flex: 1;
            background: transparent;
            color: #e2e8f0;
            overflow-y: auto;
            padding: 12px;
            line-height: 1.6;
            white-space: pre-wrap;
            word-wrap: break-word;
            position: relative;
            z-index: 2;
        }
        
        .chat-input-container {
            margin-top: 12px;
            display: flex;
            gap: 8px;
        }
        
        .chat-input {
            flex: 1;
            background: rgba(15, 23, 42, 0.8);
            border: 1px solid rgba(71, 85, 105, 0.5);
            border-radius: 10px;
            padding: 12px 16px;
            color: #e2e8f0;
            font-family: 'Consolas', monospace;
            font-size: 13px;
            resize: none;
            min-height: 60px;
            max-height: 120px;
        }
        
        .chat-input:focus {
            outline: none;
            border-color: #06b6d4;
            box-shadow: 0 0 0 3px rgba(6, 182, 212, 0.1);
        }
        
        .btn-send {
            padding: 12px 24px;
            background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%);
            border: none;
            border-radius: 10px;
            color: #ffffff;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .btn-send:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(59, 130, 246, 0.4);
        }
        
        .details-panel {
            width: 320px;
            background: linear-gradient(180deg, #0f172a 0%, #1e293b 100%);
            border-radius: 16px;
            padding: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
            border: 1px solid rgba(71, 85, 105, 0.3);
            backdrop-filter: blur(10px);
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            gap: 16px;
        }
        
        .details-section {
            flex: 1;
            display: flex;
            flex-direction: column;
            min-height: 0;
        }
        
        .details-header {
            font-size: 16px;
            font-weight: 700;
            color: #06b6d4;
            margin-bottom: 12px;
            padding-bottom: 8px;
            border-bottom: 2px solid rgba(6, 182, 212, 0.3);
        }
        
        .details-content {
            flex: 1;
            color: #cbd5e1;
            font-size: 12px;
            line-height: 1.6;
            white-space: pre-wrap;
            overflow-y: auto;
            padding: 8px;
            background: rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            font-family: 'Consolas', 'Monaco', monospace;
        }
        
        .debug-log {
            flex: 1;
            color: #94a3b8;
            font-size: 11px;
            line-height: 1.5;
            white-space: pre-wrap;
            overflow-y: auto;
            padding: 8px;
            background: rgba(0, 0, 0, 0.3);
            border-radius: 8px;
            font-family: 'Consolas', 'Monaco', monospace;
            max-height: 100%;
        }
        
        .debug-log-entry {
            margin-bottom: 4px;
            padding: 2px 0;
        }
        
        .debug-log-entry.error {
            color: #f87171;
        }
        
        .debug-log-entry.warning {
            color: #fbbf24;
        }
        
        .debug-log-entry.info {
            color: #60a5fa;
        }
        
        .debug-log-entry.debug {
            color: #94a3b8;
        }
        
        /* Scrollbar Styling */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }
        
        ::-webkit-scrollbar-track {
            background: rgba(15, 23, 42, 0.5);
            border-radius: 4px;
        }
        
        ::-webkit-scrollbar-thumb {
            background: linear-gradient(180deg, #475569 0%, #64748b 100%);
            border-radius: 4px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(180deg, #64748b 0%, #06b6d4 100%);
        }
        
        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .fade-in {
            animation: fadeIn 0.3s ease-out;
        }
        
        /* Glass morphism effects */
        .glass {
            background: rgba(15, 23, 42, 0.6);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
    </style>
</head>
<body>
    <div class="app-container">
        <!-- World-Class Header Banner -->
        <div class="header">
            <div class="header-code-overlay">
                <div class="code-easter-egg">
                    <span class="code-line">def hypercube_4d():</span>
                    <span class="code-line">class FourDLLM:</span>
                </div>
            </div>
            <div class="header-content">
                <div class="logo-container">
                    <img src="HEADER_LOGO_PLACEHOLDER" alt="RomanAILabs Logo" class="logo-img" style="width: 101px; height: 101px; object-fit: contain;" onerror="console.error('Failed to load header logo:', this.src);">
                    <svg class="logo-svg" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" style="display: none !important;">
                        <defs>
                            <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                                <stop offset="0%" style="stop-color:#06b6d4;stop-opacity:1" />
                                <stop offset="50%" style="stop-color:#22d3ee;stop-opacity:1" />
                                <stop offset="100%" style="stop-color:#06b6d4;stop-opacity:1" />
                            </linearGradient>
                            <linearGradient id="logoGradient2" x1="0%" y1="0%" x2="100%" y2="100%">
                                <stop offset="0%" style="stop-color:#3b82f6;stop-opacity:0.8" />
                                <stop offset="100%" style="stop-color:#06b6d4;stop-opacity:0.8" />
                            </linearGradient>
                            <filter id="glow">
                                <feGaussianBlur stdDeviation="4" result="coloredBlur"/>
                                <feMerge>
                                    <feMergeNode in="coloredBlur"/>
                                    <feMergeNode in="SourceGraphic"/>
                                </feMerge>
                            </filter>
                            <filter id="shadow">
                                <feGaussianBlur in="SourceAlpha" stdDeviation="2"/>
                                <feOffset dx="2" dy="2" result="offsetblur"/>
                                <feComponentTransfer>
                                    <feFuncA type="linear" slope="0.3"/>
                                </feComponentTransfer>
                                <feMerge>
                                    <feMergeNode/>
                                    <feMergeNode in="SourceGraphic"/>
                                </feMerge>
                            </filter>
                        </defs>
                        <!-- 4D Cube with 3D effect -->
                        <g filter="url(#shadow)">
                            <!-- Main cube -->
                            <rect x="20" y="20" width="60" height="60" rx="10" fill="url(#logoGradient)" filter="url(#glow)" opacity="0.95"/>
                            <!-- Top face (3D effect) -->
                            <polygon points="20,20 30,10 90,10 80,20" fill="url(#logoGradient2)" opacity="0.7"/>
                            <!-- Right face (3D effect) -->
                            <polygon points="80,20 90,10 90,70 80,80" fill="url(#logoGradient2)" opacity="0.5"/>
                            <!-- Inner border -->
                            <rect x="25" y="25" width="50" height="50" rx="6" fill="none" stroke="#ffffff" stroke-width="1.5" opacity="0.4"/>
                            <!-- Corner highlights -->
                            <circle cx="30" cy="30" r="3" fill="#ffffff" opacity="0.9"/>
                            <circle cx="70" cy="30" r="3" fill="#ffffff" opacity="0.9"/>
                            <circle cx="30" cy="70" r="3" fill="#ffffff" opacity="0.9"/>
                            <circle cx="70" cy="70" r="3" fill="#ffffff" opacity="0.9"/>
                            <!-- 4D Text -->
                            <text x="50" y="58" font-family="Arial, sans-serif" font-size="28" font-weight="900" fill="#ffffff" text-anchor="middle" opacity="1" filter="url(#glow)">4D</text>
                        </g>
                    </svg>
                    <div class="logo-text-container">
                        <div class="logo-main-text">4DLLM Studio by RomanAILabs</div>
                        <div class="logo-email">romanailabs@gmail.com</div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="main-content">
            <div class="sidebar">
                <div class="sidebar-section">
                    <div class="section-title">Recent Files</div>
                    <div id="recent-files" style="background: rgba(15, 23, 42, 0.5); border-radius: 8px; padding: 12px; min-height: 100px; color: #64748b; font-size: 12px;">
                        No recent files
                    </div>
                </div>
                
                <div class="sidebar-section">
                    <div class="section-title">Files</div>
                    <button class="btn-primary" onclick="window.bridge.open4dllm()">📂 Open .4dllm</button>
                    <button class="btn-secondary" onclick="window.bridge.openGguf()">📂 Open .gguf</button>
                </div>
                
                <div class="sidebar-section">
                    <div class="section-title">Profiles</div>
                    <select id="profile-select" style="width: 100%; padding: 10px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 8px; color: #e2e8f0; margin-bottom: 12px;" onchange="window.bridge.selectProfile(this.value)">
                        <option value="Default">Default</option>
                        <option value="High Performance">High Performance</option>
                        <option value="Low Memory">Low Memory</option>
                    </select>
                    <div id="safety-badge" style="padding: 10px; background: rgba(51, 65, 85, 0.6); border-radius: 8px; text-align: center; font-weight: 600; color: #e2e8f0; margin-bottom: 20px;">SAFE</div>
                </div>
                
                <div class="sidebar-section">
                    <div class="section-title">Navigation</div>
                    <div class="nav-tabs">
                <button class="nav-tab active" data-tab="run">▶ Run</button>
                <button class="nav-tab" data-tab="build">🔨 Build</button>
                <button class="nav-tab" data-tab="editor">✏️ Editor</button>
                <button class="nav-tab" data-tab="inspect">🔍 Inspect</button>
                <button class="nav-tab" data-tab="scripts">📜 Scripts</button>
                <button class="nav-tab" data-tab="settings">⚙️ Settings</button>
                    </div>
                </div>
            </div>
            
            <div class="workspace">
                <div id="tab-run" class="tab-content active">
                    <div class="content-header">Run 4DLLM Model</div>
                    <div style="margin-bottom: 20px;">
                        <div style="font-size: 14px; color: #94a3b8; margin-bottom: 8px;">Selected File:</div>
                        <div id="selected-file" style="padding: 12px; background: rgba(15, 23, 42, 0.6); border-radius: 8px; color: #cbd5e1;">No file selected</div>
                    </div>
                    
                    <div style="display: flex; gap: 12px; margin-bottom: 20px;">
                        <button class="btn-primary" onclick="window.bridge.selectFile()">📂 Select</button>
                        <button class="btn-primary" onclick="window.bridge.runModel()">▶ Run</button>
                        <button class="btn-secondary" onclick="window.bridge.stopModel()">■ Stop</button>
                        <button class="btn-secondary" onclick="window.bridge.copyCommand()">📋 Copy Cmd</button>
                    </div>
                    
                    <div id="safety-warning" style="padding: 16px; background: rgba(251, 191, 36, 0.1); border: 1px solid rgba(251, 191, 36, 0.3); border-radius: 10px; margin-bottom: 16px; display: none;">
                        <div style="color: #fbbf24; font-weight: 600; margin-bottom: 8px;">⚠️ Safety Warning</div>
                        <div id="warning-text" style="color: #fbbf24; font-size: 13px;"></div>
                        <label style="display: flex; align-items: center; gap: 8px; margin-top: 12px; color: #e2e8f0; cursor: pointer;">
                            <input type="checkbox" id="unsafe-check" onchange="window.bridge.toggleUnsafe(this.checked)">
                            <span>Allow Unsafe Modules</span>
                        </label>
                    </div>
                    
                    <div class="terminal-container">
                        <div class="terminal-overlay-logo">
                            <img src="TERMINAL_LOGO_PLACEHOLDER" alt="RomanAILabs Logo" style="width: 288px; height: 288px; object-fit: contain;" onerror="console.error('Failed to load terminal logo:', this.src);">
                        </div>
                        <div class="terminal-output" id="terminal-output"></div>
                        <div class="chat-input-container">
                            <textarea class="chat-input" id="chat-input" placeholder="Type your message here... (Enter to send, Shift+Enter for newline)" onkeydown="handleChatKey(event)"></textarea>
                            <button class="btn-send" onclick="sendChatMessage()">📤 Send</button>
                        </div>
                    </div>
                </div>
                
                <div id="tab-build" class="tab-content">
                    <div class="content-header">Build 4DLLM Package</div>
                    <div style="margin-bottom: 20px;">
                        <div style="font-size: 14px; color: #94a3b8; margin-bottom: 8px;">GGUF Model:</div>
                        <div id="build-gguf-file" style="padding: 12px; background: rgba(15, 23, 42, 0.6); border-radius: 8px; color: #cbd5e1; margin-bottom: 12px;">No GGUF selected</div>
                        <button class="btn-primary" onclick="window.bridge.selectGguf()">📂 Select GGUF File</button>
                    </div>
                    <div style="margin-bottom: 20px;">
                        <div style="font-size: 14px; color: #94a3b8; margin-bottom: 8px;">Modules Folder:</div>
                        <div style="display: flex; gap: 8px; margin-bottom: 12px;">
                            <button class="btn-secondary" onclick="window.bridge.loadModules()">📁 Load from modules/</button>
                            <div id="modules-status" style="padding: 8px; color: #94a3b8; font-size: 12px; align-self: center;">No modules loaded</div>
                        </div>
                    </div>
                    <div style="margin-bottom: 20px;">
                        <div style="font-size: 14px; color: #94a3b8; margin-bottom: 8px;">Scripts:</div>
                        <div id="scripts-list" style="max-height: 300px; overflow-y: auto; background: rgba(15, 23, 42, 0.6); border-radius: 8px; padding: 12px; margin-bottom: 12px; min-height: 100px;">
                            <div style="color: #64748b; font-size: 12px;">No scripts added. Click 'Load from modules/' or 'Add Script'</div>
                        </div>
                        <button class="btn-secondary" onclick="addScriptDialog()" style="margin-bottom: 8px;">➕ Add Script</button>
                    </div>
                    <div style="margin-bottom: 20px;">
                        <div style="font-size: 14px; color: #94a3b8; margin-bottom: 8px;">Output Path:</div>
                        <input type="text" id="build-output-path" placeholder="Output .4dllm path (optional)" style="width: 100%; padding: 12px; background: rgba(15, 23, 42, 0.6); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 8px; color: #e2e8f0; margin-bottom: 12px;">
                        <div style="display: flex; gap: 12px; margin-bottom: 12px;">
                            <label style="color: #cbd5e1; font-size: 13px; display: flex; align-items: center; gap: 8px; cursor: pointer;">
                                <input type="checkbox" id="compress-scripts" checked style="cursor: pointer;">
                                Compress Scripts
                            </label>
                            <label style="color: #cbd5e1; font-size: 13px; display: flex; align-items: center; gap: 8px; cursor: pointer;">
                                <input type="checkbox" id="compress-metadata" checked style="cursor: pointer;">
                                Compress Metadata
                            </label>
                        </div>
                    </div>
                    <button class="btn-primary" onclick="window.bridge.buildPackage()">🔨 Build Package</button>
                    <div id="build-status" style="margin-top: 16px; color: #94a3b8; font-size: 13px;">Ready</div>
                </div>
                
                <div id="tab-editor" class="tab-content">
                    <div class="content-header">Edit GGUF / 4DLLM File</div>
                    <div style="margin-bottom: 20px;">
                        <div style="display: flex; gap: 12px; margin-bottom: 12px;">
                            <button class="btn-primary" onclick="window.bridge.loadEditorFile()">📂 Load File (.gguf or .4dllm)</button>
                            <button class="btn-secondary" onclick="window.bridge.saveEditorFile()">💾 Save Changes</button>
                            <button class="btn-secondary" onclick="window.bridge.createBackup()">📋 Create Backup</button>
                        </div>
                        <div id="editor-file-info" style="padding: 12px; background: rgba(15, 23, 42, 0.6); border-radius: 8px; color: #cbd5e1; margin-bottom: 12px;">No file loaded</div>
                    </div>
                    <div style="display: flex; gap: 12px; margin-bottom: 20px;">
                        <button class="btn-secondary" id="easy-mode-btn" onclick="switchEditorMode('easy')">📝 Easy Mode</button>
                        <button class="btn-secondary" id="advanced-mode-btn" onclick="switchEditorMode('advanced')">🔧 Advanced Mode</button>
                    </div>
                    <div id="editor-content" style="flex: 1; overflow-y: auto; min-height: 400px;">
                        <div style="padding: 40px; text-align: center; color: #64748b;">
                            <div style="font-size: 18px; margin-bottom: 12px;">Load a file to start editing</div>
                            <div style="font-size: 13px;">Supports both .gguf and .4dllm files</div>
                        </div>
                    </div>
                </div>
                
                <div id="tab-inspect" class="tab-content">
                    <div class="content-header">Inspect 4DLLM File</div>
                    <div style="display: flex; gap: 12px; margin-bottom: 20px;">
                        <button class="btn-primary" onclick="window.bridge.inspectFile()">📂 Load .4dllm</button>
                        <button class="btn-secondary" onclick="window.bridge.refreshInspect()">🔄 Refresh</button>
                    </div>
                    <div class="terminal-container">
                        <div class="terminal-overlay-logo">
                            <img src="TERMINAL_LOGO_PLACEHOLDER" alt="RomanAILabs Logo" style="width: 288px; height: 288px; object-fit: contain;" onerror="console.error('Failed to load terminal logo:', this.src);">
                        </div>
                        <div class="terminal-output" id="inspect-output"></div>
                    </div>
                </div>
                
                <div id="tab-scripts" class="tab-content">
                    <div class="content-header">Scripts & Modules</div>
                    <div style="margin-bottom: 20px;">
                        <input type="text" id="script-search" placeholder="Search scripts..." style="width: 100%; padding: 12px; background: rgba(15, 23, 42, 0.6); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 8px; color: #e2e8f0;">
                    </div>
                    <div class="terminal-container">
                        <div class="terminal-overlay-logo">
                            <img src="TERMINAL_LOGO_PLACEHOLDER" alt="RomanAILabs Logo" style="width: 288px; height: 288px; object-fit: contain;" onerror="console.error('Failed to load terminal logo:', this.src);">
                        </div>
                        <div class="terminal-output" id="scripts-output">Load a .4dllm file to view scripts</div>
                    </div>
                </div>
                
                <div id="tab-settings" class="tab-content">
                    <div class="content-header">Settings</div>
                    <div style="color: #cbd5e1; line-height: 1.8;">
                        <div style="margin-bottom: 16px;">
                            <div style="font-weight: 600; color: #06b6d4; margin-bottom: 8px;">Profile Management</div>
                            <div id="profile-display" style="padding: 16px; background: rgba(15, 23, 42, 0.6); border-radius: 8px; font-family: 'Consolas', monospace; font-size: 12px; white-space: pre-wrap;">Current profile settings will be shown here.</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="details-panel">
                <div class="details-section">
                    <div class="details-header">Details</div>
                    <div class="details-content" id="details-content">Select a file to view details</div>
                </div>
                <div class="details-section">
                    <div class="details-header">Debug Log</div>
                    <div class="debug-log" id="debug-log">
                        <div class="debug-log-entry info">[System] Debug log initialized</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="qrc:///qtwebchannel/qwebchannel.js"></script>
    <script>
        // Initialize QWebChannel
        let bridge = null;
        let channelReady = false;
        
        function initBridge() {
            if (typeof qt !== 'undefined' && qt.webChannelTransport) {
                try {
                    new QWebChannel(qt.webChannelTransport, function(channel) {
                        bridge = channel.objects.bridge;
                        window.bridge = bridge;
                        channelReady = true;
                        console.log('QWebChannel bridge connected');
                    });
                } catch (e) {
                    console.error('QWebChannel init error:', e);
                    setupFallbackBridge();
                }
            } else {
                console.warn('QWebChannel transport not available, using fallback');
                setupFallbackBridge();
            }
        }
        
        function setupFallbackBridge() {
            // Fallback bridge for testing (will show errors in console)
            window.bridge = {
                open4dllm: () => console.warn('Bridge not connected: open4dllm'),
                openGguf: () => console.warn('Bridge not connected: openGguf'),
                selectFile: () => console.warn('Bridge not connected: selectFile'),
                runModel: () => console.warn('Bridge not connected: runModel'),
                stopModel: () => console.warn('Bridge not connected: stopModel'),
                copyCommand: () => console.warn('Bridge not connected: copyCommand'),
                selectGguf: () => console.warn('Bridge not connected: selectGguf'),
                buildPackage: () => console.warn('Bridge not connected: buildPackage'),
                inspectFile: () => console.warn('Bridge not connected: inspectFile'),
                refreshInspect: () => console.warn('Bridge not connected: refreshInspect'),
                selectProfile: (p) => console.warn('Bridge not connected: selectProfile', p),
                toggleUnsafe: (e) => console.warn('Bridge not connected: toggleUnsafe', e),
                sendChatMessage: (t) => console.warn('Bridge not connected: sendChatMessage', t),
                loadModules: () => console.warn('Bridge not connected: loadModules'),
                loadEditorFile: () => console.warn('Bridge not connected: loadEditorFile'),
                saveEditorFile: () => console.warn('Bridge not connected: saveEditorFile'),
                createBackup: () => console.warn('Bridge not connected: createBackup')
            };
        }
        
        // Try to initialize immediately
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', initBridge);
        } else {
            initBridge();
        }
        
        // Also try after a short delay in case QWebChannel loads later
        setTimeout(initBridge, 100);
        
        // Tab switching
        document.querySelectorAll('.nav-tab').forEach(tab => {
            tab.addEventListener('click', () => {
                const tabName = tab.dataset.tab;
                document.querySelectorAll('.nav-tab').forEach(t => t.classList.remove('active'));
                document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
                document.getElementById(`tab-${tabName}`).classList.add('active');
            });
        });
        
        // Chat input handling
        function handleChatKey(event) {
            if (event.key === 'Enter' && !event.shiftKey) {
                event.preventDefault();
                sendChatMessage();
            }
        }
        
        function sendChatMessage() {
            const input = document.getElementById('chat-input');
            const text = input.value.trim();
            if (text && window.bridge) {
                window.bridge.sendChatMessage(text);
                input.value = '';
            }
        }
    </script>
</body>
</html>
"""


class WebBridge(QWidget):
    """Bridge object for Python-Qt communication"""
    # Signals
    open4dllmRequested = pyqtSignal()
    openGgufRequested = pyqtSignal()
    selectFileRequested = pyqtSignal()
    runModelRequested = pyqtSignal()
    stopModelRequested = pyqtSignal()
    copyCommandRequested = pyqtSignal()
    selectGgufRequested = pyqtSignal()
    buildPackageRequested = pyqtSignal()
    inspectFileRequested = pyqtSignal()
    refreshInspectRequested = pyqtSignal()
    selectProfileRequested = pyqtSignal(str)
    toggleUnsafeRequested = pyqtSignal(bool)
    sendChatMessageRequested = pyqtSignal(str)
    # Builder signals
    loadModulesRequested = pyqtSignal()
    addScriptRequested = pyqtSignal(str, str, int, bool)  # name, content, priority, enabled
    removeScriptRequested = pyqtSignal(str)
    buildPackageRequested = pyqtSignal(str, bool, bool)  # output_path, compress_scripts, compress_metadata
    # Editor signals
    loadEditorFileRequested = pyqtSignal()
    saveEditorFileRequested = pyqtSignal()
    createBackupRequested = pyqtSignal()
    getEditorMetadataRequested = pyqtSignal()
    updateEditorMetadataRequested = pyqtSignal(str, str)  # key, value
    
    def __init__(self):
        super().__init__()
    
    @pyqtSlot()
    def open4dllm(self):
        self.open4dllmRequested.emit()
    
    @pyqtSlot()
    def openGguf(self):
        self.openGgufRequested.emit()
    
    @pyqtSlot()
    def selectFile(self):
        self.selectFileRequested.emit()
    
    @pyqtSlot()
    def runModel(self):
        self.runModelRequested.emit()
    
    @pyqtSlot()
    def stopModel(self):
        self.stopModelRequested.emit()
    
    @pyqtSlot()
    def copyCommand(self):
        self.copyCommandRequested.emit()
    
    @pyqtSlot()
    def selectGguf(self):
        self.selectGgufRequested.emit()
    
    @pyqtSlot()
    def buildPackage(self):
        self.buildPackageRequested.emit()
    
    @pyqtSlot()
    def inspectFile(self):
        self.inspectFileRequested.emit()
    
    @pyqtSlot()
    def refreshInspect(self):
        self.refreshInspectRequested.emit()
    
    @pyqtSlot(str)
    def selectProfile(self, profile: str):
        self.selectProfileRequested.emit(profile)
    
    @pyqtSlot(bool)
    def toggleUnsafe(self, enabled: bool):
        self.toggleUnsafeRequested.emit(enabled)
    
    @pyqtSlot(str)
    def sendChatMessage(self, text: str):
        self.sendChatMessageRequested.emit(text)
    
    # Builder slots
    @pyqtSlot()
    def loadModules(self):
        self.loadModulesRequested.emit()
    
    @pyqtSlot(str, str, int, bool)
    def addScript(self, name: str, content: str, priority: int, enabled: bool):
        self.addScriptRequested.emit(name, content, priority, enabled)
    
    @pyqtSlot(str)
    def removeScript(self, name: str):
        self.removeScriptRequested.emit(name)
    
    # Editor slots
    @pyqtSlot()
    def loadEditorFile(self):
        self.loadEditorFileRequested.emit()
    
    @pyqtSlot()
    def saveEditorFile(self):
        self.saveEditorFileRequested.emit()
    
    @pyqtSlot()
    def createBackup(self):
        self.createBackupRequested.emit()
    
    @pyqtSlot()
    def getEditorMetadata(self):
        self.getEditorMetadataRequested.emit()
    
    @pyqtSlot(str, str)
    def updateEditorMetadata(self, key: str, value: str):
        self.updateEditorMetadataRequested.emit(key, value)


class OutputReaderThread(QThread):
    """Thread for reading subprocess output - optimized for speed"""
    outputReceived = pyqtSignal(str)
    finished = pyqtSignal()
    
    def __init__(self, process):
        super().__init__()
        self.process = process
        self.running = True
    
    def run(self):
        """Read output with LIGHTNING FAST polling - optimized for real-time"""
        partial = ""
        buffer_size = 4096  # 4KB chunks for optimal speed
        
        while self.running:
            try:
                # Check if process ended
                if self.process.poll() is not None:
                    # Process finished, read any remaining data
                    try:
                        remaining = self.process.stdout.read()
                        if remaining:
                            data = partial + remaining
                            if data:
                                self.outputReceived.emit(data)
                    except:
                        pass
                    break
                
                # LIGHTNING FAST non-blocking read check (1ms timeout)
                if sys.platform != "win32":
                    try:
                        ready, _, _ = select.select([self.process.stdout], [], [], 0.001)
                        if not ready:
                            time.sleep(0.001)  # Minimal sleep - 1ms
                            continue
                    except (ValueError, OSError):
                        break
                
                # Read chunk immediately
                try:
                    chunk = self.process.stdout.read(buffer_size)
                except (ValueError, OSError, AttributeError):
                    break
                
                if not chunk:
                    # No data, minimal sleep
                    time.sleep(0.001)  # 1ms
                    continue
                
                # Combine with partial line
                data = partial + chunk
                lines = data.split('\n')
                
                # Process complete lines
                if data.endswith('\n'):
                    partial = ""
                    complete_lines = lines[:-1]
                else:
                    partial = lines[-1]
                    complete_lines = lines[:-1]
                
                # Emit lines - filter out auto-prompts
                for line in complete_lines:
                    # Filter out standalone "You> " prompts (runner waiting for input)
                    if line.strip() == "You>":
                        continue
                    # Filter duplicate "You> You>" patterns
                    if line.strip().startswith("You> You>"):
                        # Keep only one "You>"
                        line = "You>" + line.split("You>", 2)[-1] if "You>" in line else line
                    
                    # Emit the line
                    self.outputReceived.emit(line + '\n')
                
            except Exception as e:
                DEBUG_LOGGER.error(f"Reader error: {e}", exc_info=True)
                break
        
        # Flush any remaining partial line
        if partial:
            self.outputReceived.emit(partial + '\n')
        
        self.finished.emit()
    
    def stop(self):
        """Stop the reader thread"""
        self.running = False


class WorldClassStudio(QMainWindow):
    """World-class 4DLLM Studio with PyQt6 + HTML/CSS/JS"""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("4DLLM Studio — RomanAILabs")
        self.setGeometry(100, 100, 1600, 1000)
        
        # State
        self.run_path: Optional[Path] = None
        self.gguf_path: Optional[Path] = None
        self.proc: Optional[subprocess.Popen] = None
        self.reader_thread: Optional[OutputReaderThread] = None
        self.unsafe_enabled = True
        self.waiting_for_ai = False  # Track if AI is generating
        self.streaming_indicator = None  # Timer for streaming dots
        self.last_ai_line_time = 0  # Track when we last saw an "AI>" line
        self.last_output_time = 0  # Track when we last saw ANY output
        self.ai_timeout_id = None  # Timeout to reset waiting state if detection fails
        self.inactivity_timeout_id = None  # Shorter timeout for inactivity detection
        
        # Editor state
        self._editor_instance = None
        self._editor_file_path = None
        
        self.profiles = {
            "Default": {"n_ctx": "4096", "threads": "4", "gpu_layers": "0", "max_tokens": "256", "temp": "0.7", "backend": "llama_cpp"},
            "High Performance": {"n_ctx": "8192", "threads": "8", "gpu_layers": "35", "max_tokens": "512", "temp": "0.8", "backend": "llama_cpp"},
            "Low Memory": {"n_ctx": "2048", "threads": "2", "gpu_layers": "0", "max_tokens": "128", "temp": "0.6", "backend": "llama_cli"},
        }
        self.current_profile = self.profiles["Default"].copy()
        
        # Setup UI
        self._setup_ui()
        self._setup_bridge()
        # Setup GUI debug log handler (after bridge is set up)
        QTimer.singleShot(500, self._setup_debug_log_handler)
        # Setup GUI debug log handler (after bridge is set up)
        QTimer.singleShot(500, self._setup_debug_log_handler)
    
    def _setup_ui(self):
        """Setup the main UI with QWebEngineView"""
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)
        layout.setContentsMargins(0, 0, 0, 0)
        
        # Get assets path for logo
        assets_dir = Path(__file__).parent / "assets"
        logo_path = assets_dir / "RomanAILabs.png"
        header_logo_path = assets_dir / "RomanAILabs.png"
        
        # Replace logo placeholders in HTML template
        html_template = HTML_TEMPLATE
        
        # Convert paths to file:// URLs for QWebEngineView
        if logo_path.exists():
            logo_url = QUrl.fromLocalFile(str(logo_path.absolute())).toString()
            DEBUG_LOGGER.info(f"Terminal logo URL: {logo_url}")
            # Replace all terminal logo placeholders
            html_template = html_template.replace('TERMINAL_LOGO_PLACEHOLDER', logo_url)
            html_template = html_template.replace('TERMINAL_LOGO_DIM_PLACEHOLDER', logo_url)
            html_template = html_template.replace('TERMINAL_LOGO_BOLD_PLACEHOLDER', logo_url)
        else:
            DEBUG_LOGGER.warning(f"Terminal logo not found at: {logo_path}")
            html_template = html_template.replace('TERMINAL_LOGO_PLACEHOLDER', '')
            html_template = html_template.replace('TERMINAL_LOGO_DIM_PLACEHOLDER', '')
            html_template = html_template.replace('TERMINAL_LOGO_BOLD_PLACEHOLDER', '')
        
        if header_logo_path.exists():
            header_logo_url = QUrl.fromLocalFile(str(header_logo_path.absolute())).toString()
            DEBUG_LOGGER.info(f"Header logo URL: {header_logo_url}")
            html_template = html_template.replace('HEADER_LOGO_PLACEHOLDER', header_logo_url)
        else:
            DEBUG_LOGGER.warning(f"Header logo not found at: {header_logo_path}")
            html_template = html_template.replace('HEADER_LOGO_PLACEHOLDER', '')
        
        # Web view for HTML/CSS/JS interface
        self.web_view = QWebEngineView()
        # Set base URL to allow loading local files
        base_url = QUrl.fromLocalFile(str(Path(__file__).parent.absolute()) + "/")
        self.web_view.setHtml(html_template, base_url)
        layout.addWidget(self.web_view)
    
    def _setup_bridge(self):
        """Setup WebChannel bridge for Python-JS communication"""
        self.bridge = WebBridge()
        self.channel = QWebChannel()
        self.channel.registerObject("bridge", self.bridge)
        self.web_view.page().setWebChannel(self.channel)
        
        # Connect signals
        self.bridge.open4dllmRequested.connect(self._open_4dllm)
        self.bridge.openGgufRequested.connect(self._open_gguf)
        self.bridge.selectFileRequested.connect(self._select_file)
        self.bridge.runModelRequested.connect(self._run_model)
        self.bridge.stopModelRequested.connect(self._stop_model)
        self.bridge.copyCommandRequested.connect(self._copy_command)
        self.bridge.selectGgufRequested.connect(self._select_gguf)
        self.bridge.buildPackageRequested.connect(self._build_package)
        self.bridge.inspectFileRequested.connect(self._inspect_file)
        self.bridge.refreshInspectRequested.connect(self._refresh_inspect)
        self.bridge.selectProfileRequested.connect(self._select_profile)
        self.bridge.toggleUnsafeRequested.connect(self._toggle_unsafe)
        self.bridge.sendChatMessageRequested.connect(self._send_chat_message)
        # Builder signals
        self.bridge.loadModulesRequested.connect(self._load_modules)
        self.bridge.addScriptRequested.connect(self._add_script)
        self.bridge.removeScriptRequested.connect(self._remove_script)
        # Editor signals
        self.bridge.loadEditorFileRequested.connect(self._load_editor_file)
        self.bridge.saveEditorFileRequested.connect(self._save_editor_file)
        self.bridge.createBackupRequested.connect(self._create_backup)
        self.bridge.getEditorMetadataRequested.connect(self._get_editor_metadata)
        self.bridge.updateEditorMetadataRequested.connect(self._update_editor_metadata)
    
    def _setup_debug_log_handler(self):
        """Setup the GUI debug log handler"""
        gui_handler = GUIDebugLogHandler(self)
        DEBUG_LOGGER.addHandler(gui_handler)
        # Also add to root logger to catch all module logs
        root_logger = logging.getLogger()
        root_logger.addHandler(gui_handler)
        DEBUG_LOGGER.info("GUI debug log handler initialized")
    
    def _append_debug_log(self, message: str, level: str = "info"):
        """Append a message to the debug log"""
        from datetime import datetime
        timestamp = datetime.now().strftime("%H:%M:%S")
        # Escape message for JavaScript
        escaped_msg = message.replace('\\', '\\\\').replace("'", "\\'").replace('\n', '\\n').replace('\r', '').replace('</', '<\\/')
        js_code = f"""
            (function() {{
                const log = document.getElementById('debug-log');
                if (!log) return;
                const entry = document.createElement('div');
                entry.className = 'debug-log-entry {level}';
                entry.textContent = '[{timestamp}] {escaped_msg}';
                log.appendChild(entry);
                // Auto-scroll to bottom
                log.scrollTop = log.scrollHeight;
                // Limit to 500 entries to prevent memory issues
                while (log.children.length > 500) {{
                    log.removeChild(log.firstChild);
                }}
            }})();
        """
        self._execute_js(js_code)
    
    def _execute_js(self, script: str, callback=None):
        """Execute JavaScript in the web view"""
        if callback:
            self.web_view.page().runJavaScript(script, callback)
        else:
            self.web_view.page().runJavaScript(script)
    
    def _append_terminal(self, text: str, tag: str = "output"):
        """Append text to terminal IMMEDIATELY - no batching for real-time display"""
        if not text:
            return
        
        import time
        text_lower = text.lower()
        text_stripped = text.strip()
        
        DEBUG_LOGGER.debug(f"[DETECT] Processing line: waiting_for_ai={self.waiting_for_ai}, text='{text_stripped[:100]}'")
        
        # Update last output time for any output
        if text_stripped:
            old_output_time = self.last_output_time
            self.last_output_time = time.time()
            DEBUG_LOGGER.debug(f"[TIMING] Output received: last_output_time={self.last_output_time:.3f} (was {old_output_time:.3f})")
            self._reset_inactivity_timeout()
        
        # Detect AI response start
        if text_stripped.startswith("AI>"):
            old_ai_time = self.last_ai_line_time
            self.waiting_for_ai = True
            self.last_ai_line_time = time.time()
            DEBUG_LOGGER.info(f"[AI_START] AI response detected: last_ai_line_time={self.last_ai_line_time:.3f} (was {old_ai_time:.3f}), waiting_for_ai={self.waiting_for_ai}")
            self._start_streaming_indicator()
            self._start_ai_timeout()
            self._reset_inactivity_timeout()
        
        # Detect when AI finishes - multiple patterns:
        # 1. Standalone "You>" or "You> " prompt (runner waiting for input)
        # 2. "[4DLLM] Chat ready" message (system ready)
        # 3. System output (performance metrics) after AI response
        is_you_prompt = (
            text_stripped == "You>" or 
            text_stripped == "You> " or
            (text_stripped.startswith("You> ") and len(text_stripped) <= 10 and not text_stripped.startswith("You> You>"))
        )
        is_ready_message = (
            "[4DLLM] Chat ready" in text_stripped or
            (text_stripped.startswith("[4DLLM]") and "ready" in text_lower)
        )
        
        # Detect system output after AI response (performance metrics)
        if self.waiting_for_ai and self.last_ai_line_time > 0:
            time_since_ai = time.time() - self.last_ai_line_time
            DEBUG_LOGGER.debug(f"[AI_CHECK] waiting_for_ai={self.waiting_for_ai}, last_ai_line_time={self.last_ai_line_time:.3f}, time_since_ai={time_since_ai:.3f}s")
            if time_since_ai > 2.0:
                is_system_output = (
                    "llama_perf" in text_lower or
                    "load time" in text_lower or
                    "eval time" in text_lower or
                    "total time" in text_lower or
                    "graphs reused" in text_lower or
                    text_stripped == "" or  # Empty line after AI response
                    (not text_stripped.startswith("AI>") and time_since_ai > 3.0)  # Any non-AI content after 3s
                )
                DEBUG_LOGGER.debug(f"[SYSTEM_CHECK] time_since_ai={time_since_ai:.3f}s, is_system_output={is_system_output}, text='{text_stripped[:50]}'")
                if is_system_output:
                    DEBUG_LOGGER.info(f"[AI_END] Detected AI response end (system output after {time_since_ai:.1f}s): '{text_stripped[:50]}'")
                    self.waiting_for_ai = False
                    self._stop_streaming_indicator()
                    self._cancel_ai_timeout()
                    self._cancel_inactivity_timeout()
                    self.last_ai_line_time = 0
        
        DEBUG_LOGGER.debug(f"[PROMPT_CHECK] is_you_prompt={is_you_prompt}, is_ready_message={is_ready_message}, text='{text_stripped[:50]}'")
        
        if is_you_prompt or is_ready_message:
            # AI finished responding - allow new messages
            if self.waiting_for_ai:
                DEBUG_LOGGER.info(f"[AI_END] AI finished responding (detected: '{text_stripped[:50]}'), ready for new input")
                self.waiting_for_ai = False
                self._stop_streaming_indicator()
                self._cancel_ai_timeout()
                self._cancel_inactivity_timeout()
                self.last_ai_line_time = 0
            else:
                DEBUG_LOGGER.debug(f"[PROMPT_CHECK] Prompt detected but waiting_for_ai=False (already reset?)")
        
        # Filter out duplicate "You> " prompts from the runner (but allow standalone "You>" for detection)
        if text_stripped == "You> " or text_stripped.startswith("You> You>"):
            # Skip auto-generated prompts (but we already detected it above)
            pass  # Don't skip - we need it for detection
        
        colors = {
            "output": "#e2e8f0",
            "success": "#34d399",
            "error": "#f87171",
            "warning": "#fbbf24",
            "info": "#60a5fa",
            "command": "#3b82f6"
        }
        color = colors.get(tag, "#e2e8f0")
        
        # Escape text properly for JavaScript (handle special chars)
        escaped_text = json.dumps(text)
        
        # Direct DOM update - no batching for instant display
        script = f"""
            (function() {{
                const output = document.getElementById('terminal-output');
                if (!output) {{ console.error('Terminal output element not found!'); return; }}
                
                // Remove streaming indicator if present
                const existingIndicator = output.querySelector('.streaming-indicator');
                if (existingIndicator) {{
                    existingIndicator.remove();
                }}
                
                const span = document.createElement('span');
                span.style.color = '{color}';
                span.textContent = {escaped_text};
                output.appendChild(span);
                
                // Always auto-scroll for real-time updates
                output.scrollTop = output.scrollHeight;
            }})();
        """
        # Execute immediately - don't queue
        self.web_view.page().runJavaScript(script)
    
    def _start_streaming_indicator(self):
        """Start showing streaming dots like Ollama"""
        if self.streaming_indicator:
            return
        
        self._dot_count = 0
        
        def update_dots():
            if not self.waiting_for_ai:
                self._stop_streaming_indicator()
                return
            
            self._dot_count = (self._dot_count + 1) % 3
            dots = "." * (self._dot_count + 1)
            
            script = f"""
                (function() {{
                    const output = document.getElementById('terminal-output');
                    if (!output) return;
                    
                    // Remove old indicator
                    const old = output.querySelector('.streaming-indicator');
                    if (old) old.remove();
                    
                    // Add new indicator
                    const span = document.createElement('span');
                    span.className = 'streaming-indicator';
                    span.style.color = '#60a5fa';
                    span.textContent = '{dots}';
                    output.appendChild(span);
                    output.scrollTop = output.scrollHeight;
                }})();
            """
            self.web_view.page().runJavaScript(script)
            
            # Schedule next update
            if self.waiting_for_ai:
                QTimer.singleShot(500, update_dots)
        
        # Start the animation
        update_dots()
    
    def _stop_streaming_indicator(self):
        """Stop streaming indicator"""
        if self.streaming_indicator:
            try:
                QTimer.singleShot(0, lambda: None)  # Cancel if possible
            except:
                pass
            self.streaming_indicator = None
        
        # Remove indicator from DOM
        script = """
            (function() {
                const output = document.getElementById('terminal-output');
                if (!output) return;
                const indicator = output.querySelector('.streaming-indicator');
                if (indicator) indicator.remove();
            })();
        """
        self.web_view.page().runJavaScript(script)
    
    def _start_ai_timeout(self):
        """Start a timeout to reset waiting state if detection fails"""
        self._cancel_ai_timeout()
        DEBUG_LOGGER.debug(f"[TIMEOUT] Starting AI timeout (30s) - waiting_for_ai={self.waiting_for_ai}")
        # Set timeout for 30 seconds - if no "You>" prompt detected, reset anyway
        def timeout_reset():
            if self.waiting_for_ai:
                DEBUG_LOGGER.warning(f"[TIMEOUT] AI timeout (30s): resetting waiting state (no 'You>' prompt detected)")
                DEBUG_LOGGER.warning(f"[TIMEOUT] State at timeout: last_output_time={self.last_output_time:.3f}, last_ai_line_time={self.last_ai_line_time:.3f}")
                self.waiting_for_ai = False
                self._stop_streaming_indicator()
            else:
                DEBUG_LOGGER.debug(f"[TIMEOUT] AI timeout triggered but waiting_for_ai=False (already reset)")
        
        # Use QTimer object for proper cancellation
        self.ai_timeout_id = QTimer()
        self.ai_timeout_id.setSingleShot(True)
        self.ai_timeout_id.timeout.connect(timeout_reset)
        self.ai_timeout_id.start(30000)  # 30 second timeout
    
    def _cancel_ai_timeout(self):
        """Cancel the AI timeout"""
        if self.ai_timeout_id:
            try:
                self.ai_timeout_id.stop()
                self.ai_timeout_id.deleteLater()
            except:
                pass
            self.ai_timeout_id = None
    
    def _reset_inactivity_timeout(self):
        """Reset the inactivity timeout - called when we see output"""
        self._cancel_inactivity_timeout()
        if not self.waiting_for_ai:
            DEBUG_LOGGER.debug(f"[TIMEOUT] Not resetting inactivity timeout - waiting_for_ai=False")
            return
        
        DEBUG_LOGGER.debug(f"[TIMEOUT] Resetting inactivity timeout - last_output_time={self.last_output_time:.3f}")
        
        # If no output for 3 seconds, assume AI finished (even without "You>" prompt)
        def inactivity_check():
            if not self.waiting_for_ai:
                DEBUG_LOGGER.debug(f"[TIMEOUT] Inactivity check skipped - waiting_for_ai=False")
                return
            
            import time
            time_since_output = time.time() - self.last_output_time
            time_since_ai = time.time() - self.last_ai_line_time if self.last_ai_line_time > 0 else 999
            
            DEBUG_LOGGER.debug(f"[TIMEOUT] Inactivity check: time_since_output={time_since_output:.3f}s, time_since_ai={time_since_ai:.3f}s")
            
            # If no output for 3 seconds OR no AI output for 3 seconds, reset
            if time_since_output >= 2.5 or (time_since_ai >= 2.5 and self.last_ai_line_time > 0):
                DEBUG_LOGGER.warning(f"[TIMEOUT] Inactivity detected (output: {time_since_output:.1f}s, AI: {time_since_ai:.1f}s): resetting waiting state")
                self.waiting_for_ai = False
                self._stop_streaming_indicator()
                self._cancel_ai_timeout()
                self.last_ai_line_time = 0
            else:
                # Check again in 500ms for faster response
                DEBUG_LOGGER.debug(f"[TIMEOUT] Scheduling next inactivity check in 500ms")
                self.inactivity_timeout_id = QTimer()
                self.inactivity_timeout_id.setSingleShot(True)
                self.inactivity_timeout_id.timeout.connect(inactivity_check)
                self.inactivity_timeout_id.start(500)
        
        # Start checking after 3 seconds of inactivity (shorter for faster recovery)
        DEBUG_LOGGER.debug(f"[TIMEOUT] Starting inactivity timeout - will check in 3 seconds")
        self.inactivity_timeout_id = QTimer()
        self.inactivity_timeout_id.setSingleShot(True)
        self.inactivity_timeout_id.timeout.connect(inactivity_check)
        self.inactivity_timeout_id.start(3000)
    
    def _cancel_inactivity_timeout(self):
        """Cancel the inactivity timeout"""
        if self.inactivity_timeout_id:
            try:
                self.inactivity_timeout_id.stop()
                self.inactivity_timeout_id.deleteLater()
            except:
                pass
            self.inactivity_timeout_id = None
    
    def _open_4dllm(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Open .4dllm File", "", "4DLLM Files (*.4dllm);;All Files (*)")
        if file_path:
            self.run_path = Path(file_path)
            self._update_file_selection()
    
    def _open_gguf(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Open .gguf File", "", "GGUF Files (*.gguf);;All Files (*)")
        if file_path:
            self.gguf_path = Path(file_path)
            self._execute_js(f"document.getElementById('gguf-file').textContent = '{self.gguf_path.name}';")
    
    def _select_file(self):
        self._open_4dllm()
    
    def _run_model(self):
        if self.proc or not self.run_path:
            if not self.run_path:
                QMessageBox.warning(self, "No File", "Please select a .4dllm file first.")
            return
        
        # Clear terminal
        self._execute_js("document.getElementById('terminal-output').textContent = '';")
        
        cmd = self._build_command()
        env = os.environ.copy()
        env['PYTHONUNBUFFERED'] = '1'
        env['PYTHONIOENCODING'] = 'utf-8'
        
        # Ensure unbuffered Python
        if cmd[0] == sys.executable:
            cmd = [cmd[0], '-u'] + cmd[1:]
        
        try:
            self._append_terminal(f"Starting: {' '.join(shlex.quote(str(arg)) for arg in cmd)}\n", "info")
            
            # CRITICAL: Line-buffered for immediate output
            self.proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                stdin=subprocess.PIPE,
                text=True,
                bufsize=1,  # Line buffered for immediate output
                env=env,
                universal_newlines=True,
                cwd=str(Path(__file__).parent)
            )
            
            # Make stdout non-blocking for faster reads (Unix only)
            if HAS_FCNTL and sys.platform != "win32":
                try:
                    flags = fcntl.fcntl(self.proc.stdout.fileno(), fcntl.F_GETFL)
                    fcntl.fcntl(self.proc.stdout.fileno(), fcntl.F_SETFL, flags | os.O_NONBLOCK)
                except Exception as e:
                    DEBUG_LOGGER.debug(f"Could not set non-blocking mode: {e}")
            
            # Start reader thread
            self.reader_thread = OutputReaderThread(self.proc)
            self.reader_thread.outputReceived.connect(self._append_terminal)
            self.reader_thread.finished.connect(self._on_process_finished)
            self.reader_thread.start()
            
            self._append_terminal("Process started. Waiting for output...\n", "info")
        except Exception as e:
            error_msg = f"Failed to start process: {str(e)}"
            DEBUG_LOGGER.error(error_msg, exc_info=True)
            QMessageBox.critical(self, "Run Failed", error_msg)
            self._append_terminal(f"ERROR: {error_msg}\n", "error")
    
    def _stop_model(self):
        if not self.proc:
            return
        
        try:
            # Stop reader thread first
            if self.reader_thread:
                self.reader_thread.stop()
                self.reader_thread.wait(1000)  # Wait up to 1 second
            
            # Close stdin to signal termination
            if self.proc.stdin:
                try:
                    self.proc.stdin.close()
                except:
                    pass
            
            # Terminate process
            self.proc.terminate()
            time.sleep(0.5)
            
            # Force kill if still running
            if self.proc.poll() is None:
                self.proc.kill()
                time.sleep(0.1)
            
            self._append_terminal("\n[Process terminated]\n", "warning")
        except Exception as e:
            DEBUG_LOGGER.error(f"Error stopping process: {e}", exc_info=True)
        
        # Always clean up state
        self._stop_streaming_indicator()
        self._cancel_ai_timeout()
        self._cancel_inactivity_timeout()
        self.waiting_for_ai = False
        self.last_ai_line_time = 0
        self.proc = None
        self.reader_thread = None
    
    def _copy_command(self):
        if not self.run_path:
            QMessageBox.warning(self, "No File", "Select a .4dllm file first.")
            return
        cmd = self._build_command()
        cmd_str = " ".join(shlex.quote(str(arg)) for arg in cmd)
        QApplication.clipboard().setText(cmd_str)
        QMessageBox.information(self, "Copied", "Command copied to clipboard!")
    
    def _select_gguf(self):
        self._open_gguf()
        if self.gguf_path:
            # Update build tab GGUF display
            self._execute_js(f"document.getElementById('build-gguf-file').textContent = '{self.gguf_path.name}';")
    
    def _build_package(self):
        """Build 4DLLM package using builder"""
        if not builder_module:
            QMessageBox.warning(self, "Error", "Builder module not available!")
            return
        
        if not self.gguf_path or not self.gguf_path.exists():
            QMessageBox.warning(self, "Error", "Please select a GGUF file first!")
            return
        
        # Get output path from UI
        output_path = None
        def get_output_path():
            nonlocal output_path
            script = "document.getElementById('build-output-path').value;"
            self.web_view.page().runJavaScript(script, lambda result: setattr(self, '_js_result', result))
            time.sleep(0.1)  # Wait for JS execution
            output_path = getattr(self, '_js_result', None) if hasattr(self, '_js_result') else None
        
        get_output_path()
        
        if not output_path:
            output_path, _ = QFileDialog.getSaveFileName(
                self, "Save 4DLLM File", "", "4DLLM Files (*.4dllm);;All Files (*)"
            )
            if not output_path:
                return
        
        # Get compression settings
        compress_scripts = True
        compress_metadata = True
        
        try:
            self._append_terminal(f"Building 4DLLM package...\n", "info")
            self._append_terminal(f"GGUF: {self.gguf_path.name}\n", "info")
            self._append_terminal(f"Output: {output_path}\n", "info")
            
            # Create builder
            builder = builder_module.FourDLLMBuilderV2(str(self.gguf_path))
            
            # Get scripts from JavaScript
            scripts_data = []
            def get_scripts():
                nonlocal scripts_data
                script = "JSON.stringify(window.builderScripts || []);"
                self.web_view.page().runJavaScript(script, lambda result: setattr(self, '_scripts_result', result))
                time.sleep(0.1)
                if hasattr(self, '_scripts_result'):
                    try:
                        scripts_data = json.loads(self._scripts_result)
                    except:
                        scripts_data = []
            
            get_scripts()
            
            # Add scripts
            if scripts_data:
                for script in scripts_data:
                    script_item = builder_module.ScriptItem(
                        name=script.get('name', 'script'),
                        content=script.get('content', ''),
                        priority=script.get('priority', 0),
                        enabled=script.get('enabled', True),
                        source_path=script.get('source_path', ''),
                        description=script.get('description', '')
                    )
                    builder.add_script(script_item)
                self._append_terminal(f"Added {len(scripts_data)} script(s)\n", "info")
            
            # Build
            result_path = builder.build(output_path, compress_scripts, compress_metadata)
            file_size = Path(result_path).stat().st_size / (1024 * 1024)
            
            self._append_terminal(f"✓ Build successful!\n", "success")
            self._append_terminal(f"File: {Path(result_path).name}\n", "info")
            self._append_terminal(f"Size: {file_size:.2f} MB\n", "info")
            
            QMessageBox.information(
                self, "Success",
                f"4DLLM file created successfully!\n\n"
                f"File: {Path(result_path).name}\n"
                f"Size: {file_size:.2f} MB"
            )
        except Exception as e:
            error_msg = f"Build failed: {str(e)}"
            DEBUG_LOGGER.error(error_msg, exc_info=True)
            self._append_terminal(f"✗ {error_msg}\n", "error")
            QMessageBox.critical(self, "Build Failed", error_msg)
    
    def _load_modules(self):
        """Load scripts from modules/ folder"""
        if not builder_module:
            QMessageBox.warning(self, "Error", "Builder module not available!")
            return
        
        modules_dir = Path(__file__).parent / "modules"
        if not modules_dir.exists():
            QMessageBox.information(self, "Info", f"Modules folder not found at: {modules_dir}")
            return
        
        try:
            scripts_loaded = []
            for script_file in sorted(modules_dir.glob("*.py")):
                try:
                    content = script_file.read_text(encoding='utf-8')
                    script_item = builder_module.ScriptItem(
                        name=script_file.stem,
                        content=content,
                        priority=0,
                        enabled=True,
                        source_path=str(script_file),
                        description=f"Loaded from {script_file.name}"
                    )
                    scripts_loaded.append({
                        'name': script_item.name,
                        'content': script_item.content,
                        'priority': script_item.priority,
                        'enabled': script_item.enabled,
                        'source_path': script_item.source_path,
                        'description': script_item.description
                    })
                except Exception as e:
                    DEBUG_LOGGER.warning(f"Failed to load {script_file}: {e}")
            
            if scripts_loaded:
                # Send to JavaScript
                scripts_json = json.dumps(scripts_loaded)
                self._execute_js(f"window.builderScripts = {scripts_json}; updateScriptsList();")
                self._execute_js(f"document.getElementById('modules-status').textContent = 'Loaded {len(scripts_loaded)} script(s)';")
                QMessageBox.information(self, "Success", f"Loaded {len(scripts_loaded)} script(s) from modules/")
            else:
                QMessageBox.information(self, "Info", "No Python scripts found in modules/ folder")
        except Exception as e:
            DEBUG_LOGGER.error(f"Error loading modules: {e}", exc_info=True)
            QMessageBox.critical(self, "Error", f"Failed to load modules: {e}")
    
    def _add_script(self, name: str, content: str, priority: int, enabled: bool):
        """Add a script to builder"""
        script_data = {
            'name': name,
            'content': content,
            'priority': priority,
            'enabled': enabled,
            'source_path': '',
            'description': ''
        }
        scripts_json = json.dumps([script_data])
        self._execute_js(f"window.builderScripts.push({scripts_json}[0]); updateScriptsList();")
    
    def _remove_script(self, name: str):
        """Remove a script from builder"""
        self._execute_js(f"window.builderScripts = window.builderScripts.filter(s => s.name !== '{name}'); updateScriptsList();")
    
    def _load_editor_file(self):
        """Load a file for editing (.gguf or .4dllm)"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Load File for Editing", "", 
            "All Supported (*.gguf *.4dllm);;GGUF Files (*.gguf);;4DLLM Files (*.4dllm);;All Files (*)"
        )
        if not file_path:
            return
        
        file_path_obj = Path(file_path)
        self._execute_js(f"document.getElementById('editor-file-info').textContent = 'File: {file_path_obj.name} ({file_path_obj.stat().st_size / (1024*1024):.2f} MB)';")
        
        # Detect file type and load accordingly
        if file_path_obj.suffix.lower() == '.4dllm':
            self._load_4dllm_for_editing(file_path_obj)
        elif file_path_obj.suffix.lower() == '.gguf':
            self._load_gguf_for_editing(file_path_obj)
        else:
            QMessageBox.warning(self, "Error", "Unsupported file type!")
    
    def _load_4dllm_for_editing(self, file_path: Path):
        """Load 4DLLM file for editing"""
        try:
            # Extract GGUF from 4DLLM for editing
            self._append_terminal(f"Loading 4DLLM file: {file_path.name}\n", "info")
            # Use runner utilities to extract GGUF
            if runner_module:
                entries, toc_offset = read_and_validate_toc(file_path)
                gguf_entry = next((e for e in entries if e.section_type == 1), None)
                if gguf_entry:
                    self._append_terminal(f"Found GGUF section in 4DLLM file\n", "info")
                    # Load metadata from 4DLLM
                    metadata_entry = next((e for e in entries if e.section_type == 3), None)
                    if metadata_entry:
                        section = read_section_small(file_path, metadata_entry)
                        if section:
                            metadata = json.loads(section.data.decode('utf-8'))
                            self._display_editor_metadata(metadata, file_path)
                else:
                    QMessageBox.warning(self, "Error", "No GGUF section found in 4DLLM file")
            else:
                QMessageBox.warning(self, "Error", "Runner module not available")
        except Exception as e:
            DEBUG_LOGGER.error(f"Error loading 4DLLM for editing: {e}", exc_info=True)
            QMessageBox.critical(self, "Error", f"Failed to load 4DLLM file: {e}")
    
    def _load_gguf_for_editing(self, file_path: Path):
        """Load GGUF file for editing"""
        if not editor_module:
            QMessageBox.warning(self, "Error", "Editor module not available!")
            return
        
        try:
            self._append_terminal(f"Loading GGUF file: {file_path.name}\n", "info")
            # Create editor instance
            editor = editor_module.GGUFEditor(str(file_path))
            metadata = editor.load_metadata_only() if hasattr(editor, 'load_metadata_only') else editor.load()
            self._display_editor_metadata(metadata, file_path)
            self._editor_instance = editor
            self._editor_file_path = file_path
        except Exception as e:
            DEBUG_LOGGER.error(f"Error loading GGUF for editing: {e}", exc_info=True)
            QMessageBox.critical(self, "Error", f"Failed to load GGUF file: {e}")
    
    def _display_editor_metadata(self, metadata: Dict[str, Any], file_path: Path):
        """Display metadata in editor UI"""
        # Create HTML for metadata display
        html = f"<div style='padding: 20px; color: #cbd5e1; font-family: monospace;'>"
        html += f"<h3 style='color: #06b6d4; margin-bottom: 16px;'>Metadata for {file_path.name}</h3>"
        html += "<div style='max-height: 500px; overflow-y: auto;'>"
        
        def format_value(v):
            if isinstance(v, (dict, list)):
                return json.dumps(v, indent=2)
            return str(v)
        
        for key, value in sorted(metadata.items()):
            html += f"<div style='margin-bottom: 12px; padding: 8px; background: rgba(15, 23, 42, 0.6); border-radius: 6px;'>"
            html += f"<div style='font-weight: 600; color: #22d3ee; margin-bottom: 4px;'>{key}</div>"
            html += f"<div style='font-size: 12px; color: #94a3b8; white-space: pre-wrap;'>{format_value(value)}</div>"
            html += "</div>"
        
        html += "</div></div>"
        
        self._execute_js(f"document.getElementById('editor-content').innerHTML = {json.dumps(html)};")
    
    def _save_editor_file(self):
        """Save edited file"""
        if not hasattr(self, '_editor_instance') or not self._editor_instance:
            QMessageBox.warning(self, "Error", "No file loaded for editing!")
            return
        
        try:
            # Get updated metadata from UI (would need to implement form)
            # For now, just save the current state
            if hasattr(self, '_editor_file_path'):
                output_path, _ = QFileDialog.getSaveFileName(
                    self, "Save File", str(self._editor_file_path),
                    "GGUF Files (*.gguf);;All Files (*)"
                )
                if output_path:
                    self._editor_instance.save(output_path)
                    QMessageBox.information(self, "Success", "File saved successfully!")
        except Exception as e:
            DEBUG_LOGGER.error(f"Error saving file: {e}", exc_info=True)
            QMessageBox.critical(self, "Error", f"Failed to save file: {e}")
    
    def _create_backup(self):
        """Create backup of current file"""
        if not hasattr(self, '_editor_file_path') or not self._editor_file_path:
            QMessageBox.warning(self, "Error", "No file loaded!")
            return
        
        try:
            backup_path = self._editor_file_path.with_suffix(
                self._editor_file_path.suffix + f".backup_{int(time.time())}"
            )
            import shutil
            shutil.copy2(self._editor_file_path, backup_path)
            QMessageBox.information(self, "Success", f"Backup created: {backup_path.name}")
        except Exception as e:
            DEBUG_LOGGER.error(f"Error creating backup: {e}", exc_info=True)
            QMessageBox.critical(self, "Error", f"Failed to create backup: {e}")
    
    def _get_editor_metadata(self):
        """Get current editor metadata"""
        # Return metadata as JSON string to JavaScript
        if hasattr(self, '_editor_instance') and self._editor_instance:
            try:
                metadata = self._editor_instance.metadata if hasattr(self._editor_instance, 'metadata') else {}
                metadata_json = json.dumps(metadata)
                self._execute_js(f"window.editorMetadata = {metadata_json};")
            except Exception as e:
                DEBUG_LOGGER.error(f"Error getting metadata: {e}")
    
    def _update_editor_metadata(self, key: str, value: str):
        """Update a metadata key-value pair"""
        if hasattr(self, '_editor_instance') and self._editor_instance:
            try:
                if hasattr(self._editor_instance, 'metadata'):
                    # Try to parse value as appropriate type
                    try:
                        value = json.loads(value)
                    except:
                        pass
                    self._editor_instance.metadata[key] = value
                    self._append_terminal(f"Updated metadata: {key} = {value}\n", "info")
            except Exception as e:
                DEBUG_LOGGER.error(f"Error updating metadata: {e}")
    
    def _inspect_file(self):
        self._open_4dllm()
        if self.run_path:
            self._refresh_inspect()
    
    def _refresh_inspect(self):
        if not self.run_path:
            return
        # Load file info in background
        threading.Thread(target=self._load_inspect_data, daemon=True).start()
    
    def _load_inspect_data(self):
        try:
            info = read_4dllm_info(self.run_path)
            content = f"File: {self.run_path.name}\n"
            content += f"Size: {self.run_path.stat().st_size / (1024*1024):.2f} MB\n"
            if info.get("valid"):
                content += f"Version: {info.get('version_label', 'unknown')}\n"
                content += f"Modules: {info.get('module_count', 0)}\n"
            else:
                content += f"Error: {info.get('error', 'Unknown error')}\n"
            
            self._execute_js(f"document.getElementById('inspect-output').textContent = {json.dumps(content)};")
        except Exception as e:
            DEBUG_LOGGER.error(f"Inspect error: {e}")
    
    def _select_profile(self, profile: str):
        if profile in self.profiles:
            self.current_profile = self.profiles[profile].copy()
    
    def _toggle_unsafe(self, enabled: bool):
        self.unsafe_enabled = enabled
        color = "#f87171" if enabled else "#34d399"
        text = "UNSAFE" if enabled else "SAFE"
        self._execute_js(f"""
            const badge = document.getElementById('safety-badge');
            badge.textContent = '{text}';
            badge.style.background = 'rgba(' + (parseInt('{color}'.slice(1, 3), 16)) + ', ' + (parseInt('{color}'.slice(3, 5), 16)) + ', ' + (parseInt('{color}'.slice(5, 7), 16)) + ', 0.2)';
            badge.style.border = '1px solid {color}';
        """)
    
    def _send_chat_message(self, text: str):
        """Send chat message ONLY when user explicitly sends it"""
        if not self.proc:
            self._append_terminal("[No process running]\n", "warning")
            return
        
        if not self.proc.stdin:
            self._append_terminal("[Process stdin not available]\n", "warning")
            return
        
        # Don't send if AI is still generating
        if self.waiting_for_ai:
            self._append_terminal("[Please wait for AI to finish responding]\n", "warning")
            return
        
        try:
            # Show user message FIRST
            self._append_terminal(f"You> {text}\n", "command")
            
            # Write message with newline and flush IMMEDIATELY
            message = text + "\n"
            self.proc.stdin.write(message)
            self.proc.stdin.flush()
            
            # Set waiting state - AI will respond
            import time
            DEBUG_LOGGER.info(f"[SEND] Sending message: '{text[:100]}', setting waiting_for_ai=True")
            self.waiting_for_ai = True
            self.last_output_time = time.time()
            self.last_ai_line_time = 0  # Reset - will be set when we see "AI>" line
            DEBUG_LOGGER.debug(f"[SEND] State initialized: waiting_for_ai={self.waiting_for_ai}, last_output_time={self.last_output_time:.3f}")
            self._start_streaming_indicator()
            self._start_ai_timeout()
            self._reset_inactivity_timeout()
            
            DEBUG_LOGGER.debug(f"Sent chat message: {text}")
        except BrokenPipeError:
            self._append_terminal("[Process ended]\n", "error")
            self.proc = None
            self.waiting_for_ai = False
        except Exception as e:
            error_msg = f"Error sending message: {e}"
            DEBUG_LOGGER.error(error_msg, exc_info=True)
            self._append_terminal(f"[Error: {error_msg}]\n", "error")
            self.waiting_for_ai = False
    
    def _build_command(self) -> List[str]:
        """Build command to run"""
        runner_script = Path(__file__).parent / "4dllm_runner.py"
        cmd = [
            sys.executable,
            str(runner_script),
            "--file", str(self.run_path),
            "--backend", self.current_profile.get("backend", "llama_cpp"),
            "--n-ctx", str(self.current_profile.get("n_ctx", "4096")),
            "--threads", str(self.current_profile.get("threads", "4")),
            "--gpu-layers", str(self.current_profile.get("gpu_layers", "0")),
            "--max-tokens", str(self.current_profile.get("max_tokens", "256")),
            "--temp", str(self.current_profile.get("temp", "0.7")),
        ]
        if self.unsafe_enabled:
            cmd.append("--unsafe-modules")
        return cmd
    
    def _update_file_selection(self):
        if self.run_path:
            self._execute_js(f"document.getElementById('selected-file').textContent = '{self.run_path.name}';")
    
    def _on_process_finished(self):
        """Called when process finishes"""
        self._stop_streaming_indicator()
        self._cancel_ai_timeout()
        self._cancel_inactivity_timeout()
        self.waiting_for_ai = False
        self.last_ai_line_time = 0
        self._append_terminal("\n[Process finished]\n", "info")
        # Clean up
        if self.proc:
            try:
                if self.proc.stdin:
                    self.proc.stdin.close()
            except:
                pass
        self.proc = None
        self.reader_thread = None
    
    def _on_page_loaded(self, success: bool):
        """Called when HTML page finishes loading"""
        if success:
            # Give WebChannel time to initialize
            QTimer.singleShot(200, self._verify_bridge)
    
    def _verify_bridge(self):
        """Verify WebChannel bridge is connected"""
        self._execute_js("""
            if (window.bridge && typeof window.bridge.sendChatMessage === 'function') {
                console.log('✓ Bridge connected successfully');
            } else {
                console.warn('⚠ Bridge not fully connected, retrying...');
                setTimeout(function() {
                    if (typeof qt !== 'undefined' && qt.webChannelTransport) {
                        new QWebChannel(qt.webChannelTransport, function(channel) {
                            window.bridge = channel.objects.bridge;
                            console.log('✓ Bridge connected on retry');
                        });
                    }
                }, 500);
            }
        """)


def main():
    """Main entry point"""
    if not HAS_PYQT6:
        print("ERROR: PyQt6 or PySide6 is required for this interface.")
        print("Install with: pip install PyQt6 PyQt6-WebEngine")
        return 1
    
    app = QApplication(sys.argv)
    
    # Set dark theme
    app.setStyle('Fusion')
    palette = QPalette()
    palette.setColor(QPalette.ColorRole.Window, QColor(15, 23, 42))
    palette.setColor(QPalette.ColorRole.WindowText, QColor(226, 232, 240))
    app.setPalette(palette)
    
    window = WorldClassStudio()
    window.show()
    
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())

