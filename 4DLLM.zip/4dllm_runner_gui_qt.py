#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Copyright Daniel Harding - RomanAILabs
4DLLM Runner GUI — World-Class PyQt6 + HTML/CSS/JS Interface

A stunning graphical interface built with PyQt6 and modern web technologies
for running 4DLLM files with maximum visual quality.
"""

from __future__ import annotations

import json
import os
import queue
import select
import struct
import subprocess
import sys
import threading
import time
import zlib
import ast
import shlex
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from datetime import datetime

# For non-blocking I/O
try:
    import fcntl
    HAS_FCNTL = True
except ImportError:
    HAS_FCNTL = False

try:
    from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                                 QHBoxLayout, QPushButton, QLabel, QTextEdit, 
                                 QFileDialog, QMessageBox, QComboBox, QCheckBox,
                                 QLineEdit, QSplitter, QTreeWidget, QTreeWidgetItem,
                                 QTabWidget, QFrame, QScrollArea)
    from PyQt6.QtCore import Qt, QUrl, QThread, pyqtSignal, pyqtSlot, QTimer, QSize
    from PyQt6.QtGui import QFont, QColor, QPalette, QIcon
    from PyQt6.QtWebEngineWidgets import QWebEngineView
    from PyQt6.QtWebChannel import QWebChannel
    HAS_PYQT6 = True
except ImportError:
    try:
        from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                                      QHBoxLayout, QPushButton, QLabel, QTextEdit,
                                      QFileDialog, QMessageBox, QComboBox, QCheckBox,
                                      QLineEdit, QSplitter, QTreeWidget, QTreeWidgetItem,
                                      QTabWidget, QFrame, QScrollArea)
        from PySide6.QtCore import Qt, QUrl, QThread, Signal, Slot, QTimer, QSize
        from PySide6.QtGui import QFont, QColor, QPalette, QIcon
        from PySide6.QtWebEngineWidgets import QWebEngineView
        from PySide6.QtWebChannel import QWebChannel
        HAS_PYQT6 = True
        pyqtSignal = Signal
        pyqtSlot = Slot
    except ImportError:
        HAS_PYQT6 = False

# Import shared utilities from original file using importlib
import importlib.util

def _import_runner_utils():
    """Import utilities from 4dllm_runner.py"""
    runner_path = Path(__file__).parent / "4dllm_runner.py"
    if runner_path.exists():
        try:
            spec = importlib.util.spec_from_file_location("runner_module", str(runner_path))
            if spec and spec.loader:
                runner_module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(runner_module)
                return runner_module
        except Exception as e:
            DEBUG_LOGGER.error(f"Failed to load runner module: {e}")
    return None

def _import_gui_utils():
    """Import utilities from 4dllm_runner_gui.py"""
    gui_path = Path(__file__).parent / "4dllm_runner_gui.py"
    if gui_path.exists():
        try:
            spec = importlib.util.spec_from_file_location("gui_module", str(gui_path))
            if spec and spec.loader:
                gui_module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(gui_module)
                return gui_module
        except Exception as e:
            DEBUG_LOGGER.error(f"Failed to load GUI module: {e}")
    return None

# Setup logger
DEBUG_LOG_FILE = Path(__file__).parent / "4dllm_runner_debug.log"
DEBUG_LOGGER = logging.getLogger("4dllm_runner_gui_qt")
DEBUG_LOGGER.setLevel(logging.DEBUG)
fh = logging.FileHandler(DEBUG_LOG_FILE, mode='a', encoding='utf-8')
fh.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s [%(levelname)s] %(name)s: %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
fh.setFormatter(formatter)
DEBUG_LOGGER.addHandler(fh)

# Import utilities
runner_module = _import_runner_utils()
gui_module = _import_gui_utils()

if gui_module and hasattr(gui_module, 'read_4dllm_info'):
    read_4dllm_info = gui_module.read_4dllm_info
else:
    def read_4dllm_info(path):
        return {"valid": False, "error": "Import failed"}

if runner_module:
    read_and_validate_toc = runner_module.read_and_validate_toc
    read_section_small = runner_module.read_section_small
    SECTION_PYTHON_SCRIPT = runner_module.SECTION_PYTHON_SCRIPT
    SECTION_METADATA = runner_module.SECTION_METADATA
    SECTION_SCRIPT_CONFIG = runner_module.SECTION_SCRIPT_CONFIG
else:
    def read_and_validate_toc(path):
        return [], None
    def read_section_small(path, entry):
        return None
    SECTION_PYTHON_SCRIPT = 0x02
    SECTION_METADATA = 0x03
    SECTION_SCRIPT_CONFIG = 0x04

# ---------------- World-Class HTML/CSS/JS Interface ----------------

HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>4DLLM Studio</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', 'Segoe UI', -apple-system, BlinkMacSystemFont, sans-serif;
            background: linear-gradient(135deg, #0a0f1a 0%, #1a1f2e 100%);
            color: #e2e8f0;
            overflow: hidden;
            height: 100vh;
            width: 100vw;
        }
        
        .app-container {
            display: flex;
            flex-direction: column;
            height: 100vh;
            width: 100vw;
        }
        
        /* Stunning Header */
        .header {
            background: linear-gradient(135deg, #1e293b 0%, #334155 50%, #475569 100%);
            padding: 20px 30px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
            border-bottom: 2px solid #06b6d4;
            position: relative;
            overflow: hidden;
        }
        
        .header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 2px;
            background: linear-gradient(90deg, 
                transparent 0%, 
                #06b6d4 20%, 
                #22d3ee 50%, 
                #06b6d4 80%, 
                transparent 100%);
            animation: shimmer 3s infinite;
        }
        
        @keyframes shimmer {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
        }
        
        .header-content {
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: relative;
            z-index: 1;
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .logo-text {
            font-size: 28px;
            font-weight: 700;
            background: linear-gradient(135deg, #06b6d4 0%, #22d3ee 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            text-shadow: 0 0 30px rgba(6, 182, 212, 0.5);
        }
        
        .logo-subtitle {
            font-size: 12px;
            color: #94a3b8;
            font-weight: 500;
        }
        
        /* Navigation Tabs */
        .nav-tabs {
            display: flex;
            gap: 8px;
            background: rgba(15, 23, 42, 0.6);
            padding: 8px;
            border-radius: 12px;
            backdrop-filter: blur(10px);
        }
        
        .nav-tab {
            padding: 10px 20px;
            background: transparent;
            border: none;
            color: #cbd5e1;
            font-size: 13px;
            font-weight: 600;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
        }
        
        .nav-tab::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(6, 182, 212, 0.2), transparent);
            transition: left 0.5s;
        }
        
        .nav-tab:hover::before {
            left: 100%;
        }
        
        .nav-tab:hover {
            background: rgba(6, 182, 212, 0.1);
            color: #22d3ee;
            transform: translateY(-2px);
        }
        
        .nav-tab.active {
            background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%);
            color: #ffffff;
            box-shadow: 0 4px 15px rgba(59, 130, 246, 0.4);
        }
        
        /* Main Content Area */
        .main-content {
            display: flex;
            flex: 1;
            overflow: hidden;
            gap: 12px;
            padding: 12px;
        }
        
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, #0f172a 0%, #1e293b 100%);
            border-radius: 16px;
            padding: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
            border: 1px solid rgba(71, 85, 105, 0.3);
            backdrop-filter: blur(10px);
            overflow-y: auto;
        }
        
        .sidebar-section {
            margin-bottom: 24px;
        }
        
        .section-title {
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: #06b6d4;
            margin-bottom: 12px;
        }
        
        .btn-primary {
            width: 100%;
            padding: 12px 20px;
            background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%);
            border: none;
            border-radius: 10px;
            color: #ffffff;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 4px 15px rgba(59, 130, 246, 0.3);
            margin-bottom: 8px;
            position: relative;
            overflow: hidden;
        }
        
        .btn-primary::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.3);
            transform: translate(-50%, -50%);
            transition: width 0.6s, height 0.6s;
        }
        
        .btn-primary:hover::before {
            width: 300px;
            height: 300px;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(59, 130, 246, 0.5);
        }
        
        .btn-primary:active {
            transform: translateY(0);
        }
        
        .btn-secondary {
            width: 100%;
            padding: 10px 18px;
            background: rgba(51, 65, 85, 0.6);
            border: 1px solid rgba(71, 85, 105, 0.5);
            border-radius: 10px;
            color: #e2e8f0;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-bottom: 8px;
        }
        
        .btn-secondary:hover {
            background: rgba(71, 85, 105, 0.8);
            border-color: #06b6d4;
            transform: translateY(-1px);
        }
        
        .workspace {
            flex: 1;
            background: linear-gradient(180deg, #0f172a 0%, #1e293b 100%);
            border-radius: 16px;
            padding: 24px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
            border: 1px solid rgba(71, 85, 105, 0.3);
            backdrop-filter: blur(10px);
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }
        
        .tab-content {
            display: none;
            flex: 1;
            overflow-y: auto;
            padding: 20px;
        }
        
        .tab-content.active {
            display: flex;
            flex-direction: column;
        }
        
        .content-header {
            font-size: 24px;
            font-weight: 700;
            background: linear-gradient(135deg, #06b6d4 0%, #22d3ee 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 24px;
        }
        
        .terminal-container {
            flex: 1;
            background: #0a0f1a;
            border-radius: 12px;
            padding: 16px;
            border: 1px solid rgba(71, 85, 105, 0.3);
            display: flex;
            flex-direction: column;
            font-family: 'Consolas', 'Monaco', monospace;
            font-size: 13px;
            overflow: hidden;
        }
        
        .terminal-output {
            flex: 1;
            background: transparent;
            color: #e2e8f0;
            overflow-y: auto;
            padding: 12px;
            line-height: 1.6;
            white-space: pre-wrap;
            word-wrap: break-word;
        }
        
        .chat-input-container {
            margin-top: 12px;
            display: flex;
            gap: 8px;
        }
        
        .chat-input {
            flex: 1;
            background: rgba(15, 23, 42, 0.8);
            border: 1px solid rgba(71, 85, 105, 0.5);
            border-radius: 10px;
            padding: 12px 16px;
            color: #e2e8f0;
            font-family: 'Consolas', monospace;
            font-size: 13px;
            resize: none;
            min-height: 60px;
            max-height: 120px;
        }
        
        .chat-input:focus {
            outline: none;
            border-color: #06b6d4;
            box-shadow: 0 0 0 3px rgba(6, 182, 212, 0.1);
        }
        
        .btn-send {
            padding: 12px 24px;
            background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%);
            border: none;
            border-radius: 10px;
            color: #ffffff;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .btn-send:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(59, 130, 246, 0.4);
        }
        
        .details-panel {
            width: 320px;
            background: linear-gradient(180deg, #0f172a 0%, #1e293b 100%);
            border-radius: 16px;
            padding: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
            border: 1px solid rgba(71, 85, 105, 0.3);
            backdrop-filter: blur(10px);
            overflow-y: auto;
        }
        
        .details-header {
            font-size: 18px;
            font-weight: 700;
            color: #06b6d4;
            margin-bottom: 16px;
            padding-bottom: 12px;
            border-bottom: 2px solid rgba(6, 182, 212, 0.3);
        }
        
        .details-content {
            color: #cbd5e1;
            font-size: 13px;
            line-height: 1.8;
            white-space: pre-wrap;
        }
        
        /* Scrollbar Styling */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }
        
        ::-webkit-scrollbar-track {
            background: rgba(15, 23, 42, 0.5);
            border-radius: 4px;
        }
        
        ::-webkit-scrollbar-thumb {
            background: linear-gradient(180deg, #475569 0%, #64748b 100%);
            border-radius: 4px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(180deg, #64748b 0%, #06b6d4 100%);
        }
        
        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .fade-in {
            animation: fadeIn 0.3s ease-out;
        }
        
        /* Glass morphism effects */
        .glass {
            background: rgba(15, 23, 42, 0.6);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
    </style>
</head>
<body>
    <div class="app-container">
        <div class="header">
            <div class="header-content">
                <div class="logo">
                    <div>
                        <div class="logo-text">4DLLM Studio</div>
                        <div class="logo-subtitle">RomanAILabs</div>
                    </div>
                </div>
                <div class="nav-tabs">
                    <button class="nav-tab active" data-tab="run">▶ Run</button>
                    <button class="nav-tab" data-tab="build">🔨 Build</button>
                    <button class="nav-tab" data-tab="inspect">🔍 Inspect</button>
                    <button class="nav-tab" data-tab="scripts">📜 Scripts</button>
                    <button class="nav-tab" data-tab="settings">⚙️ Settings</button>
                </div>
            </div>
        </div>
        
        <div class="main-content">
            <div class="sidebar">
                <div class="sidebar-section">
                    <div class="section-title">Recent Files</div>
                    <div id="recent-files" style="background: rgba(15, 23, 42, 0.5); border-radius: 8px; padding: 12px; min-height: 100px; color: #64748b; font-size: 12px;">
                        No recent files
                    </div>
                </div>
                
                <div class="sidebar-section">
                    <div class="section-title">Files</div>
                    <button class="btn-primary" onclick="window.bridge.open4dllm()">📂 Open .4dllm</button>
                    <button class="btn-secondary" onclick="window.bridge.openGguf()">📂 Open .gguf</button>
                </div>
                
                <div class="sidebar-section">
                    <div class="section-title">Profiles</div>
                    <select id="profile-select" style="width: 100%; padding: 10px; background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 8px; color: #e2e8f0; margin-bottom: 12px;" onchange="window.bridge.selectProfile(this.value)">
                        <option value="Default">Default</option>
                        <option value="High Performance">High Performance</option>
                        <option value="Low Memory">Low Memory</option>
                    </select>
                    <div id="safety-badge" style="padding: 10px; background: rgba(51, 65, 85, 0.6); border-radius: 8px; text-align: center; font-weight: 600; color: #e2e8f0;">SAFE</div>
                </div>
            </div>
            
            <div class="workspace">
                <div id="tab-run" class="tab-content active">
                    <div class="content-header">Run 4DLLM Model</div>
                    <div style="margin-bottom: 20px;">
                        <div style="font-size: 14px; color: #94a3b8; margin-bottom: 8px;">Selected File:</div>
                        <div id="selected-file" style="padding: 12px; background: rgba(15, 23, 42, 0.6); border-radius: 8px; color: #cbd5e1;">No file selected</div>
                    </div>
                    
                    <div style="display: flex; gap: 12px; margin-bottom: 20px;">
                        <button class="btn-primary" onclick="window.bridge.selectFile()">📂 Select</button>
                        <button class="btn-primary" onclick="window.bridge.runModel()">▶ Run</button>
                        <button class="btn-secondary" onclick="window.bridge.stopModel()">■ Stop</button>
                        <button class="btn-secondary" onclick="window.bridge.copyCommand()">📋 Copy Cmd</button>
                    </div>
                    
                    <div id="safety-warning" style="padding: 16px; background: rgba(251, 191, 36, 0.1); border: 1px solid rgba(251, 191, 36, 0.3); border-radius: 10px; margin-bottom: 16px; display: none;">
                        <div style="color: #fbbf24; font-weight: 600; margin-bottom: 8px;">⚠️ Safety Warning</div>
                        <div id="warning-text" style="color: #fbbf24; font-size: 13px;"></div>
                        <label style="display: flex; align-items: center; gap: 8px; margin-top: 12px; color: #e2e8f0; cursor: pointer;">
                            <input type="checkbox" id="unsafe-check" onchange="window.bridge.toggleUnsafe(this.checked)">
                            <span>Allow Unsafe Modules</span>
                        </label>
                    </div>
                    
                    <div class="terminal-container">
                        <div class="terminal-output" id="terminal-output"></div>
                        <div class="chat-input-container">
                            <textarea class="chat-input" id="chat-input" placeholder="Type your message here... (Enter to send, Shift+Enter for newline)" onkeydown="handleChatKey(event)"></textarea>
                            <button class="btn-send" onclick="sendChatMessage()">📤 Send</button>
                        </div>
                    </div>
                </div>
                
                <div id="tab-build" class="tab-content">
                    <div class="content-header">Build 4DLLM Package</div>
                    <div style="margin-bottom: 20px;">
                        <div style="font-size: 14px; color: #94a3b8; margin-bottom: 8px;">GGUF Model:</div>
                        <div id="gguf-file" style="padding: 12px; background: rgba(15, 23, 42, 0.6); border-radius: 8px; color: #cbd5e1; margin-bottom: 12px;">No GGUF selected</div>
                        <button class="btn-primary" onclick="window.bridge.selectGguf()">📂 Select GGUF File</button>
                    </div>
                    <div style="margin-bottom: 20px;">
                        <div style="font-size: 14px; color: #94a3b8; margin-bottom: 8px;">Output Path:</div>
                        <input type="text" id="output-path" placeholder="Output .4dllm path (optional)" style="width: 100%; padding: 12px; background: rgba(15, 23, 42, 0.6); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 8px; color: #e2e8f0;">
                    </div>
                    <button class="btn-primary" onclick="window.bridge.buildPackage()">🔨 Build Package</button>
                    <div id="build-status" style="margin-top: 16px; color: #94a3b8; font-size: 13px;">Ready</div>
                </div>
                
                <div id="tab-inspect" class="tab-content">
                    <div class="content-header">Inspect 4DLLM File</div>
                    <div style="display: flex; gap: 12px; margin-bottom: 20px;">
                        <button class="btn-primary" onclick="window.bridge.inspectFile()">📂 Load .4dllm</button>
                        <button class="btn-secondary" onclick="window.bridge.refreshInspect()">🔄 Refresh</button>
                    </div>
                    <div class="terminal-container">
                        <div class="terminal-output" id="inspect-output"></div>
                    </div>
                </div>
                
                <div id="tab-scripts" class="tab-content">
                    <div class="content-header">Scripts & Modules</div>
                    <div style="margin-bottom: 20px;">
                        <input type="text" id="script-search" placeholder="Search scripts..." style="width: 100%; padding: 12px; background: rgba(15, 23, 42, 0.6); border: 1px solid rgba(71, 85, 105, 0.5); border-radius: 8px; color: #e2e8f0;">
                    </div>
                    <div class="terminal-container">
                        <div class="terminal-output" id="scripts-output">Load a .4dllm file to view scripts</div>
                    </div>
                </div>
                
                <div id="tab-settings" class="tab-content">
                    <div class="content-header">Settings</div>
                    <div style="color: #cbd5e1; line-height: 1.8;">
                        <div style="margin-bottom: 16px;">
                            <div style="font-weight: 600; color: #06b6d4; margin-bottom: 8px;">Profile Management</div>
                            <div id="profile-display" style="padding: 16px; background: rgba(15, 23, 42, 0.6); border-radius: 8px; font-family: 'Consolas', monospace; font-size: 12px; white-space: pre-wrap;">Current profile settings will be shown here.</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="details-panel">
                <div class="details-header">Details</div>
                <div class="details-content" id="details-content">Select a file to view details</div>
            </div>
        </div>
    </div>
    
    <script src="qrc:///qtwebchannel/qwebchannel.js"></script>
    <script>
        // Initialize QWebChannel
        let bridge = null;
        let channelReady = false;
        
        function initBridge() {
            if (typeof qt !== 'undefined' && qt.webChannelTransport) {
                try {
                    new QWebChannel(qt.webChannelTransport, function(channel) {
                        bridge = channel.objects.bridge;
                        window.bridge = bridge;
                        channelReady = true;
                        console.log('QWebChannel bridge connected');
                    });
                } catch (e) {
                    console.error('QWebChannel init error:', e);
                    setupFallbackBridge();
                }
            } else {
                console.warn('QWebChannel transport not available, using fallback');
                setupFallbackBridge();
            }
        }
        
        function setupFallbackBridge() {
            // Fallback bridge for testing (will show errors in console)
            window.bridge = {
                open4dllm: () => console.warn('Bridge not connected: open4dllm'),
                openGguf: () => console.warn('Bridge not connected: openGguf'),
                selectFile: () => console.warn('Bridge not connected: selectFile'),
                runModel: () => console.warn('Bridge not connected: runModel'),
                stopModel: () => console.warn('Bridge not connected: stopModel'),
                copyCommand: () => console.warn('Bridge not connected: copyCommand'),
                selectGguf: () => console.warn('Bridge not connected: selectGguf'),
                buildPackage: () => console.warn('Bridge not connected: buildPackage'),
                inspectFile: () => console.warn('Bridge not connected: inspectFile'),
                refreshInspect: () => console.warn('Bridge not connected: refreshInspect'),
                selectProfile: (p) => console.warn('Bridge not connected: selectProfile', p),
                toggleUnsafe: (e) => console.warn('Bridge not connected: toggleUnsafe', e),
                sendChatMessage: (t) => console.warn('Bridge not connected: sendChatMessage', t)
            };
        }
        
        // Try to initialize immediately
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', initBridge);
        } else {
            initBridge();
        }
        
        // Also try after a short delay in case QWebChannel loads later
        setTimeout(initBridge, 100);
        
        // Tab switching
        document.querySelectorAll('.nav-tab').forEach(tab => {
            tab.addEventListener('click', () => {
                const tabName = tab.dataset.tab;
                document.querySelectorAll('.nav-tab').forEach(t => t.classList.remove('active'));
                document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
                document.getElementById(`tab-${tabName}`).classList.add('active');
            });
        });
        
        // Chat input handling
        function handleChatKey(event) {
            if (event.key === 'Enter' && !event.shiftKey) {
                event.preventDefault();
                sendChatMessage();
            }
        }
        
        function sendChatMessage() {
            const input = document.getElementById('chat-input');
            const text = input.value.trim();
            if (text && window.bridge) {
                window.bridge.sendChatMessage(text);
                input.value = '';
            }
        }
    </script>
</body>
</html>
"""


class WebBridge(QWidget):
    """Bridge object for Python-Qt communication"""
    # Signals
    open4dllmRequested = pyqtSignal()
    openGgufRequested = pyqtSignal()
    selectFileRequested = pyqtSignal()
    runModelRequested = pyqtSignal()
    stopModelRequested = pyqtSignal()
    copyCommandRequested = pyqtSignal()
    selectGgufRequested = pyqtSignal()
    buildPackageRequested = pyqtSignal()
    inspectFileRequested = pyqtSignal()
    refreshInspectRequested = pyqtSignal()
    selectProfileRequested = pyqtSignal(str)
    toggleUnsafeRequested = pyqtSignal(bool)
    sendChatMessageRequested = pyqtSignal(str)
    
    def __init__(self):
        super().__init__()
    
    @pyqtSlot()
    def open4dllm(self):
        self.open4dllmRequested.emit()
    
    @pyqtSlot()
    def openGguf(self):
        self.openGgufRequested.emit()
    
    @pyqtSlot()
    def selectFile(self):
        self.selectFileRequested.emit()
    
    @pyqtSlot()
    def runModel(self):
        self.runModelRequested.emit()
    
    @pyqtSlot()
    def stopModel(self):
        self.stopModelRequested.emit()
    
    @pyqtSlot()
    def copyCommand(self):
        self.copyCommandRequested.emit()
    
    @pyqtSlot()
    def selectGguf(self):
        self.selectGgufRequested.emit()
    
    @pyqtSlot()
    def buildPackage(self):
        self.buildPackageRequested.emit()
    
    @pyqtSlot()
    def inspectFile(self):
        self.inspectFileRequested.emit()
    
    @pyqtSlot()
    def refreshInspect(self):
        self.refreshInspectRequested.emit()
    
    @pyqtSlot(str)
    def selectProfile(self, profile: str):
        self.selectProfileRequested.emit(profile)
    
    @pyqtSlot(bool)
    def toggleUnsafe(self, enabled: bool):
        self.toggleUnsafeRequested.emit(enabled)
    
    @pyqtSlot(str)
    def sendChatMessage(self, text: str):
        self.sendChatMessageRequested.emit(text)


class OutputReaderThread(QThread):
    """Thread for reading subprocess output - optimized for speed"""
    outputReceived = pyqtSignal(str)
    finished = pyqtSignal()
    
    def __init__(self, process):
        super().__init__()
        self.process = process
        self.running = True
    
    def run(self):
        """Read output with LIGHTNING FAST polling - optimized for real-time"""
        partial = ""
        buffer_size = 4096  # 4KB chunks for optimal speed
        
        while self.running:
            try:
                # Check if process ended
                if self.process.poll() is not None:
                    # Process finished, read any remaining data
                    try:
                        remaining = self.process.stdout.read()
                        if remaining:
                            data = partial + remaining
                            if data:
                                self.outputReceived.emit(data)
                    except:
                        pass
                    break
                
                # LIGHTNING FAST non-blocking read check (1ms timeout)
                if sys.platform != "win32":
                    try:
                        ready, _, _ = select.select([self.process.stdout], [], [], 0.001)
                        if not ready:
                            time.sleep(0.001)  # Minimal sleep - 1ms
                            continue
                    except (ValueError, OSError):
                        break
                
                # Read chunk immediately
                try:
                    chunk = self.process.stdout.read(buffer_size)
                except (ValueError, OSError, AttributeError):
                    break
                
                if not chunk:
                    # No data, minimal sleep
                    time.sleep(0.001)  # 1ms
                    continue
                
                # Combine with partial line
                data = partial + chunk
                lines = data.split('\n')
                
                # Process complete lines
                if data.endswith('\n'):
                    partial = ""
                    complete_lines = lines[:-1]
                else:
                    partial = lines[-1]
                    complete_lines = lines[:-1]
                
                # Emit lines - filter out auto-prompts
                for line in complete_lines:
                    # Filter out standalone "You> " prompts (runner waiting for input)
                    if line.strip() == "You>":
                        continue
                    # Filter duplicate "You> You>" patterns
                    if line.strip().startswith("You> You>"):
                        # Keep only one "You>"
                        line = "You>" + line.split("You>", 2)[-1] if "You>" in line else line
                    
                    # Emit the line
                    self.outputReceived.emit(line + '\n')
                
            except Exception as e:
                DEBUG_LOGGER.error(f"Reader error: {e}", exc_info=True)
                break
        
        # Flush any remaining partial line
        if partial:
            self.outputReceived.emit(partial + '\n')
        
        self.finished.emit()
    
    def stop(self):
        """Stop the reader thread"""
        self.running = False


class WorldClassStudio(QMainWindow):
    """World-class 4DLLM Studio with PyQt6 + HTML/CSS/JS"""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("4DLLM Studio — RomanAILabs")
        self.setGeometry(100, 100, 1600, 1000)
        
        # State
        self.run_path: Optional[Path] = None
        self.gguf_path: Optional[Path] = None
        self.proc: Optional[subprocess.Popen] = None
        self.reader_thread: Optional[OutputReaderThread] = None
        self.unsafe_enabled = True
        self.waiting_for_ai = False  # Track if AI is generating
        self.streaming_indicator = None  # Timer for streaming dots
        
        self.profiles = {
            "Default": {"n_ctx": "4096", "threads": "4", "gpu_layers": "0", "max_tokens": "256", "temp": "0.7", "backend": "llama_cpp"},
            "High Performance": {"n_ctx": "8192", "threads": "8", "gpu_layers": "35", "max_tokens": "512", "temp": "0.8", "backend": "llama_cpp"},
            "Low Memory": {"n_ctx": "2048", "threads": "2", "gpu_layers": "0", "max_tokens": "128", "temp": "0.6", "backend": "llama_cli"},
        }
        self.current_profile = self.profiles["Default"].copy()
        
        # Setup UI
        self._setup_ui()
        self._setup_bridge()
    
    def _setup_ui(self):
        """Setup the main UI with QWebEngineView"""
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)
        layout.setContentsMargins(0, 0, 0, 0)
        
        # Web view for HTML/CSS/JS interface
        self.web_view = QWebEngineView()
        self.web_view.setHtml(HTML_TEMPLATE)
        layout.addWidget(self.web_view)
    
    def _setup_bridge(self):
        """Setup WebChannel bridge for Python-JS communication"""
        self.bridge = WebBridge()
        self.channel = QWebChannel()
        self.channel.registerObject("bridge", self.bridge)
        self.web_view.page().setWebChannel(self.channel)
        
        # Connect signals
        self.bridge.open4dllmRequested.connect(self._open_4dllm)
        self.bridge.openGgufRequested.connect(self._open_gguf)
        self.bridge.selectFileRequested.connect(self._select_file)
        self.bridge.runModelRequested.connect(self._run_model)
        self.bridge.stopModelRequested.connect(self._stop_model)
        self.bridge.copyCommandRequested.connect(self._copy_command)
        self.bridge.selectGgufRequested.connect(self._select_gguf)
        self.bridge.buildPackageRequested.connect(self._build_package)
        self.bridge.inspectFileRequested.connect(self._inspect_file)
        self.bridge.refreshInspectRequested.connect(self._refresh_inspect)
        self.bridge.selectProfileRequested.connect(self._select_profile)
        self.bridge.toggleUnsafeRequested.connect(self._toggle_unsafe)
        self.bridge.sendChatMessageRequested.connect(self._send_chat_message)
    
    def _execute_js(self, script: str):
        """Execute JavaScript in the web view"""
        self.web_view.page().runJavaScript(script)
    
    def _append_terminal(self, text: str, tag: str = "output"):
        """Append text to terminal IMMEDIATELY - no batching for real-time display"""
        if not text:
            return
        
        # Detect AI response start/end
        if "AI>" in text and not self.waiting_for_ai:
            self.waiting_for_ai = True
            self._start_streaming_indicator()
        elif text.strip().endswith("\n") and self.waiting_for_ai and "AI>" in text:
            # Check if this is the end of AI response (empty line after AI>)
            if text.count("\n") > 1 or (text.count("\n") == 1 and not text.strip().replace("AI>", "").strip()):
                self._stop_streaming_indicator()
                self.waiting_for_ai = False
        
        # Filter out duplicate "You> " prompts from the runner
        if text.strip() == "You> " or text.strip().startswith("You> You>"):
            # Skip auto-generated prompts
            return
        
        colors = {
            "output": "#e2e8f0",
            "success": "#34d399",
            "error": "#f87171",
            "warning": "#fbbf24",
            "info": "#60a5fa",
            "command": "#3b82f6"
        }
        color = colors.get(tag, "#e2e8f0")
        
        # Escape text properly for JavaScript (handle special chars)
        escaped_text = json.dumps(text)
        
        # Direct DOM update - no batching for instant display
        script = f"""
            (function() {{
                const output = document.getElementById('terminal-output');
                if (!output) {{ console.error('Terminal output element not found!'); return; }}
                
                // Remove streaming indicator if present
                const existingIndicator = output.querySelector('.streaming-indicator');
                if (existingIndicator) {{
                    existingIndicator.remove();
                }}
                
                const span = document.createElement('span');
                span.style.color = '{color}';
                span.textContent = {escaped_text};
                output.appendChild(span);
                
                // Always auto-scroll for real-time updates
                output.scrollTop = output.scrollHeight;
            }})();
        """
        # Execute immediately - don't queue
        self.web_view.page().runJavaScript(script)
    
    def _start_streaming_indicator(self):
        """Start showing streaming dots like Ollama"""
        if self.streaming_indicator:
            return
        
        self._dot_count = 0
        
        def update_dots():
            if not self.waiting_for_ai:
                self._stop_streaming_indicator()
                return
            
            self._dot_count = (self._dot_count + 1) % 3
            dots = "." * (self._dot_count + 1)
            
            script = f"""
                (function() {{
                    const output = document.getElementById('terminal-output');
                    if (!output) return;
                    
                    // Remove old indicator
                    const old = output.querySelector('.streaming-indicator');
                    if (old) old.remove();
                    
                    // Add new indicator
                    const span = document.createElement('span');
                    span.className = 'streaming-indicator';
                    span.style.color = '#60a5fa';
                    span.textContent = '{dots}';
                    output.appendChild(span);
                    output.scrollTop = output.scrollHeight;
                }})();
            """
            self.web_view.page().runJavaScript(script)
            
            # Schedule next update
            if self.waiting_for_ai:
                QTimer.singleShot(500, update_dots)
        
        # Start the animation
        update_dots()
    
    def _stop_streaming_indicator(self):
        """Stop streaming indicator"""
        if self.streaming_indicator:
            try:
                QTimer.singleShot(0, lambda: None)  # Cancel if possible
            except:
                pass
            self.streaming_indicator = None
        
        # Remove indicator from DOM
        script = """
            (function() {
                const output = document.getElementById('terminal-output');
                if (!output) return;
                const indicator = output.querySelector('.streaming-indicator');
                if (indicator) indicator.remove();
            })();
        """
        self.web_view.page().runJavaScript(script)
    
    def _open_4dllm(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Open .4dllm File", "", "4DLLM Files (*.4dllm);;All Files (*)")
        if file_path:
            self.run_path = Path(file_path)
            self._update_file_selection()
    
    def _open_gguf(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Open .gguf File", "", "GGUF Files (*.gguf);;All Files (*)")
        if file_path:
            self.gguf_path = Path(file_path)
            self._execute_js(f"document.getElementById('gguf-file').textContent = '{self.gguf_path.name}';")
    
    def _select_file(self):
        self._open_4dllm()
    
    def _run_model(self):
        if self.proc or not self.run_path:
            if not self.run_path:
                QMessageBox.warning(self, "No File", "Please select a .4dllm file first.")
            return
        
        # Clear terminal
        self._execute_js("document.getElementById('terminal-output').textContent = '';")
        
        cmd = self._build_command()
        env = os.environ.copy()
        env['PYTHONUNBUFFERED'] = '1'
        env['PYTHONIOENCODING'] = 'utf-8'
        
        # Ensure unbuffered Python
        if cmd[0] == sys.executable:
            cmd = [cmd[0], '-u'] + cmd[1:]
        
        try:
            self._append_terminal(f"Starting: {' '.join(shlex.quote(str(arg)) for arg in cmd)}\n", "info")
            
            # CRITICAL: Line-buffered for immediate output
            self.proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                stdin=subprocess.PIPE,
                text=True,
                bufsize=1,  # Line buffered for immediate output
                env=env,
                universal_newlines=True,
                cwd=str(Path(__file__).parent)
            )
            
            # Make stdout non-blocking for faster reads (Unix only)
            if HAS_FCNTL and sys.platform != "win32":
                try:
                    flags = fcntl.fcntl(self.proc.stdout.fileno(), fcntl.F_GETFL)
                    fcntl.fcntl(self.proc.stdout.fileno(), fcntl.F_SETFL, flags | os.O_NONBLOCK)
                except Exception as e:
                    DEBUG_LOGGER.debug(f"Could not set non-blocking mode: {e}")
            
            # Start reader thread
            self.reader_thread = OutputReaderThread(self.proc)
            self.reader_thread.outputReceived.connect(self._append_terminal)
            self.reader_thread.finished.connect(self._on_process_finished)
            self.reader_thread.start()
            
            self._append_terminal("Process started. Waiting for output...\n", "info")
        except Exception as e:
            error_msg = f"Failed to start process: {str(e)}"
            DEBUG_LOGGER.error(error_msg, exc_info=True)
            QMessageBox.critical(self, "Run Failed", error_msg)
            self._append_terminal(f"ERROR: {error_msg}\n", "error")
    
    def _stop_model(self):
        if not self.proc:
            return
        
        try:
            # Stop reader thread first
            if self.reader_thread:
                self.reader_thread.stop()
                self.reader_thread.wait(1000)  # Wait up to 1 second
            
            # Close stdin to signal termination
            if self.proc.stdin:
                try:
                    self.proc.stdin.close()
                except:
                    pass
            
            # Terminate process
            self.proc.terminate()
            time.sleep(0.5)
            
            # Force kill if still running
            if self.proc.poll() is None:
                self.proc.kill()
                time.sleep(0.1)
            
            self._append_terminal("\n[Process terminated]\n", "warning")
            self.proc = None
            self.reader_thread = None
        except Exception as e:
            DEBUG_LOGGER.error(f"Error stopping process: {e}", exc_info=True)
            self._append_terminal(f"\n[Error stopping: {e}]\n", "error")
            self.proc = None
            self.reader_thread = None
    
    def _copy_command(self):
        if not self.run_path:
            QMessageBox.warning(self, "No File", "Select a .4dllm file first.")
            return
        cmd = self._build_command()
        cmd_str = " ".join(shlex.quote(str(arg)) for arg in cmd)
        QApplication.clipboard().setText(cmd_str)
        QMessageBox.information(self, "Copied", "Command copied to clipboard!")
    
    def _select_gguf(self):
        self._open_gguf()
    
    def _build_package(self):
        QMessageBox.information(self, "Build", "Build functionality coming soon!")
    
    def _inspect_file(self):
        self._open_4dllm()
        if self.run_path:
            self._refresh_inspect()
    
    def _refresh_inspect(self):
        if not self.run_path:
            return
        # Load file info in background
        threading.Thread(target=self._load_inspect_data, daemon=True).start()
    
    def _load_inspect_data(self):
        try:
            info = read_4dllm_info(self.run_path)
            content = f"File: {self.run_path.name}\n"
            content += f"Size: {self.run_path.stat().st_size / (1024*1024):.2f} MB\n"
            if info.get("valid"):
                content += f"Version: {info.get('version_label', 'unknown')}\n"
                content += f"Modules: {info.get('module_count', 0)}\n"
            else:
                content += f"Error: {info.get('error', 'Unknown error')}\n"
            
            self._execute_js(f"document.getElementById('inspect-output').textContent = {json.dumps(content)};")
        except Exception as e:
            DEBUG_LOGGER.error(f"Inspect error: {e}")
    
    def _select_profile(self, profile: str):
        if profile in self.profiles:
            self.current_profile = self.profiles[profile].copy()
    
    def _toggle_unsafe(self, enabled: bool):
        self.unsafe_enabled = enabled
        color = "#f87171" if enabled else "#34d399"
        text = "UNSAFE" if enabled else "SAFE"
        self._execute_js(f"""
            const badge = document.getElementById('safety-badge');
            badge.textContent = '{text}';
            badge.style.background = 'rgba(' + (parseInt('{color}'.slice(1, 3), 16)) + ', ' + (parseInt('{color}'.slice(3, 5), 16)) + ', ' + (parseInt('{color}'.slice(5, 7), 16)) + ', 0.2)';
            badge.style.border = '1px solid {color}';
        """)
    
    def _send_chat_message(self, text: str):
        """Send chat message ONLY when user explicitly sends it"""
        if not self.proc:
            self._append_terminal("[No process running]\n", "warning")
            return
        
        if not self.proc.stdin:
            self._append_terminal("[Process stdin not available]\n", "warning")
            return
        
        # Don't send if AI is still generating
        if self.waiting_for_ai:
            self._append_terminal("[Please wait for AI to finish responding]\n", "warning")
            return
        
        try:
            # Show user message FIRST
            self._append_terminal(f"You> {text}\n", "command")
            
            # Write message with newline and flush IMMEDIATELY
            message = text + "\n"
            self.proc.stdin.write(message)
            self.proc.stdin.flush()
            
            # Set waiting state - AI will respond
            self.waiting_for_ai = True
            self._start_streaming_indicator()
            
            DEBUG_LOGGER.debug(f"Sent chat message: {text}")
        except BrokenPipeError:
            self._append_terminal("[Process ended]\n", "error")
            self.proc = None
            self.waiting_for_ai = False
        except Exception as e:
            error_msg = f"Error sending message: {e}"
            DEBUG_LOGGER.error(error_msg, exc_info=True)
            self._append_terminal(f"[Error: {error_msg}]\n", "error")
            self.waiting_for_ai = False
    
    def _build_command(self) -> List[str]:
        """Build command to run"""
        runner_script = Path(__file__).parent / "4dllm_runner.py"
        cmd = [
            sys.executable,
            str(runner_script),
            "--file", str(self.run_path),
            "--backend", self.current_profile.get("backend", "llama_cpp"),
            "--n-ctx", str(self.current_profile.get("n_ctx", "4096")),
            "--threads", str(self.current_profile.get("threads", "4")),
            "--gpu-layers", str(self.current_profile.get("gpu_layers", "0")),
            "--max-tokens", str(self.current_profile.get("max_tokens", "256")),
            "--temp", str(self.current_profile.get("temp", "0.7")),
        ]
        if self.unsafe_enabled:
            cmd.append("--unsafe-modules")
        return cmd
    
    def _update_file_selection(self):
        if self.run_path:
            self._execute_js(f"document.getElementById('selected-file').textContent = '{self.run_path.name}';")
    
    def _on_process_finished(self):
        """Called when process finishes"""
        self._stop_streaming_indicator()
        self.waiting_for_ai = False
        self._append_terminal("\n[Process finished]\n", "info")
        # Clean up
        if self.proc:
            try:
                if self.proc.stdin:
                    self.proc.stdin.close()
            except:
                pass
        self.proc = None
        self.reader_thread = None
    
    def _on_page_loaded(self, success: bool):
        """Called when HTML page finishes loading"""
        if success:
            # Give WebChannel time to initialize
            QTimer.singleShot(200, self._verify_bridge)
    
    def _verify_bridge(self):
        """Verify WebChannel bridge is connected"""
        self._execute_js("""
            if (window.bridge && typeof window.bridge.sendChatMessage === 'function') {
                console.log('✓ Bridge connected successfully');
            } else {
                console.warn('⚠ Bridge not fully connected, retrying...');
                setTimeout(function() {
                    if (typeof qt !== 'undefined' && qt.webChannelTransport) {
                        new QWebChannel(qt.webChannelTransport, function(channel) {
                            window.bridge = channel.objects.bridge;
                            console.log('✓ Bridge connected on retry');
                        });
                    }
                }, 500);
            }
        """)


def main():
    """Main entry point"""
    if not HAS_PYQT6:
        print("ERROR: PyQt6 or PySide6 is required for this interface.")
        print("Install with: pip install PyQt6 PyQt6-WebEngine")
        return 1
    
    app = QApplication(sys.argv)
    
    # Set dark theme
    app.setStyle('Fusion')
    palette = QPalette()
    palette.setColor(QPalette.ColorRole.Window, QColor(15, 23, 42))
    palette.setColor(QPalette.ColorRole.WindowText, QColor(226, 232, 240))
    app.setPalette(palette)
    
    window = WorldClassStudio()
    window.show()
    
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())

